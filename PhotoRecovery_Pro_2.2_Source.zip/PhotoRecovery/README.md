# PhotoRecovery Pro 2.2

## البناء على GitHub
ضع `.github/workflows/build.yml` في المستودع، ثم ارفع ملف ZIP الخاص بالمشروع كما هو.
يبني ملف العمل أحدث ملف `PhotoRecovery_Pro_*.zip` وينتج نسختين:
- **full**: تفحص التخزين العام (للتثبيت المباشر).
- **play**: بلا إذن الوصول لكل الملفات، وتفحص المجلد المختار.

## التوقيع
أضف في Settings ← Secrets and variables ← Actions:
`KEYSTORE_BASE64` و`KEYSTORE_PASSWORD` (الاسم المستعار للمفتاح `photorecovery`).

## الحدود
استعادة الصور المحذوفة نهائياً دون روت غير مضمونة.
