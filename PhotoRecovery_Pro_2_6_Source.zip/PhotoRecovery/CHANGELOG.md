# Changelog

## 2.6 (not yet compiled or tested)
- Search results by file name.
- Dashboard: previewable count, successful restores, file types, last scan duration, sources, integrity.

## 2.5 (not yet compiled or tested)
- Renamed to PhotoRecovery Pro Ultimate.
- Warns before a new scan deletes unrestored extracted photos.
- Reports when the 512 MB cache or 50,000-entry folder limit leaves results incomplete.
- Existing image files up to 100 MB are accepted (was 20 MB). Carved images stay capped at 20 MB.
- Grid columns update on rotation. Elapsed time and previewable count during scans.
- Format filter reads file signatures. Dark mode follows the system until toggled.
- An error restoring one photo no longer leaves the app stuck.

## 2.4

### New
- **Integrity check for every result.** Each photo is classified as complete, partial (cut off) or
  damaged without decoding it: JPEG marker structure, PNG chunk CRC-32 checks, GIF block structure,
  WebP and BMP declared sizes. The result shows in the grid, is saved with the results, and a new
  filter hides damaged photos.
- **Report export (CSV / JSON)** of all results with source, format, size and integrity, shared
  through the system share sheet. CSV fields are protected against spreadsheet formula injection.
- **BMP and HEIC/HEIF carving.** The carver now follows the BMP header and the ISO base media box
  structure, next to JPEG, PNG, GIF and WebP.
- **Restore verification.** After a copy the size of the written file is compared with the source;
  a mismatch removes the copy and the history records the reason (`VERIFY_FAILED`, `WRITE_FAILED`...).

### Improved
- Recovery tips dialog, scan statistics, "select complete photos" and a "best condition first" sort.
- Noise filtering: app data folders, stickers, emoji, avatars and icons are skipped, and a new filter (on by default) hides images under 200 px or 8 KB.
- Gallery comparison uses a multi-index Hamming lookup (pigeonhole principle) instead of comparing
  every candidate with every gallery view. Results are identical; the cost no longer grows with the
  gallery size. A test compares it with brute force.
- Folder scanning through the Storage Access Framework asks the provider once per folder instead of
  once per file property.
- The filesystem walk skips symbolic links and stops at a maximum depth, so a link loop cannot make a
  scan endless.
- File signatures are defined once (`ImageSignatures`); three duplicated copies were removed.
- Scan errors are counted and written to the exported report.

### Build
- R8 shrinking and resource shrinking enabled for release builds (`proguard-rules.pro`).

### Tests
- Robolectric tests for the results repository and the restore outcomes/history.
- Unit tests now run against real files from a standard encoder (JPEG, PNG, GIF, WebP, BMP) and
  include fuzz tests that feed random and damaged data to the carver and the analyzer, and a
  property test of the Hamming index against brute force.

### Compatibility
- Result files written by 2.3 are still read (the new integrity column is optional).
