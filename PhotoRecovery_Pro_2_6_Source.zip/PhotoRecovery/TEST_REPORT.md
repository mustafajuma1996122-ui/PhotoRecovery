# Test report 2.6

Done: source review; XML parsing; English/Arabic string key and placeholder comparison.
NOT run: Gradle build, unit tests, emulator or device tests (no Android SDK or network).
No Android version (10-16) has been verified for this release.

Manual checks after building: JPG/PNG/WEBP restore, a file over 20 MB, a damaged file,
search, dashboard, rotation, dark mode, rescan warning, folder permission, stop during a scan.
