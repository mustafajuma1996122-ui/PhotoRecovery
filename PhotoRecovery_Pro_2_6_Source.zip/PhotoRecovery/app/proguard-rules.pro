# The app uses no reflection. Enum helpers are kept because results are stored by enum name.
-keepclassmembers enum com.mustafa.photorecovery.** {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}
