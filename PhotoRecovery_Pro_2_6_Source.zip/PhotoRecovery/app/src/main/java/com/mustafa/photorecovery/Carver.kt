package com.mustafa.photorecovery

import java.io.File
import java.io.RandomAccessFile

/**
 * Finds complete images embedded inside a larger file (cache, thumbnail database).
 * The structure of every format is followed, so an EXIF thumbnail does not end
 * the outer JPEG and a random 0x3B byte does not end a GIF. Supports JPEG, PNG,
 * GIF, WebP, BMP and HEIC. Pure Kotlin.
 */
object Carver {
    data class Hit(val start: Long, val end: Long, val extension: String, val truncated: Boolean = false) {
        val size: Long get() = end - start
    }

    private val bmpHeaderSizes = setOf(12L, 40L, 52L, 56L, 64L, 108L, 124L)
    private val heifBoxes = setOf("ftyp", "meta", "mdat", "free", "skip", "moov")

    fun scan(file: File, maxSize: Long, isCancelled: () -> Boolean = { false }, onHit: (Hit) -> Unit) {
        RandomAccessFile(file, "r").use { raf ->
            scan(FileByteSource(raf), maxSize, isCancelled, onHit)
        }
    }

    fun scan(source: ByteSource, maxSize: Long, isCancelled: () -> Boolean = { false }, onHit: (Hit) -> Unit) {
        var position = 0L
        // End of the last complete image; a HEIC box starts four bytes before its signature.
        var floor = 0L
        while (position < source.length) {
            if ((position and 0xFFFF) == 0L && isCancelled()) return
            val hit = when (source[position]) {
                0xFF -> jpeg(source, position, maxSize)
                0x89 -> png(source, position, maxSize)
                'G'.code -> gif(source, position, maxSize)
                'R'.code -> webp(source, position, maxSize)
                'B'.code -> bmp(source, position, maxSize)
                'f'.code -> if (position - 4 >= floor) heic(source, position - 4, maxSize) else null
                else -> null
            }
            if (hit != null) {
                if (isCancelled()) return
                onHit(hit)
            }
            // A truncated candidate may hide further images, so keep searching inside it.
            if (hit != null && !hit.truncated) {
                floor = hit.end
                position = hit.end
            } else {
                position++
            }
        }
    }

    /** Copies one hit to [target]; a truncated JPEG gets the missing end marker. */
    fun extract(file: File, hit: Hit, target: File) {
        RandomAccessFile(file, "r").use { input ->
            input.seek(hit.start)
            target.outputStream().use { output ->
                val buffer = ByteArray(64 * 1024)
                var remaining = hit.size
                while (remaining > 0) {
                    val count = input.read(buffer, 0, minOf(remaining, buffer.size.toLong()).toInt())
                    if (count < 0) break
                    output.write(buffer, 0, count)
                    remaining -= count
                }
                if (hit.truncated) output.write(byteArrayOf(0xFF.toByte(), 0xD9.toByte()))
            }
        }
    }

    private fun jpeg(s: ByteSource, start: Long, maxSize: Long): Hit? {
        if (s[start + 1] != 0xD8 || s[start + 2] != 0xFF) return null
        val limit = start + maxSize
        var p = start + 2
        var hasScan = false
        fun truncated(end: Long) =
            if (hasScan && end - start >= 512) Hit(start, end, "jpg", true) else null
        while (p < limit) {
            if (p >= s.length) return truncated(s.length)
            if (s[p] != 0xFF) return truncated(p)
            val marker = s[p + 1]
            when {
                marker < 0 -> return truncated(s.length)
                marker == 0xFF -> p++
                marker == 0xD9 -> return if (hasScan) Hit(start, p + 2, "jpg") else null
                marker == 0xD8 || marker == 0x00 -> return truncated(p)
                marker == 0x01 || marker in 0xD0..0xD7 -> p += 2
                else -> {
                    val size = s.bigEndian(p + 2, 2)
                    if (size < 2) return truncated(p)
                    p += 2 + size
                    if (marker == 0xDA) {
                        hasScan = true
                        // Skip entropy coded data up to the next real marker.
                        while (p < limit && p < s.length) {
                            if (s[p] == 0xFF) {
                                val next = s[p + 1]
                                if (next == 0x00 || next in 0xD0..0xD7) p += 2
                                else if (next == 0xFF) p++
                                else break
                            } else p++
                        }
                    }
                }
            }
        }
        return null
    }

    private fun png(s: ByteSource, start: Long, maxSize: Long): Hit? {
        if (!s.matches(start + 1, "PNG\r\n\u001A\n")) return null
        var p = start + 8
        if (s.bigEndian(p, 4) != 13L || !s.matches(p + 4, "IHDR")) return null
        while (p + 12 <= s.length) {
            val size = s.bigEndian(p, 4)
            val end = p + 12 + size
            if (size < 0 || end > s.length || end - start > maxSize) return null
            if (s.matches(p + 4, "IEND")) return Hit(start, end, "png")
            p = end
        }
        return null
    }

    private fun gif(s: ByteSource, start: Long, maxSize: Long): Hit? {
        if (!s.matches(start, "GIF89a") && !s.matches(start, "GIF87a")) return null
        val screenFlags = s[start + 10]
        if (screenFlags < 0) return null
        var p = start + 13 + colorTable(screenFlags)
        var images = 0
        /** Returns the position after a chain of data sub-blocks, or -1. */
        fun skipBlocks(from: Long): Long {
            var q = from
            while (q - start <= maxSize) {
                val size = s[q]
                if (size < 0) return -1
                q += 1 + size
                if (size == 0) return q
            }
            return -1
        }
        while (p >= 0 && p - start < maxSize) {
            when (s[p]) {
                0x3B -> return if (images > 0) Hit(start, p + 1, "gif") else null
                0x21 -> p = skipBlocks(p + 2)
                0x2C -> {
                    val flags = s[p + 9]
                    if (flags < 0) return null
                    p = skipBlocks(p + 11 + colorTable(flags))
                    images++
                }
                else -> return null
            }
        }
        return null
    }

    private fun colorTable(flags: Int): Long =
        if (flags and 0x80 != 0) 3L * (1 shl ((flags and 7) + 1)) else 0L

    private fun webp(s: ByteSource, start: Long, maxSize: Long): Hit? {
        if (!s.matches(start, "RIFF") || !s.matches(start + 8, "WEBP")) return null
        var size = 0L
        for (i in 0 until 4) size = size or (s[start + 4 + i].toLong() shl (8 * i))
        val end = start + 8 + size
        if (size < 12 || end > s.length || end - start > maxSize) return null
        return Hit(start, end, "webp")
    }

    /** BMP: the declared size, the reserved field, the pixel offset and the header size must all agree. */
    private fun bmp(s: ByteSource, start: Long, maxSize: Long): Hit? {
        if (s[start + 1] != 'M'.code) return null
        val size = s.littleEndian(start + 2, 4)
        if (size < 26 || size > maxSize || start + size > s.length) return null
        if (s.littleEndian(start + 6, 4) != 0L) return null
        val offset = s.littleEndian(start + 10, 4)
        if (offset < 26 || offset >= size) return null
        val header = s.littleEndian(start + 14, 4)
        if (header !in bmpHeaderSizes) return null
        val width: Long
        val height: Long
        if (header == 12L) {
            width = s.littleEndian(start + 18, 2)
            height = s.littleEndian(start + 20, 2)
        } else {
            width = s.littleEndian(start + 18, 4)
            val rawHeight = s.littleEndian(start + 22, 4)
            // A negative height (stored unsigned) means a top-down bitmap.
            height = if (rawHeight >= 0x80000000L) 0x100000000L - rawHeight else rawHeight
            if (width >= 0x80000000L) return null
        }
        if (width !in 1L..100_000L || height !in 1L..100_000L) return null
        return Hit(start, start + size, "bmp")
    }

    private fun fourCharCode(s: ByteSource, position: Long): String? {
        val chars = CharArray(4)
        for (i in 0 until 4) {
            val b = s[position + i]
            if (b < 0x20 || b > 0x7E) return null
            chars[i] = b.toChar()
        }
        return String(chars)
    }

    /**
     * HEIC/HEIF: walks the top level boxes (ftyp, meta, mdat, ...). A photo needs both
     * the metadata box and the data box; the image ends after the last plausible box.
     */
    private fun heic(s: ByteSource, start: Long, maxSize: Long): Hit? {
        if (start < 0 || !s.matches(start + 4, "ftyp")) return null
        val ftypSize = s.bigEndian(start, 4)
        if (ftypSize < 16 || start + ftypSize > s.length) return null
        val brand = fourCharCode(s, start + 8) ?: return null
        if (brand !in ImageSignatures.heifBrands) return null
        var p = start
        var end = -1L
        var hasMeta = false
        var hasData = false
        while (p + 8 <= s.length && p - start <= maxSize) {
            var size = s.bigEndian(p, 4)
            val type = fourCharCode(s, p + 4) ?: break
            var header = 8L
            if (size == 1L) {
                // 64 bit box size.
                val high = s.bigEndian(p + 8, 4)
                val low = s.bigEndian(p + 12, 4)
                if (high < 0 || low < 0) break
                size = (high shl 32) or low
                header = 16L
            } else if (size == 0L) {
                size = s.length - p
            }
            if (size < header) break
            val next = p + size
            if (next > s.length || next - start > maxSize) break
            if (p != start && type !in heifBoxes) break
            if (type == "meta") hasMeta = true
            if (type == "mdat") hasData = true
            end = next
            p = next
        }
        return if (hasMeta && hasData && end > start) Hit(start, end, "heic") else null
    }
}
