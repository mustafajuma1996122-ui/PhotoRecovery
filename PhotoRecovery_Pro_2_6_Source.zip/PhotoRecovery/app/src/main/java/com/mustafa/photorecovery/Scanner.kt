package com.mustafa.photorecovery

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest

class Scanner(private val context: Context, private val onFound: (Photo) -> Unit) {
    @Volatile var cancelled = false
    private val seenPaths = HashSet<String>()
    private val seenHashes = HashSet<String>()
    private val carveDir = temporaryDirectory(context)
    @Volatile var scannedFiles = 0
        private set
    @Volatile var currentFolder = ""
        private set

    /** Files that could not be read or processed. They never stop the scan. */
    @Volatile var errorCount = 0
        private set
    private val imageExt = setOf("jpg", "jpeg", "png", "gif", "webp", "heic", "heif", "bmp")
    private val suspiciousWords = listOf("trash", "recycle", "deleted", ".bin", "thumb", "cache")
    /** App internals and artwork (icons, stickers, avatars) are never lost photos. */
    private val noiseWords = listOf(
        "/android/data/", "/android/obb/", "sticker", "emoji", "emoticon", "avatar",
        "/icon", "profile pictures", "/.thumbnails/emoji"
    )
    private val selectedFolderWords = listOf("trash", "recycle", "deleted", "thumb", "cache")
    private val maxCandidateBytes = 20L * 1024 * 1024
    private val maxStoredBytes = 512L * 1024 * 1024
    private var storedBytes = 0L
    /** Originals are decoded downsampled, so they may be larger than carved candidates. */
    private val maxOriginalBytes = 100L * 1024 * 1024
    /** True when a safety limit skipped results, so the scan is not exhaustive. */
    @Volatile var limitReached = false
        private set

    private class Pending(val id: String, val name: String, val depth: Int)

    fun scan(treeUri: Uri? = null) {
        carveDir.deleteRecursively()
        storedBytes = 0L
        seenPaths.clear()
        seenHashes.clear()
        if (!carveDir.mkdirs() && !carveDir.isDirectory) throw IllegalStateException("Cannot create the temporary folder")
        if (treeUri != null) {
            scanSelectedTree(treeUri)
        } else {
            if (Build.VERSION.SDK_INT >= 30) scanSystemTrash()
            walk(Environment.getExternalStorageDirectory())
        }
        if (cacheFull()) limitReached = true
    }

    /** Scans only the folder explicitly granted through Android's Storage Access Framework. */
    private fun scanSelectedTree(treeUri: Uri) {
        val rootId = try { SafTree.rootDocumentId(treeUri) } catch (_: Exception) { return }
        val stack = ArrayDeque<Pending>()
        stack.add(Pending(rootId, "", 0))
        var visited = 0
        while (stack.isNotEmpty() && !cancelled && !cacheFull() && visited < MAX_SAF_ENTRIES) {
            val directory = stack.removeLast()
            if (directory.depth > MAX_DEPTH) continue
            currentFolder = directory.name
            for (entry in SafTree.children(context, treeUri, directory.id)) {
                if (cancelled) return
                if (visited++ >= MAX_SAF_ENTRIES) { limitReached = true; return }
                if (entry.isDirectory) {
                    stack.add(Pending(entry.documentId, entry.name, directory.depth + 1))
                } else if (entry.size in 16L..MAX_SAF_FILE_BYTES) {
                    scannedFiles++
                    scanSelectedFile(entry, visited)
                }
            }
        }
    }

    private fun scanSelectedFile(entry: SafTree.Entry, number: Int) {
        val name = entry.name.ifEmpty { "document_$number" }
        val lower = name.lowercase()
        val extension = name.substringAfterLast('.', "").lowercase()
        if (noiseWords.any { lower.contains(it) }) return
        val suspicious = lower.startsWith(".") || selectedFolderWords.any { lower.contains(it) }
        // Do not copy ordinary documents or videos into the app cache.
        if (extension !in imageExt && !suspicious) return
        val temp = File(carveDir, "saf_${number}_${name.replace(Regex("[^A-Za-z0-9._-]"), "_")}")
        try {
            context.contentResolver.openInputStream(entry.uri)?.use { input ->
                FileOutputStream(temp).use { output -> input.copyTo(output, 64 * 1024) }
            } ?: return
            if (temp.length() <= maxOriginalBytes &&
                (temp.extension.lowercase() in imageExt || ImageSignatures.detect(temp) != null) &&
                isDecodableImage(temp)) {
                retain(temp, PhotoSource.FOLDER)
            } else {
                if (suspicious && temp.length() >= 64L * 1024) carve(temp)
                temp.delete()
            }
        } catch (_: Exception) {
            errorCount++
            temp.delete()
        }
    }

    /** Queries only trashed MediaStore rows. DATA may be unavailable on some devices. */
    private fun scanSystemTrash() {
        try {
            val args = Bundle().apply {
                putInt(MediaStore.QUERY_ARG_MATCH_TRASHED, MediaStore.MATCH_ONLY)
            }
            context.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Images.Media.DATA), args, null
            )?.use { cursor ->
                val pathColumn = cursor.getColumnIndex(MediaStore.Images.Media.DATA)
                if (pathColumn < 0) return
                while (cursor.moveToNext() && !cancelled) {
                    val path = cursor.getString(pathColumn) ?: continue
                    val candidate = File(path)
                    if (isDecodableImage(candidate)) add(candidate, PhotoSource.TRASH)
                }
            }
        } catch (_: Exception) {
            // OEM MediaStore implementations differ; filesystem scanning continues.
            errorCount++
        }
    }

    /** Symbolic links are skipped, so a link back to a parent folder cannot make the walk endless. */
    private fun isSymbolicLink(file: File): Boolean = try {
        java.nio.file.Files.isSymbolicLink(file.toPath())
    } catch (_: Exception) {
        false
    }

    private fun walk(root: File) {
        val stack = ArrayDeque<Pair<File, Int>>()
        stack.add(root to 0)
        while (stack.isNotEmpty() && !cancelled) {
            val (directory, depth) = stack.removeLast()
            currentFolder = directory.name
            val children = try { directory.listFiles() } catch (_: SecurityException) { null } ?: continue
            for (entry in children) {
                if (cancelled) return
                try {
                    if (entry.isDirectory) {
                        val path = entry.absolutePath
                        if (depth < MAX_DEPTH &&
                            !path.endsWith("/Pictures/Recovered") &&
                            !path.startsWith(context.cacheDir.absolutePath) &&
                            !path.startsWith(context.filesDir.absolutePath) &&
                            !path.startsWith(context.codeCacheDir.absolutePath) &&
                            !isSymbolicLink(entry)) stack.add(entry to depth + 1)
                    } else if (entry.isFile && entry.canRead()) {
                        scannedFiles++
                        inspect(entry)
                    }
                } catch (_: SecurityException) { /* inaccessible folder */ }
            }
        }
    }

    /** Deliberately avoids ordinary gallery files to reduce noise and scan time. */
    private fun inspect(file: File) {
        if (file.length() < 16L) return
        val relative = file.absolutePath
            .removePrefix(Environment.getExternalStorageDirectory().absolutePath)
            .lowercase()
        if (noiseWords.any { relative.contains(it) }) return
        val hidden = relative.split('/').any { it.startsWith(".") }
        val suspiciousPath = hidden || suspiciousWords.any { relative.contains(it) }
        if (!suspiciousPath) return

        if (file.name.startsWith(".thumbdata", ignoreCase = true)) {
            carve(file)
            return
        }
        if (file.length() <= maxOriginalBytes &&
            (file.extension.lowercase() in imageExt || ImageSignatures.detect(file) != null) &&
            isDecodableImage(file)) {
            add(file, if (relative.contains("thumb")) PhotoSource.THUMBNAIL else PhotoSource.HIDDEN)
        } else if (file.length() in 64L * 1024..512L * 1024 * 1024 &&
            (relative.contains("cache") || relative.contains("thumb"))) {
            carve(file)
        }
    }

    private fun isDecodableImage(file: File): Boolean {
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        return try {
            BitmapFactory.decodeFile(file.absolutePath, options)
            val bitmapFactoryCanRead = options.outWidth > 0 && options.outHeight > 0 &&
                options.outWidth <= 100_000 && options.outHeight <= 100_000 &&
                options.outMimeType?.startsWith("image/") == true
            if (bitmapFactoryCanRead) return true

            // HEIF/HEIC decoding is available only on Android releases/codecs that support it.
            if (Build.VERSION.SDK_INT >= 28 && ImageSignatures.detect(file) == ImageFormat.HEIC) {
                val source = android.graphics.ImageDecoder.createSource(file)
                val decoded = android.graphics.ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                    val width = info.size.width
                    val height = info.size.height
                    if (width <= 0 || height <= 0 || width > 100_000 || height > 100_000) {
                        throw IllegalArgumentException("bad HEIF size")
                    }
                    decoder.setTargetSampleSize(16)
                    decoder.setAllocator(android.graphics.ImageDecoder.ALLOCATOR_SOFTWARE)
                }
                decoded.recycle()
                return true
            }
            false
        } catch (_: Exception) { false }
    }

    /** One pass over the source finds every supported format. */
    private fun carve(source: File) {
        try {
            Carver.scan(source, maxCandidateBytes, { cancelled || cacheFull() }) { hit ->
                if (hit.size >= 128) {
                    val candidate = File(carveDir, "candidate_${System.nanoTime()}.${hit.extension}")
                    try {
                        Carver.extract(source, hit, candidate)
                        retain(candidate, PhotoSource.CARVED, hit.truncated)
                    } catch (_: Exception) {
                        errorCount++
                        candidate.delete()
                    }
                }
            }
        } catch (_: Exception) {
            // A damaged cache file must not abort the whole scan.
            errorCount++
        }
    }

    private fun cacheFull() = storedBytes >= maxStoredBytes

    /** Keeps a temporary candidate only if it decodes, is new and fits the cache limit. */
    private fun retain(candidate: File, source: PhotoSource, truncated: Boolean = false) {
        val size = candidate.length()
        if (storedBytes + size > maxStoredBytes) limitReached = true
        if (storedBytes + size <= maxStoredBytes && isDecodableImage(candidate) &&
            seenHashes.add(sha256(candidate))) {
            storedBytes += size
            add(candidate, source, truncated)
        } else candidate.delete()
    }

    companion object {
        private const val MAX_DEPTH = 32
        private const val MAX_SAF_ENTRIES = 50_000
        private const val MAX_SAF_FILE_BYTES = 512L * 1024 * 1024

        fun temporaryDirectory(context: Context) = File(context.filesDir, "carved")
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun add(file: File, source: PhotoSource, truncated: Boolean = false) {
        if (file.isFile && file.canRead() && file.length() >= 16 && seenPaths.add(file.absolutePath)) {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            var integrity = IntegrityAnalyzer.analyze(file).integrity
            // The end marker of a cut JPEG was added by the extraction, not found in the data.
            if (truncated && integrity == Integrity.COMPLETE) integrity = Integrity.PARTIAL
            onFound(Photo(file, source, maxOf(bounds.outWidth, 0), maxOf(bounds.outHeight, 0), integrity))
        }
    }
}
