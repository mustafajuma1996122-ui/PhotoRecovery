package com.mustafa.photorecovery

/**
 * One saved result per line. Pure Kotlin so it can be unit tested.
 *
 * Current format: source, width, height, integrity, path (tab separated, the path last so it may
 * contain tabs). Lines written by older versions have no integrity column and are still read.
 */
object ResultCodec {
    data class Entry(
        val source: String,
        val width: Int,
        val height: Int,
        val path: String,
        val integrity: String = "UNKNOWN"
    )

    fun encode(entry: Entry): String? =
        if (entry.path.any { it == '\n' || it == '\r' }) null
        else "${entry.source}\t${entry.width}\t${entry.height}\t${entry.integrity}\t${entry.path}"

    fun decode(line: String): Entry? {
        // Absolute paths start with a slash, so a name in the fourth column marks the current format.
        val current = line.split('\t', limit = 5)
        if (current.size == 5 && current[3].isNotEmpty() && current[3].all { it.isUpperCase() || it == '_' }) {
            return build(current[0], current[1], current[2], current[4], current[3])
        }
        val legacy = line.split('\t', limit = 4)
        if (legacy.size != 4) return null
        return build(legacy[0], legacy[1], legacy[2], legacy[3], "UNKNOWN")
    }

    private fun build(source: String, width: String, height: String, path: String, integrity: String): Entry? {
        if (path.isEmpty()) return null
        val w = width.toIntOrNull() ?: return null
        val h = height.toIntOrNull() ?: return null
        return Entry(source, w, h, path, integrity)
    }
}
