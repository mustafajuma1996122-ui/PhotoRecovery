package com.mustafa.photorecovery

import java.io.File
import java.io.RandomAccessFile
import java.util.zip.CRC32

/** How trustworthy a candidate file is, judged from its structure and checksums. */
enum class Integrity {
    /** Every structural check passed. */
    COMPLETE,

    /** Readable header and image data, but the file ends early. */
    PARTIAL,

    /** Corrupted (bad checksum or broken structure) or without usable image data. */
    DAMAGED,

    /** Format not analysed here; the system decoder is the only judge. */
    UNKNOWN
}

enum class Issue {
    NO_FRAME_HEADER,
    NO_IMAGE_DATA,
    NO_END_MARKER,
    TRUNCATED,
    BAD_CRC,
    BAD_STRUCTURE,
    /** Bytes after the end of the image. Harmless, reported for completeness. */
    TRAILING_DATA
}

data class IntegrityReport(
    val format: ImageFormat?,
    val width: Int,
    val height: Int,
    val integrity: Integrity,
    val issues: Set<Issue>
)

/**
 * Validates image files without decoding them: JPEG marker structure, PNG chunk CRCs,
 * GIF block structure, WebP and BMP declared sizes. Pure Kotlin, never throws.
 */
object IntegrityAnalyzer {
    private val unknown = IntegrityReport(null, 0, 0, Integrity.UNKNOWN, emptySet())

    fun analyze(file: File): IntegrityReport = try {
        RandomAccessFile(file, "r").use { analyze(FileByteSource(it)) }
    } catch (_: Exception) {
        unknown
    }

    fun analyze(bytes: ByteArray): IntegrityReport = analyze(ArrayByteSource(bytes))

    fun analyze(source: ByteSource): IntegrityReport = try {
        val count = minOf(ImageSignatures.HEADER_SIZE.toLong(), source.length).toInt()
        val header = ByteArray(count) { source[it.toLong()].toByte() }
        when (val format = ImageSignatures.detect(header, count)) {
            null -> unknown
            ImageFormat.JPEG -> jpeg(source)
            ImageFormat.PNG -> png(source)
            ImageFormat.GIF -> gif(source)
            ImageFormat.WEBP -> webp(source)
            ImageFormat.BMP -> bmp(source)
            ImageFormat.HEIC -> IntegrityReport(format, 0, 0, Integrity.UNKNOWN, emptySet())
        }
    } catch (_: Exception) {
        unknown
    }

    private fun verdict(issues: Set<Issue>): Integrity = when {
        Issue.BAD_CRC in issues || Issue.BAD_STRUCTURE in issues ||
            Issue.NO_FRAME_HEADER in issues || Issue.NO_IMAGE_DATA in issues -> Integrity.DAMAGED
        Issue.NO_END_MARKER in issues || Issue.TRUNCATED in issues -> Integrity.PARTIAL
        else -> Integrity.COMPLETE
    }

    /** Sizes read from damaged headers can be absurd, so they are clamped to a valid Int. */
    private fun clamp(value: Long): Int = value.coerceIn(0L, Int.MAX_VALUE.toLong()).toInt()

    private fun report(format: ImageFormat, width: Long, height: Long, issues: Set<Issue>) =
        IntegrityReport(format, clamp(width), clamp(height), verdict(issues), issues)

    private fun jpeg(s: ByteSource): IntegrityReport {
        val issues = LinkedHashSet<Issue>()
        var width = 0L
        var height = 0L
        var hasFrame = false
        var hasScan = false
        var hasEnd = false
        var p = 2L
        loop@ while (p + 1 < s.length) {
            if (s[p] != 0xFF) {
                issues.add(Issue.BAD_STRUCTURE)
                break@loop
            }
            val marker = s[p + 1]
            when {
                marker == 0xFF -> p++
                marker == 0xD9 -> {
                    hasEnd = true
                    p += 2
                    break@loop
                }
                marker == 0x00 || marker == 0xD8 -> {
                    issues.add(Issue.BAD_STRUCTURE)
                    break@loop
                }
                marker == 0x01 || marker in 0xD0..0xD7 -> p += 2
                else -> {
                    val size = s.bigEndian(p + 2, 2)
                    if (size < 2 || p + 2 + size > s.length) {
                        issues.add(Issue.TRUNCATED)
                        break@loop
                    }
                    if (marker in 0xC0..0xCF && marker != 0xC4 && marker != 0xC8 && marker != 0xCC) {
                        hasFrame = true
                        height = s.bigEndian(p + 5, 2)
                        width = s.bigEndian(p + 7, 2)
                    }
                    p += 2 + size
                    if (marker == 0xDA) {
                        hasScan = true
                        // Skip entropy coded data up to the next real marker.
                        while (p < s.length) {
                            if (s[p] == 0xFF) {
                                val next = s[p + 1]
                                if (next == 0x00 || next in 0xD0..0xD7) p += 2
                                else if (next == 0xFF) p++
                                else break
                            } else p++
                        }
                    }
                }
            }
        }
        if (!hasFrame) issues.add(Issue.NO_FRAME_HEADER)
        if (!hasScan) issues.add(Issue.NO_IMAGE_DATA)
        if (!hasEnd) issues.add(Issue.NO_END_MARKER) else if (p < s.length) issues.add(Issue.TRAILING_DATA)
        return report(ImageFormat.JPEG, width, height, issues)
    }

    private fun png(s: ByteSource): IntegrityReport {
        val issues = LinkedHashSet<Issue>()
        var width = 0L
        var height = 0L
        var hasData = false
        var hasEnd = false
        var p = 8L
        if (s.bigEndian(p, 4) != 13L || !s.matches(p + 4, "IHDR")) {
            issues.add(Issue.NO_FRAME_HEADER)
            return report(ImageFormat.PNG, 0, 0, issues)
        }
        width = s.bigEndian(p + 8, 4)
        height = s.bigEndian(p + 12, 4)
        while (p + 12 <= s.length) {
            val size = s.bigEndian(p, 4)
            if (size < 0 || size > Int.MAX_VALUE) {
                issues.add(Issue.BAD_STRUCTURE)
                break
            }
            val isData = s.matches(p + 4, "IDAT")
            val end = p + 12 + size
            if (end > s.length) {
                // The last chunk is cut off; a partly stored IDAT still holds image rows.
                if (isData) hasData = true
                issues.add(Issue.TRUNCATED)
                break
            }
            // Only critical chunks (uppercase first letter) must have a valid checksum.
            val critical = (s[p + 4] and 0x20) == 0
            if (critical && !crcMatches(s, p + 4, size + 4, s.bigEndian(p + 8 + size, 4))) {
                issues.add(Issue.BAD_CRC)
            }
            if (isData) hasData = true
            val isEnd = s.matches(p + 4, "IEND")
            p = end
            if (isEnd) {
                hasEnd = true
                break
            }
        }
        if (!hasEnd && Issue.TRUNCATED !in issues && Issue.BAD_STRUCTURE !in issues) {
            issues.add(Issue.NO_END_MARKER)
        }
        if (!hasData) issues.add(Issue.NO_IMAGE_DATA)
        if (hasEnd && p < s.length) issues.add(Issue.TRAILING_DATA)
        return report(ImageFormat.PNG, width, height, issues)
    }

    private fun crcMatches(s: ByteSource, from: Long, count: Long, expected: Long): Boolean {
        val crc = CRC32()
        var i = 0L
        while (i < count) {
            crc.update(s[from + i])
            i++
        }
        return crc.value == expected
    }

    private fun gifColorTable(flags: Int): Long =
        if (flags and 0x80 != 0) 3L * (1 shl ((flags and 7) + 1)) else 0L

    /** Returns the position after a chain of data sub-blocks, or -1 if the data ends first. */
    private fun skipBlocks(s: ByteSource, from: Long): Long {
        var q = from
        while (q < s.length) {
            val size = s[q]
            if (size < 0) return -1
            q += 1 + size
            if (size == 0) return q
        }
        return -1
    }

    private fun gif(s: ByteSource): IntegrityReport {
        val issues = LinkedHashSet<Issue>()
        val width = s.littleEndian(6, 2)
        val height = s.littleEndian(8, 2)
        val flags = s[10]
        var p = 13L + gifColorTable(maxOf(flags, 0))
        var images = 0
        var hasEnd = false
        loop@ while (p < s.length) {
            when (s[p]) {
                0x3B -> {
                    hasEnd = true
                    p++
                    break@loop
                }
                0x21 -> {
                    p = skipBlocks(s, p + 2)
                    if (p < 0) {
                        issues.add(Issue.TRUNCATED)
                        break@loop
                    }
                }
                0x2C -> {
                    val imageFlags = s[p + 9]
                    if (imageFlags < 0) {
                        issues.add(Issue.TRUNCATED)
                        break@loop
                    }
                    p = skipBlocks(s, p + 11 + gifColorTable(imageFlags))
                    if (p < 0) {
                        issues.add(Issue.TRUNCATED)
                        break@loop
                    }
                    images++
                }
                else -> {
                    issues.add(Issue.BAD_STRUCTURE)
                    break@loop
                }
            }
        }
        if (images == 0) issues.add(Issue.NO_IMAGE_DATA)
        if (!hasEnd && Issue.TRUNCATED !in issues && Issue.BAD_STRUCTURE !in issues) {
            issues.add(Issue.NO_END_MARKER)
        }
        if (hasEnd && p < s.length) issues.add(Issue.TRAILING_DATA)
        return report(ImageFormat.GIF, width, height, issues)
    }

    private fun webp(s: ByteSource): IntegrityReport {
        val issues = LinkedHashSet<Issue>()
        var width = 0L
        var height = 0L
        val declaredEnd = 8L + s.littleEndian(4, 4)
        when {
            s.matches(12, "VP8X") -> {
                width = 1 + s.littleEndian(24, 3)
                height = 1 + s.littleEndian(27, 3)
            }
            s.matches(12, "VP8L") -> if (s[20] == 0x2F) {
                val bits = s.littleEndian(21, 4)
                width = (bits and 0x3FFF) + 1
                height = ((bits shr 14) and 0x3FFF) + 1
            }
            s.matches(12, "VP8 ") -> if (s[23] == 0x9D && s[24] == 0x01 && s[25] == 0x2A) {
                width = s.littleEndian(26, 2) and 0x3FFF
                height = s.littleEndian(28, 2) and 0x3FFF
            }
            else -> issues.add(Issue.NO_FRAME_HEADER)
        }
        if (declaredEnd > s.length) issues.add(Issue.TRUNCATED)
        else if (declaredEnd < s.length) issues.add(Issue.TRAILING_DATA)
        return report(ImageFormat.WEBP, width, height, issues)
    }

    private fun bmp(s: ByteSource): IntegrityReport {
        val issues = LinkedHashSet<Issue>()
        val declared = s.littleEndian(2, 4)
        val offset = s.littleEndian(10, 4)
        val header = s.littleEndian(14, 4)
        val width: Long
        val height: Long
        if (header == 12L) {
            width = s.littleEndian(18, 2)
            height = s.littleEndian(20, 2)
        } else {
            width = s.littleEndian(18, 4)
            val rawHeight = s.littleEndian(22, 4)
            height = if (rawHeight >= 0x80000000L) 0x100000000L - rawHeight else rawHeight
        }
        if (offset < 26 || offset >= declared || width <= 0 || height <= 0) issues.add(Issue.BAD_STRUCTURE)
        if (declared > s.length) issues.add(Issue.TRUNCATED)
        else if (declared < s.length) issues.add(Issue.TRAILING_DATA)
        return report(ImageFormat.BMP, width, height, issues)
    }
}
