package com.mustafa.photorecovery

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract

/**
 * Lists a Storage Access Framework tree with one query per folder. DocumentFile asks the
 * provider again for every property of every file, which is very slow in large folders.
 */
object SafTree {
    data class Entry(
        val documentId: String,
        val name: String,
        val mime: String,
        /** -1 when the provider does not report a size. */
        val size: Long,
        val uri: Uri
    ) {
        val isDirectory: Boolean get() = mime == DocumentsContract.Document.MIME_TYPE_DIR
    }

    fun rootDocumentId(treeUri: Uri): String = DocumentsContract.getTreeDocumentId(treeUri)

    /** Returns an empty list if the folder cannot be read. */
    fun children(context: Context, treeUri: Uri, parentDocumentId: String): List<Entry> {
        val result = ArrayList<Entry>()
        try {
            val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocumentId)
            val projection = arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_SIZE
            )
            context.contentResolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
                while (cursor.moveToNext()) {
                    val id = cursor.getString(0) ?: continue
                    val name = cursor.getString(1).orEmpty()
                    val mime = cursor.getString(2).orEmpty()
                    val size = if (cursor.isNull(3)) -1L else cursor.getLong(3)
                    result.add(
                        Entry(id, name, mime, size, DocumentsContract.buildDocumentUriUsingTree(treeUri, id))
                    )
                }
            }
        } catch (_: Exception) {
            // An unreadable folder is skipped; the rest of the tree is still scanned.
        }
        return result
    }
}
