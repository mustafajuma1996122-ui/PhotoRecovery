package com.mustafa.photorecovery

import android.view.Gravity
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.card.MaterialCardView

class PhotoAdapter(
    private val items: List<Photo>,
    private val thumbs: ThumbLoader,
    private val isSelected: (Photo) -> Boolean,
    private val onClick: (Int) -> Unit,
    private val onLongClick: (Int) -> Unit
) : RecyclerView.Adapter<PhotoAdapter.Holder>() {

    class Holder(val card: MaterialCardView, val image: ImageView, val label: TextView) :
        RecyclerView.ViewHolder(card)

    override fun getItemCount() = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val context = parent.context
        val card = MaterialCardView(context)
        card.layoutParams = RecyclerView.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(context.dp(4), context.dp(4), context.dp(4), context.dp(4)) }
        val column = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        val image = ImageView(context).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        val label = TextView(context).apply {
            textSize = 11f
            maxLines = 4
            gravity = Gravity.CENTER
            setPadding(context.dp(4), context.dp(4), context.dp(4), context.dp(6))
        }
        column.addView(image, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, context.dp(180)))
        column.addView(label)
        card.addView(column)
        val holder = Holder(card, image, label)
        card.setOnClickListener {
            val position = holder.bindingAdapterPosition
            if (position != RecyclerView.NO_POSITION) onClick(position)
        }
        card.setOnLongClickListener {
            val position = holder.bindingAdapterPosition
            if (position != RecyclerView.NO_POSITION) onLongClick(position)
            true
        }
        return holder
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val context = holder.card.context
        val photo = items[position]
        val selected = isSelected(photo)
        val mark = if (selected) "✔ " else ""
        holder.label.text = mark + describe(context, photo)
        holder.card.strokeColor = context.getColor(R.color.pr_secondary)
        holder.card.strokeWidth = if (selected) context.dp(4) else 0
        thumbs.load(photo, holder.image)
    }
}
