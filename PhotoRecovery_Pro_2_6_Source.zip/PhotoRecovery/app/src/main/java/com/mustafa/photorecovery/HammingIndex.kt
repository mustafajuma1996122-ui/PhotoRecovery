package com.mustafa.photorecovery

/**
 * Finds every stored 64-bit hash within [maxDistance] bits of a query without comparing
 * against all of them (multi-index hashing). The hash is cut into maxDistance + 1 bands;
 * if two hashes differ in at most maxDistance bits, at least one band is identical
 * (pigeonhole principle), so a lookup per band finds every true match. Pure Kotlin.
 */
class HammingIndex(val maxDistance: Int) {
    private val bandCount: Int
    private val shifts: IntArray
    private val masks: LongArray
    private val tables: Array<HashMap<Long, ArrayList<Int>>>
    private val hashes = ArrayList<Long>()

    init {
        require(maxDistance in 0..63) { "maxDistance must be between 0 and 63" }
        bandCount = maxDistance + 1
        shifts = IntArray(bandCount) { it * 64 / bandCount }
        masks = LongArray(bandCount) { band ->
            val width = (band + 1) * 64 / bandCount - band * 64 / bandCount
            if (width >= 64) -1L else (1L shl width) - 1L
        }
        tables = Array(bandCount) { HashMap<Long, ArrayList<Int>>() }
    }

    val size: Int get() = hashes.size

    fun hashOf(id: Int): Long = hashes[id]

    private fun key(hash: Long, band: Int): Long = (hash ushr shifts[band]) and masks[band]

    /** Stores a hash and returns its id (0, 1, 2, ... in insertion order). */
    fun add(hash: Long): Int {
        val id = hashes.size
        hashes.add(hash)
        for (band in 0 until bandCount) {
            tables[band].getOrPut(key(hash, band)) { ArrayList() }.add(id)
        }
        return id
    }

    /**
     * True as soon as [accept] returns true for a stored hash within the distance.
     * [accept] may see the same id more than once, once per matching band.
     */
    fun anyWithin(hash: Long, accept: (Int) -> Boolean = { true }): Boolean {
        for (band in 0 until bandCount) {
            val ids = tables[band][key(hash, band)] ?: continue
            for (id in ids) {
                if (java.lang.Long.bitCount(hashes[id] xor hash) <= maxDistance && accept(id)) return true
            }
        }
        return false
    }

    /** Ids of every stored hash within the distance, without duplicates, in ascending order. */
    fun within(hash: Long): List<Int> {
        val found = java.util.TreeSet<Int>()
        for (band in 0 until bandCount) {
            val ids = tables[band][key(hash, band)] ?: continue
            for (id in ids) {
                if (java.lang.Long.bitCount(hashes[id] xor hash) <= maxDistance) found.add(id)
            }
        }
        return found.toList()
    }
}
