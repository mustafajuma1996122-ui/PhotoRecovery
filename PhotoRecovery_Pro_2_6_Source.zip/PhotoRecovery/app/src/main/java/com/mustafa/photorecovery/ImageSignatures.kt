package com.mustafa.photorecovery

import java.io.File

/** Image formats the app can recognise, with the MIME type and extension used when saving. */
enum class ImageFormat(val mime: String, val extension: String) {
    JPEG("image/jpeg", "jpg"),
    PNG("image/png", "png"),
    GIF("image/gif", "gif"),
    WEBP("image/webp", "webp"),
    HEIC("image/heic", "heic"),
    BMP("image/bmp", "bmp");

    companion object {
        fun fromMime(mime: String): ImageFormat? = when (mime.lowercase()) {
            "image/jpeg", "image/jpg" -> JPEG
            "image/png" -> PNG
            "image/gif" -> GIF
            "image/webp" -> WEBP
            "image/heic", "image/heif" -> HEIC
            "image/bmp" -> BMP
            else -> null
        }
    }
}

/** The one place that knows the first bytes of every supported format. Pure Kotlin. */
object ImageSignatures {
    const val HEADER_SIZE = 16

    val heifBrands = setOf("heic", "heix", "hevc", "hevx", "mif1", "msf1")

    /** Needs at least 12 header bytes; a shorter header is never recognised. */
    fun detect(header: ByteArray, count: Int = header.size): ImageFormat? {
        if (count < 12 || header.size < count) return null
        fun at(index: Int) = header[index].toInt() and 0xFF
        fun text(from: Int, length: Int) =
            String(header, from, length, Charsets.US_ASCII)
        return when {
            at(0) == 0xFF && at(1) == 0xD8 && at(2) == 0xFF -> ImageFormat.JPEG
            at(0) == 0x89 && text(1, 3) == "PNG" -> ImageFormat.PNG
            text(0, 4) == "GIF8" -> ImageFormat.GIF
            text(0, 4) == "RIFF" && text(8, 4) == "WEBP" -> ImageFormat.WEBP
            text(4, 4) == "ftyp" && text(8, 4) in heifBrands -> ImageFormat.HEIC
            // A real bitmap header has four reserved zero bytes at offset 6.
            at(0) == 'B'.code && at(1) == 'M'.code &&
                at(6) == 0 && at(7) == 0 && at(8) == 0 && at(9) == 0 -> ImageFormat.BMP
            else -> null
        }
    }

    fun detect(file: File): ImageFormat? {
        val header = ByteArray(HEADER_SIZE)
        val count = try {
            file.inputStream().use { it.read(header) }
        } catch (_: Exception) {
            return null
        }
        return if (count < 12) null else detect(header, count)
    }
}
