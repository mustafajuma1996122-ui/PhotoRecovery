package com.mustafa.photorecovery

import java.io.RandomAccessFile

/**
 * Random access to bytes, from a file or from memory. Reading outside the data returns -1,
 * so parsers can test for truncation without exceptions. Pure Kotlin.
 */
interface ByteSource {
    val length: Long

    operator fun get(position: Long): Int

    fun matches(position: Long, text: String): Boolean =
        text.indices.all { get(position + it) == text[it].code }

    /** Unsigned big endian value, or -1 if it does not fit inside the data. */
    fun bigEndian(position: Long, bytes: Int): Long {
        var value = 0L
        for (i in 0 until bytes) {
            val b = get(position + i)
            if (b < 0) return -1
            value = (value shl 8) or b.toLong()
        }
        return value
    }

    /** Unsigned little endian value, or -1 if it does not fit inside the data. */
    fun littleEndian(position: Long, bytes: Int): Long {
        var value = 0L
        for (i in 0 until bytes) {
            val b = get(position + i)
            if (b < 0) return -1
            value = value or (b.toLong() shl (8 * i))
        }
        return value
    }
}

/** Reads a file through a 128 KB window, so scanning large files stays cheap. */
class FileByteSource(private val file: RandomAccessFile) : ByteSource {
    override val length: Long = file.length()
    private val window = ByteArray(128 * 1024)
    private var windowStart = 0L
    private var windowSize = 0

    override fun get(position: Long): Int {
        if (position < 0 || position >= length) return -1
        if (position < windowStart || position >= windowStart + windowSize) load(position)
        val index = (position - windowStart).toInt()
        return if (index < windowSize) window[index].toInt() and 0xFF else -1
    }

    private fun load(position: Long) {
        windowStart = position
        file.seek(position)
        var total = 0
        while (total < window.size) {
            val count = file.read(window, total, window.size - total)
            if (count < 0) break
            total += count
        }
        windowSize = total
    }
}

class ArrayByteSource(private val data: ByteArray) : ByteSource {
    override val length: Long get() = data.size.toLong()

    override fun get(position: Long): Int =
        if (position < 0 || position >= data.size) -1 else data[position.toInt()].toInt() and 0xFF
}
