package com.mustafa.photorecovery

/** Builds the exported scan report (CSV or JSON) as plain text. Pure Kotlin, no Android types. */
object ReportWriter {
    data class Row(
        val name: String,
        val source: String,
        val format: String,
        val width: Int,
        val height: Int,
        val bytes: Long,
        val integrity: String
    )

    /** Values the app only knows for the scan that just ran are null after a restart. */
    data class Summary(
        val appVersion: String,
        val generatedAtMillis: Long,
        val scanDurationMillis: Long?,
        val scannedFiles: Int?,
        val errors: Int?
    )

    private const val CSV_HEADER = "name,source,format,width,height,bytes,integrity"

    fun csv(rows: List<Row>): String {
        val out = StringBuilder(CSV_HEADER).append('\n')
        for (row in rows) {
            out.append(csvField(row.name)).append(',')
                .append(csvField(row.source)).append(',')
                .append(csvField(row.format)).append(',')
                .append(row.width).append(',')
                .append(row.height).append(',')
                .append(row.bytes).append(',')
                .append(csvField(row.integrity)).append('\n')
        }
        return out.toString()
    }

    /**
     * Quotes a field when needed. A value that starts with = + - or @ is prefixed with an
     * apostrophe, because spreadsheet programs would otherwise run it as a formula.
     */
    fun csvField(value: String): String {
        val safe = if (value.isNotEmpty() && value[0] in "=+-@") "'$value" else value
        val needsQuotes = safe.any { it == ',' || it == '"' || it == '\n' || it == '\r' }
        return if (needsQuotes) "\"" + safe.replace("\"", "\"\"") + "\"" else safe
    }

    fun jsonString(value: String): String {
        val out = StringBuilder("\"")
        for (c in value) {
            when {
                c == '"' -> out.append("\\\"")
                c == '\\' -> out.append("\\\\")
                c == '\n' -> out.append("\\n")
                c == '\r' -> out.append("\\r")
                c == '\t' -> out.append("\\t")
                c < ' ' -> out.append("\\u").append("%04x".format(c.code))
                else -> out.append(c)
            }
        }
        return out.append('"').toString()
    }

    private fun counts(values: List<String>): String =
        values.groupingBy { it }.eachCount().toSortedMap().entries
            .joinToString(",\n") { "    ${jsonString(it.key)}: ${it.value}" }

    fun json(summary: Summary, rows: List<Row>): String {
        val out = StringBuilder("{\n")
        out.append("  \"app_version\": ").append(jsonString(summary.appVersion)).append(",\n")
        out.append("  \"generated_at_millis\": ").append(summary.generatedAtMillis).append(",\n")
        out.append("  \"scan_duration_millis\": ").append(summary.scanDurationMillis ?: "null").append(",\n")
        out.append("  \"scanned_files\": ").append(summary.scannedFiles ?: "null").append(",\n")
        out.append("  \"errors\": ").append(summary.errors ?: "null").append(",\n")
        out.append("  \"total_photos\": ").append(rows.size).append(",\n")
        out.append("  \"total_bytes\": ").append(rows.sumOf { it.bytes }).append(",\n")
        out.append("  \"by_source\": {\n").append(counts(rows.map { it.source })).append("\n  },\n")
        out.append("  \"by_integrity\": {\n").append(counts(rows.map { it.integrity })).append("\n  },\n")
        out.append("  \"photos\": [")
        rows.forEachIndexed { index, row ->
            out.append(if (index == 0) "\n" else ",\n")
            out.append("    {")
                .append("\"name\": ").append(jsonString(row.name)).append(", ")
                .append("\"source\": ").append(jsonString(row.source)).append(", ")
                .append("\"format\": ").append(jsonString(row.format)).append(", ")
                .append("\"width\": ").append(row.width).append(", ")
                .append("\"height\": ").append(row.height).append(", ")
                .append("\"bytes\": ").append(row.bytes).append(", ")
                .append("\"integrity\": ").append(jsonString(row.integrity))
                .append("}")
        }
        out.append(if (rows.isEmpty()) "]\n" else "\n  ]\n")
        out.append("}\n")
        return out.toString()
    }
}
