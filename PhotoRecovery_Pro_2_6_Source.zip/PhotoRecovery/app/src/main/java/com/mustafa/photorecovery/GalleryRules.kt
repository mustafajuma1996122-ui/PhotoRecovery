package com.mustafa.photorecovery

import kotlin.math.abs

/** Decides whether a candidate looks like a photo that is still in the gallery. Pure Kotlin. */
object GalleryRules {
    /** Hash of one view (a rotation, or its centre square) of a picture; shape is width / height. */
    data class View(val hash: Long, val shape: Double)

    /**
     * Lookups use a [HammingIndex], so the cost does not grow with the size of the gallery
     * the way a comparison against every stored view would.
     */
    class Index(views: List<View>, private val threshold: Int = 4) {
        private val kept = views.filter { distinctive(it.hash) }
        private val lookup = HammingIndex(threshold).also { index -> kept.forEach { index.add(it.hash) } }

        fun contains(candidate: View): Boolean = distinctive(candidate.hash) &&
            lookup.anyWithin(candidate.hash) { id ->
                abs(kept[id].shape - candidate.shape) / candidate.shape < 0.06
            }
    }

    /** Nearly flat pictures share trivial hashes, so they are never matched. */
    private fun distinctive(hash: Long) = java.lang.Long.bitCount(hash) in 4..60
}
