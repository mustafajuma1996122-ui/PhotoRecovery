package com.mustafa.photorecovery

import android.content.ContentValues
import android.content.Context
import android.graphics.BitmapFactory
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.documentfile.provider.DocumentFile
import java.io.File

/** Why a restore succeeded or failed. The name is written to the restore history. */
enum class RestoreOutcome {
    SUCCESS,
    SOURCE_MISSING,
    NOT_AN_IMAGE,
    WRITE_FAILED,

    /** The copy was written but its size differs from the source, so it was removed. */
    VERIFY_FAILED
}

object Restorer {
    private class VerificationFailed : Exception()

    fun extensionFor(mime: String) = ImageFormat.fromMime(mime)?.extension ?: "jpg"

    /** The folder chosen by the user, or null for Pictures/Recovered. */
    fun destination(context: Context): Uri? =
        context.getSharedPreferences("photo_recovery", Context.MODE_PRIVATE)
            .getString("dest_tree_uri", null)?.let { Uri.parse(it) }

    private fun copyToTree(context: Context, tree: Uri, source: File, mime: String, name: String) {
        val folder = DocumentFile.fromTreeUri(context, tree) ?: throw IllegalStateException("no folder")
        val target = folder.createFile(mime, name) ?: throw IllegalStateException("cannot create file")
        try {
            val output = context.contentResolver.openOutputStream(target.uri)
                ?: throw IllegalStateException("cannot open file")
            output.use { out -> source.inputStream().use { it.copyTo(out) } }
            if (target.length() != source.length()) throw VerificationFailed()
        } catch (e: Exception) {
            target.delete()
            throw e
        }
    }

    private fun copyToMediaStore(context: Context, source: File, mime: String, name: String) {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, mime)
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Recovered")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("restore failed")
        try {
            val output = resolver.openOutputStream(uri) ?: throw IllegalStateException("restore failed")
            output.use { out ->
                source.inputStream().use { it.copyTo(out) }
            }
            // The length is -1 when the provider cannot tell; then there is nothing to compare.
            val stored = resolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
            if (stored >= 0 && stored != source.length()) throw VerificationFailed()
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
    }

    private fun copyToPictures(context: Context, source: File, name: String) {
        val dir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
            "Recovered"
        )
        if (!dir.exists() && !dir.mkdirs()) throw IllegalStateException("restore failed")
        val target = source.copyTo(File(dir, name), overwrite = false)
        if (target.length() != source.length()) {
            target.delete()
            throw VerificationFailed()
        }
        MediaScannerConnection.scanFile(context, arrayOf(target.path), null, null)
    }

    fun restore(context: Context, photo: Photo): Boolean =
        restoreDetailed(context, photo) == RestoreOutcome.SUCCESS

    /* ينسخ الصورة إلى Pictures/Recovered دون تعديل الأصل، ثم يتحقق من حجم النسخة */
    fun restoreDetailed(context: Context, photo: Photo): RestoreOutcome {
        if (!photo.file.exists() || !photo.file.isFile || !photo.file.canRead() || photo.size < 16) {
            return finish(context, photo, RestoreOutcome.SOURCE_MISSING)
        }
        val repaired = tryRepairJpegEndMarker(context, photo.file)
        val sourceFile = repaired ?: photo.file
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        try { BitmapFactory.decodeFile(sourceFile.path, bounds) } catch (_: Exception) { }
        val mime = detectMime(sourceFile)
        val heifValid = if (mime == "image/heic" && Build.VERSION.SDK_INT >= 28 &&
            (bounds.outWidth <= 0 || bounds.outHeight <= 0)) decodeHeifForValidation(sourceFile) else false
        if ((bounds.outWidth <= 0 || bounds.outHeight <= 0) && !heifValid || !mime.startsWith("image/")) {
            repaired?.delete()
            return finish(context, photo, RestoreOutcome.NOT_AN_IMAGE)
        }
        val name = "recovered_${System.currentTimeMillis()}_${System.nanoTime()}.${extensionFor(mime)}"
        val outcome = try {
            val tree = destination(context)
            if (tree != null) {
                copyToTree(context, tree, sourceFile, mime, name)
            } else if (Build.VERSION.SDK_INT >= 29) {
                copyToMediaStore(context, sourceFile, mime, name)
            } else {
                copyToPictures(context, sourceFile, name)
            }
            RestoreOutcome.SUCCESS
        } catch (_: VerificationFailed) {
            RestoreOutcome.VERIFY_FAILED
        } catch (_: Exception) {
            RestoreOutcome.WRITE_FAILED
        }
        repaired?.delete()
        return finish(context, photo, outcome)
    }

    private fun finish(context: Context, photo: Photo, outcome: RestoreOutcome): RestoreOutcome {
        recordHistory(context, photo, outcome)
        return outcome
    }

    /**
     * Limited JPEG repair: if the decoder cannot read dimensions, try a temporary
     * copy with a missing EOI marker appended. The original candidate is never modified.
     */
    private fun tryRepairJpegEndMarker(context: Context, source: File): File? {
        return try {
            if (ImageSignatures.detect(source) != ImageFormat.JPEG) return null

            val originalBounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(source.path, originalBounds)
            if (originalBounds.outWidth > 0 && originalBounds.outHeight > 0) return null

            val temp = File.createTempFile("jpeg_repair_", ".jpg", context.cacheDir)
            source.inputStream().use { input ->
                temp.outputStream().use { output ->
                    input.copyTo(output, 64 * 1024)
                    output.write(byteArrayOf(0xFF.toByte(), 0xD9.toByte()))
                }
            }
            val repairedBounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(temp.path, repairedBounds)
            if (repairedBounds.outWidth > 0 && repairedBounds.outHeight > 0) temp else {
                temp.delete()
                null
            }
        } catch (_: Exception) { null }
    }

    private fun decodeHeifForValidation(file: File): Boolean {
        return try {
            val source = android.graphics.ImageDecoder.createSource(file)
            val bitmap = android.graphics.ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                if (info.size.width <= 0 || info.size.height <= 0 ||
                    info.size.width > 100_000 || info.size.height > 100_000) {
                    throw IllegalArgumentException("bad HEIF size")
                }
                decoder.setTargetSampleSize(16)
                decoder.setAllocator(android.graphics.ImageDecoder.ALLOCATOR_SOFTWARE)
            }
            bitmap.recycle()
            true
        } catch (_: Exception) { false }
    }

    private fun recordHistory(context: Context, photo: Photo, outcome: RestoreOutcome) {
        try {
            val prefs = context.getSharedPreferences("photo_recovery_history", Context.MODE_PRIVATE)
            val old = prefs.getString("entries", "").orEmpty()
            val time = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault())
                .format(java.util.Date())
            val success = outcome == RestoreOutcome.SUCCESS
            val state = context.getString(if (success) R.string.success else R.string.failure)
            val reason = if (success) "" else " (${outcome.name})"
            val entry = "$time | $state$reason | ${photo.file.name} | ${context.getString(photo.source.label)}"
            val entries = (old.lines().filter { it.isNotBlank() } + entry).takeLast(100)
            prefs.edit().putString("entries", entries.joinToString("\n")).apply()
        } catch (_: Exception) {
            // History must never interrupt a restore operation.
        }
    }

    fun detectMime(f: File): String {
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, options)
        val decodedMime = options.outMimeType?.lowercase()
        if (decodedMime?.startsWith("image/") == true) {
            return if (decodedMime == "image/heif") "image/heic" else decodedMime
        }
        // BitmapFactory support varies by Android release; use validated file signatures as fallback.
        return ImageSignatures.detect(f)?.mime ?: "application/octet-stream"
    }
}
