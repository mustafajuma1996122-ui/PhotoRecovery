package com.mustafa.photorecovery

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import java.io.File
import java.util.concurrent.Executors

/** Keeps results and long running work alive when the screen is recreated. Main thread only. */
object ScanStore {
    val results = ArrayList<Photo>()
    val selected = HashSet<Photo>()
    var running = false
        private set
    var restoring = false
        private set
    var failed = false
        private set
    var finished = false
        private set
    var restoreSummary: Pair<Int, Int>? = null
        private set

    /** Argument is true when the result list or the state changed, false for progress only. */
    var listener: ((Boolean) -> Unit)? = null
    var serviceListener: (() -> Unit)? = null

    private var scanner: Scanner? = null
    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    val busy get() = running || restoring
    private var loaded = false

    /** Restores the results of the previous session once per process. */
    fun load(context: Context) {
        if (loaded || busy) return
        loaded = true
        results.addAll(ResultsRepository.load(context.applicationContext))
        finished = results.isNotEmpty()
    }
    val limitReached get() = scanner?.limitReached == true
    val elapsedSeconds get() = (System.currentTimeMillis() - scanStartedAt) / 1000
    val cancelled get() = scanner?.cancelled == true
    val scannedFiles get() = scanner?.scannedFiles ?: 0

    /** Files skipped because of read errors in the latest scan of this session, or null. */
    val scanErrors: Int? get() = scanner?.errorCount

    /** Duration of the latest scan of this session in milliseconds, or null. */
    var lastScanMillis: Long? = null
        private set
    private var scanStartedAt = 0L
    val currentFolder get() = scanner?.currentFolder.orEmpty()

    fun cancel() {
        scanner?.cancelled = true
    }

    private fun notifyChanged(full: Boolean) {
        listener?.invoke(full)
        serviceListener?.invoke()
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (!running) return
            notifyChanged(false)
            main.postDelayed(this, 800)
        }
    }

    fun start(context: Context, treeUri: Uri?) {
        if (busy) return
        loaded = true
        val app = context.applicationContext
        ResultsRepository.save(app, emptyList())
        results.clear()
        selected.clear()
        restoreSummary = null
        running = true
        failed = false
        finished = false
        lastScanMillis = null
        scanStartedAt = System.currentTimeMillis()
        val pending = ArrayList<Photo>()
        var last = 0L
        fun flush() {
            val batch = ArrayList(pending)
            pending.clear()
            main.post {
                results.addAll(batch)
                notifyChanged(true)
            }
        }
        val current = Scanner(app) {
            pending.add(it)
            val now = System.currentTimeMillis()
            if (now - last > 700) {
                last = now
                flush()
            }
        }
        scanner = current
        notifyChanged(true)
        main.postDelayed(ticker, 800)
        worker.execute {
            val ok = try { current.scan(treeUri); true } catch (_: Throwable) { false }
            flush()
            main.post {
                ResultsRepository.save(app, results)
                lastScanMillis = System.currentTimeMillis() - scanStartedAt
                running = false
                finished = true
                failed = !ok
                notifyChanged(true)
            }
        }
    }

    fun restore(context: Context, photos: List<Photo>) {
        if (busy || photos.isEmpty()) return
        val app = context.applicationContext
        restoring = true
        restoreSummary = null
        notifyChanged(true)
        worker.execute {
            val done = photos.count { try { Restorer.restore(app, it) } catch (_: Throwable) { false } }
            main.post {
                restoring = false
                selected.clear()
                restoreSummary = done to (photos.size - done)
                notifyChanged(true)
            }
        }
    }

    fun clearTemporary(context: Context) {
        if (busy) return
        val directory = Scanner.temporaryDirectory(context)
        val prefix = directory.absolutePath + File.separator
        results.removeAll { it.file.absolutePath.startsWith(prefix) }
        selected.retainAll(results.toHashSet())
        directory.deleteRecursively()
        File(context.cacheDir, "share").deleteRecursively()
        ResultsRepository.save(context.applicationContext, results)
        notifyChanged(true)
    }
}
