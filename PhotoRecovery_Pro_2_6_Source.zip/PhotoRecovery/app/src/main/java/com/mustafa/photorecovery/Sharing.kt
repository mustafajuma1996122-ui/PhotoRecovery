package com.mustafa.photorecovery

import android.app.Activity
import android.content.ClipData
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import kotlin.concurrent.thread

object Sharing {
    private const val LIMIT = 30

    /** Shares one file that already lives in cache/share (see share_paths.xml). */
    fun shareFile(activity: Activity, file: File, mime: String, title: String) {
        try {
            val uri = FileProvider.getUriForFile(activity, "${activity.packageName}.files", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mime
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = ClipData.newRawUri(file.name, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            activity.startActivity(Intent.createChooser(intent, title))
        } catch (_: Exception) {
            Toast.makeText(activity, R.string.share_failed, Toast.LENGTH_LONG).show()
        }
    }

    /** Shares private copies, so the receiving app never gets access to other files. */
    fun share(activity: Activity, photos: List<Photo>) {
        if (photos.isEmpty() || photos.size > LIMIT) {
            Toast.makeText(activity, activity.getString(R.string.share_limit, LIMIT), Toast.LENGTH_LONG).show()
            return
        }
        thread {
            try {
                val directory = File(activity.cacheDir, "share")
                directory.mkdirs()
                // Old copies are removed after a day, so a running share is not interrupted.
                val expired = System.currentTimeMillis() - 24L * 60 * 60 * 1000
                directory.listFiles()?.filter { it.lastModified() < expired }?.forEach { it.delete() }
                val uris = ArrayList<Uri>()
                photos.forEachIndexed { index, photo ->
                    val extension = Restorer.extensionFor(Restorer.detectMime(photo.file))
                    val copy = File(directory, "photo_${System.nanoTime()}_$index.$extension")
                    photo.file.copyTo(copy, overwrite = true)
                    uris.add(FileProvider.getUriForFile(activity, "${activity.packageName}.files", copy))
                }
                activity.runOnUiThread {
                    if (activity.isDestroyed) return@runOnUiThread
                    val clip = ClipData.newRawUri("photos", uris[0])
                    uris.drop(1).forEach { clip.addItem(ClipData.Item(it)) }
                    val intent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                        type = "image/*"
                        putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                        clipData = clip
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    activity.startActivity(Intent.createChooser(intent, activity.getString(R.string.share)))
                }
            } catch (_: Exception) {
                activity.runOnUiThread {
                    Toast.makeText(activity, R.string.share_failed, Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}
