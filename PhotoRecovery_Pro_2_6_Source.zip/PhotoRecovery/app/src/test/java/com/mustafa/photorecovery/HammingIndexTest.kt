package com.mustafa.photorecovery

import java.util.Random
import kotlin.math.abs
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class HammingIndexTest {
    private fun brute(values: List<Long>, query: Long, distance: Int): List<Int> =
        values.indices.filter { java.lang.Long.bitCount(values[it] xor query) <= distance }

    /** A value that differs from [base] in exactly [bits] random positions. */
    private fun flipped(random: Random, base: Long, bits: Int): Long {
        var value = base
        val positions = HashSet<Int>()
        while (positions.size < bits) positions.add(random.nextInt(64))
        positions.forEach { value = value xor (1L shl it) }
        return value
    }

    @Test fun matchesBruteForceForEveryDistance() {
        for (distance in 0..8) {
            val random = Random(1000L + distance)
            val values = ArrayList<Long>()
            repeat(300) { values.add(random.nextLong()) }
            // Near copies, some inside and some just outside the distance.
            for (i in 0 until 150) values.add(flipped(random, values[i], random.nextInt(distance + 3)))
            val index = HammingIndex(distance)
            values.forEach { index.add(it) }
            val queries = values.take(200) + List(100) { random.nextLong() }
            for (query in queries) {
                assertEquals("distance $distance", brute(values, query, distance), index.within(query))
                assertEquals(brute(values, query, distance).isNotEmpty(), index.anyWithin(query))
            }
        }
    }

    @Test fun exactMatchOnlyWithDistanceZero() {
        val index = HammingIndex(0)
        index.add(0x1234L)
        assertTrue(index.anyWithin(0x1234L))
        assertFalse(index.anyWithin(0x1235L))
    }

    @Test fun acceptPredicateDecidesTheResult() {
        val index = HammingIndex(2)
        val first = index.add(0xFF00L)
        val second = index.add(0xFF01L)
        assertTrue(index.anyWithin(0xFF00L) { it == second })
        assertFalse(index.anyWithin(0xFF00L) { it == 99 })
        assertEquals(listOf(first, second), index.within(0xFF00L))
        assertEquals(0xFF01L, index.hashOf(second))
        assertEquals(2, index.size)
    }

    @Test fun distanceOutOfRangeIsRejected() {
        for (bad in listOf(-1, 64)) {
            try {
                HammingIndex(bad)
                fail("expected IllegalArgumentException for $bad")
            } catch (_: IllegalArgumentException) {
                // expected
            }
        }
    }

    @Test fun galleryIndexAgreesWithTheDirectComparison() {
        val random = Random(77)
        val views = List(500) { GalleryRules.View(random.nextLong(), 0.5 + random.nextDouble()) }
        val index = GalleryRules.Index(views)
        fun distinctive(hash: Long) = java.lang.Long.bitCount(hash) in 4..60
        val candidates = views.take(200).map {
            GalleryRules.View(flipped(random, it.hash, random.nextInt(8)), it.shape * (0.9 + random.nextDouble() * 0.2))
        } + List(100) { GalleryRules.View(random.nextLong(), 0.5 + random.nextDouble()) }
        for (candidate in candidates) {
            val expected = distinctive(candidate.hash) && views.any {
                distinctive(it.hash) &&
                    java.lang.Long.bitCount(it.hash xor candidate.hash) <= 4 &&
                    abs(it.shape - candidate.shape) / candidate.shape < 0.06
            }
            assertEquals(expected, index.contains(candidate))
        }
    }
}
