package com.mustafa.photorecovery

import java.util.Random
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Random and damaged input must never crash the carver, and every hit it reports must lie inside
 * the data. The seeds are fixed, so a failure can be reproduced.
 */
class CarverFuzzTest {
    private val maxSize = 20_000L

    private val samples = listOf(
        TestFixtures.jpeg, TestFixtures.png, TestFixtures.gif, TestFixtures.webpLossless,
        TestFixtures.webpLossy, TestFixtures.bmp, TestFixtures.heic()
    )

    private fun carve(data: ByteArray): List<Carver.Hit> {
        val hits = ArrayList<Carver.Hit>()
        Carver.scan(ArrayByteSource(data), maxSize) { hits.add(it) }
        return hits
    }

    private fun assertSane(data: ByteArray, hits: List<Carver.Hit>) {
        for ((number, hit) in hits.withIndex()) {
            assertTrue("start ${hit.start}", hit.start in 0 until data.size.toLong())
            assertTrue("end ${hit.end}", hit.end > hit.start && hit.end <= data.size)
            // The JPEG parser checks the limit before it reads the end marker, hence the slack.
            assertTrue("size ${hit.size}", hit.size <= maxSize + 2)
            if (!hit.truncated) {
                // Nothing found later may start inside a complete image.
                for (later in hits.drop(number + 1)) assertTrue(later.start >= hit.end)
            }
            // The analyzer must cope with whatever the carver finds.
            IntegrityAnalyzer.analyze(data.copyOfRange(hit.start.toInt(), hit.end.toInt()))
        }
    }

    @Test fun randomBytesNeverCrashTheCarver() {
        for (seed in 0 until 150) {
            val random = Random(seed.toLong())
            val data = ByteArray(random.nextInt(8000)).also { random.nextBytes(it) }
            assertSane(data, carve(data))
        }
    }

    @Test fun damagedImagesNeverCrashTheCarver() {
        for (seed in 0 until 300) {
            val random = Random(10_000L + seed)
            val data = ByteArray(2000 + random.nextInt(4000)).also { random.nextBytes(it) }
            repeat(random.nextInt(4)) {
                val sample = samples[random.nextInt(samples.size)]
                val at = random.nextInt(data.size - sample.size.coerceAtMost(data.size - 1))
                System.arraycopy(sample, 0, data, at, minOf(sample.size, data.size - at))
            }
            repeat(random.nextInt(8)) { data[random.nextInt(data.size)] = random.nextInt(256).toByte() }
            val cut = if (random.nextInt(3) == 0) data.copyOf(random.nextInt(data.size)) else data
            assertSane(cut, carve(cut))
        }
    }

    @Test fun undamagedImagesAreAlwaysFoundAtTheirOffsets() {
        for ((number, sample) in samples.withIndex()) {
            for (offset in listOf(0, 1, 3, 4, 5, 77, 4096)) {
                val data = TestFixtures.concat(TestFixtures.padding(offset), sample, TestFixtures.padding(20))
                val hits = carve(data)
                assertEquals("sample $number at $offset", 1, hits.size)
                assertEquals(offset.toLong(), hits[0].start)
                assertEquals(offset.toLong() + sample.size, hits[0].end)
            }
        }
    }
}
