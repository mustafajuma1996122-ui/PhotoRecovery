package com.mustafa.photorecovery

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ResultCodecCompatTest {
    @Test fun linesFromOlderVersionsAreStillRead() {
        val entry = ResultCodec.decode("CARVED\t640\t480\t/data/carved/a.jpg")
        assertEquals(ResultCodec.Entry("CARVED", 640, 480, "/data/carved/a.jpg", "UNKNOWN"), entry)
    }

    @Test fun olderLinesKeepTabsInThePath() {
        val entry = ResultCodec.decode("FOLDER\t1\t2\t/a/b\tc.jpg")
        assertEquals("/a/b\tc.jpg", entry?.path)
        assertEquals("UNKNOWN", entry?.integrity)
    }

    @Test fun integrityIsStoredAndRestored() {
        val entry = ResultCodec.Entry("HIDDEN", 10, 20, "/x/y\tz.png", "PARTIAL")
        val line = ResultCodec.encode(entry)!!
        assertEquals("HIDDEN\t10\t20\tPARTIAL\t/x/y\tz.png", line)
        assertEquals(entry, ResultCodec.decode(line))
    }

    @Test fun everyIntegrityValueRoundTrips() {
        for (integrity in Integrity.values()) {
            val entry = ResultCodec.Entry("CARVED", 1, 1, "/p.jpg", integrity.name)
            assertEquals(entry, ResultCodec.decode(ResultCodec.encode(entry)!!))
        }
    }

    @Test fun damagedLinesAreRejected() {
        assertNull(ResultCodec.decode(""))
        assertNull(ResultCodec.decode("CARVED\t1\t2"))
        assertNull(ResultCodec.decode("CARVED\tx\t2\tPARTIAL\t/a.jpg"))
        assertNull(ResultCodec.decode("CARVED\t1\t2\tPARTIAL\t"))
    }
}
