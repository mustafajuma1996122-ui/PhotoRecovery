package com.mustafa.photorecovery

import java.util.Random
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class IntegrityAnalyzerTest {
    private fun assertComplete(format: ImageFormat, data: ByteArray) {
        val report = IntegrityAnalyzer.analyze(data)
        assertEquals(format, report.format)
        assertEquals(Integrity.COMPLETE, report.integrity)
        assertEquals(16, report.width)
        assertEquals(12, report.height)
        assertTrue(report.issues.isEmpty())
    }

    @Test fun realFilesAreComplete() {
        assertComplete(ImageFormat.JPEG, TestFixtures.jpeg)
        assertComplete(ImageFormat.PNG, TestFixtures.png)
        assertComplete(ImageFormat.GIF, TestFixtures.gif)
        assertComplete(ImageFormat.WEBP, TestFixtures.webpLossless)
        assertComplete(ImageFormat.WEBP, TestFixtures.webpLossy)
        assertComplete(ImageFormat.BMP, TestFixtures.bmp)
    }

    @Test fun jpegWithoutEndMarkerIsPartial() {
        val report = IntegrityAnalyzer.analyze(TestFixtures.dropLast(TestFixtures.jpeg, 2))
        assertEquals(Integrity.PARTIAL, report.integrity)
        assertTrue(Issue.NO_END_MARKER in report.issues)
        assertEquals(16, report.width)
    }

    @Test fun jpegCutInsideTheHeaderIsDamaged() {
        val report = IntegrityAnalyzer.analyze(TestFixtures.jpeg.copyOf(30))
        assertEquals(Integrity.DAMAGED, report.integrity)
        assertTrue(Issue.NO_IMAGE_DATA in report.issues)
    }

    @Test fun jpegWithTrailingBytesIsStillComplete() {
        val report = IntegrityAnalyzer.analyze(TestFixtures.concat(TestFixtures.jpeg, ByteArray(40)))
        assertEquals(Integrity.COMPLETE, report.integrity)
        assertTrue(Issue.TRAILING_DATA in report.issues)
    }

    @Test fun pngChecksumMismatchIsDamaged() {
        val data = TestFixtures.png.copyOf()
        // Flip a byte inside the IDAT data; the chunk checksum no longer matches.
        var position = 0
        while (position < data.size - 4 && String(data, position, 4, Charsets.US_ASCII) != "IDAT") position++
        data[position + 6] = (data[position + 6].toInt() xor 0xFF).toByte()
        val report = IntegrityAnalyzer.analyze(data)
        assertEquals(Integrity.DAMAGED, report.integrity)
        assertTrue(Issue.BAD_CRC in report.issues)
    }

    @Test fun pngWithoutIendIsPartial() {
        val report = IntegrityAnalyzer.analyze(TestFixtures.dropLast(TestFixtures.png, 12))
        assertEquals(Integrity.PARTIAL, report.integrity)
        assertTrue(Issue.NO_END_MARKER in report.issues)
    }

    @Test fun pngCutInsideImageDataIsPartial() {
        val report = IntegrityAnalyzer.analyze(TestFixtures.dropLast(TestFixtures.png, 20))
        assertEquals(Integrity.PARTIAL, report.integrity)
        assertTrue(Issue.TRUNCATED in report.issues)
    }

    @Test fun gifWithoutTrailerIsPartial() {
        val report = IntegrityAnalyzer.analyze(TestFixtures.dropLast(TestFixtures.gif, 1))
        assertEquals(Integrity.PARTIAL, report.integrity)
    }

    @Test fun cutWebpAndBitmapArePartial() {
        assertEquals(Integrity.PARTIAL, IntegrityAnalyzer.analyze(TestFixtures.dropLast(TestFixtures.webpLossless, 10)).integrity)
        assertEquals(Integrity.PARTIAL, IntegrityAnalyzer.analyze(TestFixtures.dropLast(TestFixtures.bmp, 10)).integrity)
    }

    @Test fun otherDataIsUnknown() {
        assertEquals(Integrity.UNKNOWN, IntegrityAnalyzer.analyze(ByteArray(0)).integrity)
        assertEquals(Integrity.UNKNOWN, IntegrityAnalyzer.analyze(ByteArray(500) { 0x55 }).integrity)
        assertNull(IntegrityAnalyzer.analyze(ByteArray(500) { 0x55 }).format)
    }

    @Test fun heicIsRecognisedButNotJudged() {
        val report = IntegrityAnalyzer.analyze(TestFixtures.heic())
        assertEquals(ImageFormat.HEIC, report.format)
        assertEquals(Integrity.UNKNOWN, report.integrity)
    }

    @Test fun analysingDamagedDataNeverThrows() {
        val random = Random(2024)
        val samples = listOf(
            TestFixtures.jpeg, TestFixtures.png, TestFixtures.gif,
            TestFixtures.webpLossless, TestFixtures.webpLossy, TestFixtures.bmp
        )
        repeat(600) {
            val data = samples[random.nextInt(samples.size)].copyOf()
            repeat(1 + random.nextInt(6)) {
                data[random.nextInt(data.size)] = random.nextInt(256).toByte()
            }
            val cut = if (random.nextBoolean()) data else data.copyOf(random.nextInt(data.size + 1))
            // Only the absence of an exception and a sensible value are checked.
            val report = IntegrityAnalyzer.analyze(cut)
            assertTrue(report.width >= 0 && report.height >= 0)
        }
    }
}
