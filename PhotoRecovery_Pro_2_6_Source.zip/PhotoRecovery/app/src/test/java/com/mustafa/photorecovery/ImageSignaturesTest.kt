package com.mustafa.photorecovery

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ImageSignaturesTest {
    @Test fun recognisesEveryFormatFromRealFiles() {
        assertEquals(ImageFormat.JPEG, ImageSignatures.detect(TestFixtures.jpeg.copyOf(16)))
        assertEquals(ImageFormat.PNG, ImageSignatures.detect(TestFixtures.png.copyOf(16)))
        assertEquals(ImageFormat.GIF, ImageSignatures.detect(TestFixtures.gif.copyOf(16)))
        assertEquals(ImageFormat.WEBP, ImageSignatures.detect(TestFixtures.webpLossless.copyOf(16)))
        assertEquals(ImageFormat.WEBP, ImageSignatures.detect(TestFixtures.webpLossy.copyOf(16)))
        assertEquals(ImageFormat.BMP, ImageSignatures.detect(TestFixtures.bmp.copyOf(16)))
        assertEquals(ImageFormat.HEIC, ImageSignatures.detect(TestFixtures.heic().copyOf(16)))
    }

    @Test fun shortOrUnrelatedHeadersAreRejected() {
        assertNull(ImageSignatures.detect(ByteArray(0)))
        assertNull(ImageSignatures.detect(TestFixtures.jpeg.copyOf(11)))
        assertNull(ImageSignatures.detect(ByteArray(16) { 0x55 }))
        assertNull(ImageSignatures.detect(ByteArray(16)))
    }

    @Test fun bitmapNeedsReservedZeroBytes() {
        val header = TestFixtures.bmp.copyOf(16)
        header[6] = 1
        assertNull(ImageSignatures.detect(header))
    }

    @Test fun unknownHeifBrandIsRejected() {
        val header = TestFixtures.heic().copyOf(16)
        header[8] = 'x'.code.toByte()
        assertNull(ImageSignatures.detect(header))
    }

    @Test fun mimeTypesMapToFormats() {
        assertEquals(ImageFormat.JPEG, ImageFormat.fromMime("image/jpeg"))
        assertEquals(ImageFormat.HEIC, ImageFormat.fromMime("image/heif"))
        assertEquals(ImageFormat.PNG, ImageFormat.fromMime("IMAGE/PNG"))
        assertNull(ImageFormat.fromMime("application/octet-stream"))
        assertEquals("jpg", ImageFormat.JPEG.extension)
        assertEquals("image/webp", ImageFormat.WEBP.mime)
    }
}
