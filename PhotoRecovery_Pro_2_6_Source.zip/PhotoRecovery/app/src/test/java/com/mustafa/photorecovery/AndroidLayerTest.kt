package com.mustafa.photorecovery

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/** Tests of the Android layer that need a Context but no real image decoding. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [33])
class AndroidLayerTest {
    private val context: Context get() = ApplicationProvider.getApplicationContext()

    private fun sampleFile(name: String, bytes: ByteArray): File =
        File(context.filesDir, name).also { it.writeBytes(bytes) }

    @Test fun savedResultsKeepSourceAndIntegrity() {
        val file = sampleFile("a.jpg", ByteArray(64) { 1 })
        ResultsRepository.save(context, listOf(Photo(file, PhotoSource.CARVED, 10, 20, Integrity.PARTIAL)))
        val loaded = ResultsRepository.load(context)
        assertEquals(1, loaded.size)
        assertEquals(PhotoSource.CARVED, loaded[0].source)
        assertEquals(Integrity.PARTIAL, loaded[0].integrity)
        assertEquals(10, loaded[0].width)
    }

    @Test fun resultsWhoseFileIsGoneAreDropped() {
        val file = sampleFile("gone.jpg", ByteArray(64) { 1 })
        ResultsRepository.save(context, listOf(Photo(file, PhotoSource.HIDDEN, 1, 1)))
        file.delete()
        assertTrue(ResultsRepository.load(context).isEmpty())
    }

    @Test fun missingSourceIsReportedAndLogged() {
        val photo = Photo(File(context.filesDir, "missing.jpg"), PhotoSource.CARVED)
        assertEquals(RestoreOutcome.SOURCE_MISSING, Restorer.restoreDetailed(context, photo))
        val history = context.getSharedPreferences("photo_recovery_history", Context.MODE_PRIVATE)
            .getString("entries", "").orEmpty()
        assertTrue(history.contains("SOURCE_MISSING"))
    }

    @Test fun nonImageFileIsRejected() {
        val file = sampleFile("note.jpg", "this is plain text, not a picture".toByteArray())
        val outcome = Restorer.restoreDetailed(context, Photo(file, PhotoSource.HIDDEN))
        assertEquals(RestoreOutcome.NOT_AN_IMAGE, outcome)
    }
}
