package com.mustafa.photorecovery

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ReportWriterTest {
    private val rows = listOf(
        ReportWriter.Row("a.jpg", "CARVED", "jpg", 16, 12, 658, "COMPLETE"),
        ReportWriter.Row("b, \"quoted\".png", "FOLDER", "png", 8, 8, 100, "DAMAGED")
    )

    @Test fun csvHasHeaderAndOneLinePerPhoto() {
        val lines = ReportWriter.csv(rows).trimEnd().lines()
        assertEquals("name,source,format,width,height,bytes,integrity", lines[0])
        assertEquals("a.jpg,CARVED,jpg,16,12,658,COMPLETE", lines[1])
        assertEquals("\"b, \"\"quoted\"\".png\",FOLDER,png,8,8,100,DAMAGED", lines[2])
        assertEquals(3, lines.size)
    }

    @Test fun csvFieldBlocksSpreadsheetFormulas() {
        assertEquals("'=SUM(A1)", ReportWriter.csvField("=SUM(A1)"))
        assertEquals("'@cmd", ReportWriter.csvField("@cmd"))
        assertEquals("plain", ReportWriter.csvField("plain"))
        assertEquals("\"line\nbreak\"", ReportWriter.csvField("line\nbreak"))
    }

    @Test fun jsonStringEscapesSpecialCharacters() {
        assertEquals("\"a\\\"b\"", ReportWriter.jsonString("a\"b"))
        assertEquals("\"a\\\\b\"", ReportWriter.jsonString("a\\b"))
        assertEquals("\"x\\ny\\tz\"", ReportWriter.jsonString("x\ny\tz"))
        assertEquals("\"\\u0001\"", ReportWriter.jsonString("\u0001"))
        assertEquals("\"صورة\"", ReportWriter.jsonString("صورة"))
    }

    @Test fun jsonContainsTotalsAndCounts() {
        val json = ReportWriter.json(ReportWriter.Summary("2.4", 1000L, 5000L, 123, 2), rows)
        assertTrue(json.contains("\"app_version\": \"2.4\""))
        assertTrue(json.contains("\"scan_duration_millis\": 5000"))
        assertTrue(json.contains("\"scanned_files\": 123"))
        assertTrue(json.contains("\"errors\": 2"))
        assertTrue(json.contains("\"total_photos\": 2"))
        assertTrue(json.contains("\"total_bytes\": 758"))
        assertTrue(json.contains("\"CARVED\": 1"))
        assertTrue(json.contains("\"DAMAGED\": 1"))
        assertTrue(json.contains("\"name\": \"b, \\\"quoted\\\".png\""))
    }

    @Test fun unknownScanValuesAreWrittenAsNull() {
        val json = ReportWriter.json(ReportWriter.Summary("2.4", 1L, null, null, null), emptyList())
        assertTrue(json.contains("\"scan_duration_millis\": null"))
        assertTrue(json.contains("\"scanned_files\": null"))
        assertTrue(json.contains("\"total_photos\": 0"))
        assertTrue(json.contains("\"photos\": []"))
    }
}
