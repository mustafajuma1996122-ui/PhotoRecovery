package com.mustafa.photorecovery

import java.util.Base64

/**
 * Real files written by a standard image encoder (Pillow), each a 16x12 picture, so the tests
 * run against genuine encoder output and not only against hand made byte arrays.
 */
object TestFixtures {
    private fun decode(text: String): ByteArray = Base64.getDecoder().decode(text)

    /** JPEG 16x12, baseline, quality 60. */
    val jpeg: ByteArray = decode(
        "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAA0JCgsKCA0LCgsODg0PEyAVExISEyccHhcgLikxMC4pLSwzOko+MzZGNywtQFdBRkxOUlNSMj5aYVpQYEpRUk//2wBDAQ4ODhMREyYVFSZPNS01T09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0//wAARCAAMABADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDmbPR+ny1u2ej9Plrbs7WLj5a3bO1i4+WppVWY5Zmc9D//2Q=="
    )

    /** PNG 16x12, RGB. */
    val png: ByteArray = decode(
        "iVBORw0KGgoAAAANSUhEUgAAABAAAAAMCAIAAADkharWAAAAHUlEQVR4nGNkYGAQYOAkHrEwiHIyMJCARjWMFA0A9DEIvNcDTdIAAAAASUVORK5CYII="
    )

    /** GIF 16x12, one image. */
    val gif: ByteArray = decode(
        "R0lGODdhEAAMAIcAAPDn6uDn4dDn2PDS4eDS2NDSz8Dnz7DnxsDSxrDSvfC92OC9z9C9xsC9vbC9tPCoz+CoxtCovcCotLCoq6DnvZDntIDnq6DStJDSq4DSonDnonDSmaC9q5C9ooC9mXC9kKCoopComYCokHCoh2DnmVDnkEDnh2DSkFDSh0DSfjDnfjDSdWC9h1C9fkC9dTC9bCDndRDnbADnYyDSbBDSYwDSWiC9YxC9WgC9UWCoflCodUCobDCoYyCoWhCoUQCoSPCTxuCTvdCTtPB+veB+tNB+q8CTq7CTosB+orB+mfBptOBpq9BposBpmbBpkKCTmZCTkICTh6B+kJB+h4B+fnCTfnB+daBph5BpfoBpdXBpbGCTdVCTbECTY2B+bFB+Y0B+WjCTWjB+UWBpY1BpWkBpUTBpSCCTURCTSACTPyB+SBB+PwB+NiBpPxBpNgBpLfBUq+BUotBUmfA/ouA/mdA/kMBUkLBUh8A/h7A/fvAqmeAqkNAqh8AqfrAqdaBUfpBUdYBUbKA/dZA/bIA/Y3BUY3A/WqAqbJAqY4AqWnAqUfAVkOAVh9AVfvAAh+AAftAAdcAVdbAVbMAAbLAAY6AVY5AVWoAVUaAAWpAAUYAASHAVSHAAP2BUWlBUUUBUSGA/UVA/SEA/PzBUPzA/NmAqSFAqP0AqNjAqLSBUNhBULQBUJCA/LRA/JAA/GyAqJBAqGwAqEmAVP1AVNkAVLWAANlAALUAAJDAVJDAAGyAVGxAVEgAVCSAAEhAACQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACwAAAAAEAAMAAAI2wB/+eqV65atWpw0ZcJEaRKkR4547dKFi9YsWZsuWaokKVIjRotiwXqF6pSpUooSITrkpw+fPXpctWJFSlQoUIYIDRKUB08dOnNWqUo16pOnToUCAfpzx46cOHDeuGljpgyZMVqyYLnipAmTJUrYrFEjBswXL1aoTJGSBEkRIkPSoDkTpguXLVWiQHlyxIiQIEB++OjBY4eOHCNEhAAxQUIECA9w3LDxwkULFh88dODgoAGDBQpq0JixIgWKExsyYLiQAEEBAgNkxIChwkQJEhosVKBwwICAAAACAgA7"
    )

    /** WebP 16x12, lossless (VP8L). */
    val webpLossless: ByteArray = decode(
        "UklGRioAAABXRUJQVlA4TB4AAAAvD8ACALmM6H/sIqL/ASEB4YT/czV5ICYhJgC46i4="
    )

    /** WebP 16x12, lossy (VP8). */
    val webpLossy: ByteArray = decode(
        "UklGRkQAAABXRUJQVlA4IDgAAACwAQCdASoQAAwAAsBMJbACdAEOtXHUAP74lOhNNk2tYPmDtxoH7JwXfFyyz+/Qwv/EokGpWIAAAA=="
    )

    /** BMP 16x12, 24 bit. */
    val bmp: ByteArray = decode(
        "Qk12AgAAAAAAADYAAAAoAAAAEAAAAAwAAAABABgAAAAAAEACAADEDgAAxA4AAAAAAAAAAAAAY+cAbOcQdecgfucwh+dAkOdQmedgoudwq+eAtOeQveegxuewz+fA2OfQ4efg6ufwWtIAY9IQbNIgddIwftJAh9JQkNJgmdJwotKAq9KQtNKgvdKwxtLAz9LQ2NLg4dLwUb0AWr0QY70gbL0wdb1Afr1Qh71gkL1wmb2Aor2Qq72gtL2wvb3Axr3Qz73g2L3wSKgAUagQWqggY6gwbKhAdahQfqhgh6hwkKiAmaiQoqigq6iwtKjAvajQxqjgz6jwP5MASJMQUZMgWpMwY5NAbJNQdZNgfpNwh5OAkJOQmZOgopOwq5PAtJPQvZPgxpPwNn4AP34QSH4gUX4wWn5AY35QbH5gdX5wfn6Ah36QkH6gmX6won7Aq37QtH7gvX7wLWkANmkQP2kgSGkwUWlAWmlQY2lgbGlwdWmAfmmQh2mgkGmwmWnAomnQq2ngtGnwJFQALVQQNlQgP1QwSFRAUVRQWlRgY1RwbFSAdVSQflSgh1SwkFTAmVTQolTgq1TwGz8AJD8QLT8gNj8wPz9ASD9QUT9gWj9wYz+AbD+QdT+gfj+whz/AkD/QmT/goj/wEioAGyoQJCogLSowNipAPypQSCpgUSpwWiqAYyqQbCqgdSqwfirAhyrQkCrgmSrwCRUAEhUQGxUgJBUwLRVANhVQPxVgSBVwURWAWhWQYxWgbBWwdRXAfhXQhxXgkBXwAAAACQAQEgAgGwAwJABALQBQNgBgPwBwSACAUQCQWgCgYwCwbADAdQDQfgDghwDw"
    )

    fun concat(vararg parts: ByteArray): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        parts.forEach { out.write(it) }
        return out.toByteArray()
    }

    /** Filler that contains none of the first bytes the carver looks for. */
    fun padding(size: Int): ByteArray = ByteArray(size) { 0x55 }

    fun uint32(value: Long): ByteArray = byteArrayOf(
        (value shr 24).toByte(), (value shr 16).toByte(), (value shr 8).toByte(), value.toByte()
    )

    /** An ISO base media file format box: size, four letter type, payload. */
    fun box(type: String, payload: ByteArray): ByteArray =
        concat(uint32(8L + payload.size), type.toByteArray(Charsets.US_ASCII), payload)

    /** A minimal HEIC container: ftyp, meta and mdat boxes. */
    fun heic(dataSize: Int = 400): ByteArray = concat(
        box("ftyp", concat("heic".toByteArray(), uint32(0), "mif1heic".toByteArray())),
        box("meta", ByteArray(40)),
        box("mdat", ByteArray(dataSize) { (it * 7 + 3).toByte() })
    )

    fun dropLast(data: ByteArray, count: Int): ByteArray = data.copyOf(data.size - count)
}
