package com.mustafa.photorecovery

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CarverFormatsTest {
    private val padding = TestFixtures.padding(100)

    private fun carve(data: ByteArray, maxSize: Long = 1_000_000, isCancelled: () -> Boolean = { false }): List<Carver.Hit> {
        val hits = ArrayList<Carver.Hit>()
        Carver.scan(ArrayByteSource(data), maxSize, isCancelled) { hits.add(it) }
        return hits
    }

    private fun assertFound(image: ByteArray, extension: String) {
        val hits = carve(TestFixtures.concat(padding, image, padding))
        assertEquals(listOf(Carver.Hit(100, 100L + image.size, extension)), hits)
    }

    @Test fun findsEveryFormatInsideNoise() {
        assertFound(TestFixtures.jpeg, "jpg")
        assertFound(TestFixtures.png, "png")
        assertFound(TestFixtures.gif, "gif")
        assertFound(TestFixtures.webpLossless, "webp")
        assertFound(TestFixtures.webpLossy, "webp")
        assertFound(TestFixtures.bmp, "bmp")
        assertFound(TestFixtures.heic(), "heic")
    }

    @Test fun findsImagesStoredBackToBack() {
        val heic = TestFixtures.heic()
        val data = TestFixtures.concat(
            padding, TestFixtures.jpeg, TestFixtures.png, TestFixtures.gif, padding, heic, TestFixtures.bmp
        )
        val extensions = carve(data).map { it.extension }
        assertEquals(listOf("jpg", "png", "gif", "heic", "bmp"), extensions)
    }

    @Test fun hitsAreContiguousWithTheirNeighbours() {
        val data = TestFixtures.concat(TestFixtures.png, TestFixtures.bmp)
        val hits = carve(data)
        assertEquals(2, hits.size)
        assertEquals(0L, hits[0].start)
        assertEquals(hits[0].end, hits[1].start)
        assertEquals(data.size.toLong(), hits[1].end)
    }

    @Test fun truncatedPngIsNotReported() {
        assertTrue(carve(TestFixtures.concat(padding, TestFixtures.dropLast(TestFixtures.png, 5), padding)).isEmpty())
    }

    @Test fun truncatedJpegIsReportedAsTruncated() {
        val cut = TestFixtures.dropLast(TestFixtures.jpeg, 2)
        val hits = carve(TestFixtures.concat(padding, cut))
        assertEquals(listOf(Carver.Hit(100, 100L + cut.size, "jpg", true)), hits)
    }

    @Test fun bitmapWithBrokenHeaderIsRejected() {
        val reserved = TestFixtures.bmp.copyOf()
        reserved[6] = 9
        assertTrue(carve(reserved).isEmpty())

        val headerSize = TestFixtures.bmp.copyOf()
        headerSize[14] = 41
        assertTrue(carve(headerSize).isEmpty())

        val declaredSize = TestFixtures.bmp.copyOf()
        declaredSize[2] = 0xFF.toByte()
        declaredSize[3] = 0xFF.toByte()
        assertTrue(carve(declaredSize).isEmpty())
    }

    @Test fun heicNeedsBothMetadataAndData() {
        val onlyMeta = TestFixtures.concat(
            padding,
            TestFixtures.box("ftyp", TestFixtures.concat("heic".toByteArray(), TestFixtures.uint32(0), "mif1".toByteArray())),
            TestFixtures.box("meta", ByteArray(40)),
            padding
        )
        assertTrue(carve(onlyMeta).isEmpty())
    }

    @Test fun heicWithUnknownBrandIsRejected() {
        val data = TestFixtures.heic().copyOf()
        data[8] = 'q'.code.toByte()
        assertTrue(carve(data).isEmpty())
    }

    @Test fun heicStopsAtTheFirstUnknownBox() {
        val heic = TestFixtures.heic()
        val unknown = TestFixtures.box("junk", ByteArray(30))
        val hits = carve(TestFixtures.concat(padding, heic, unknown))
        assertEquals(listOf(Carver.Hit(100, 100L + heic.size, "heic")), hits)
    }

    @Test fun imagesLargerThanTheLimitAreSkipped() {
        assertTrue(carve(TestFixtures.png, maxSize = TestFixtures.png.size - 1L).isEmpty())
        assertTrue(carve(TestFixtures.bmp, maxSize = TestFixtures.bmp.size - 1L).isEmpty())
        assertTrue(carve(TestFixtures.heic(), maxSize = TestFixtures.heic().size - 1L).isEmpty())
    }

    @Test fun cancellationStopsTheScan() {
        assertTrue(carve(TestFixtures.concat(padding, TestFixtures.png), isCancelled = { true }).isEmpty())
    }
}
