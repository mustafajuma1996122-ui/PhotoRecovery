# PhotoRecovery Pro — architecture

## Layers

```
 UI (Android)            MainActivity · PhotoAdapter · PreviewDialog · ZoomImageView
        │ listener
 State (Android)         ScanStore (results, selection, progress)   ScanService (foreground)
        │
 Pipeline (Android)      Scanner ── SafTree (folder listing) ── MediaStore (system trash)
        │                Restorer (copy + verify) · Sharing · ResultsRepository
        │
 Core (pure Kotlin)      Carver · IntegrityAnalyzer · ImageSignatures · ByteSource
                         HammingIndex · GalleryRules · DuplicateRules · PerceptualDuplicates
                         PhotoFilters · ResultCodec · ReportWriter
```

The core has no Android dependency, so it runs in plain JVM unit tests. Android classes only wire
the core to files, MediaStore and the screen.

## Scan pipeline

1. `Scanner` visits candidate locations: the system trash (Android 11+), then either the whole
   storage (full build) or the folder chosen by the user (store build / `SafTree`).
2. Only suspicious places are inspected (hidden, trash, thumbnail and cache paths). Files that decode
   as images are kept; large cache and thumbnail files are handed to the `Carver`.
3. `Carver` makes one pass over a file and follows the structure of every format, so an EXIF
   thumbnail does not end the outer JPEG and a stray `0x3B` byte does not end a GIF.
4. Each candidate must decode (`BitmapFactory` / `ImageDecoder`), must be new (SHA-256) and must fit
   the 512 MB temporary budget.
5. `IntegrityAnalyzer` classifies the candidate. A JPEG that the carver found cut off and closed with
   an added end marker is forced to `PARTIAL`, because the marker was not in the data.

## Carver

| Format | Boundaries are decided by |
|--------|---------------------------|
| JPEG | marker segments, entropy data skipping, `EOI`; a cut JPEG with scan data is reported `truncated` |
| PNG | chunk lengths up to `IEND` |
| GIF | block structure up to the trailer, at least one image |
| WebP | RIFF size |
| BMP | declared file size, zero reserved field, pixel offset, known DIB header size, sane dimensions |
| HEIC/HEIF | top-level boxes; needs `ftyp` with a known brand, `meta` and `mdat`; ends before the first unknown box |

A HEIC box starts four bytes before its `ftyp` signature, so the scan keeps a *floor* (the end of
the last complete image) and never starts a hit before it. Hits are never reported outside the data
and never exceed the size limit (the JPEG parser checks the limit before the end marker, so it can
exceed it by one byte; the fuzz test allows that).

## Integrity verdict

| Verdict | Meaning | Issues that cause it |
|---------|---------|----------------------|
| `COMPLETE` | all structural checks pass | none (`TRAILING_DATA` is informational) |
| `PARTIAL` | readable but cut off | `NO_END_MARKER`, `TRUNCATED` |
| `DAMAGED` | corrupt or without image data | `BAD_CRC`, `BAD_STRUCTURE`, `NO_FRAME_HEADER`, `NO_IMAGE_DATA` |
| `UNKNOWN` | not analysed (HEIC, unknown) | — |

Only critical PNG chunks (uppercase first letter) must have a valid CRC, as in libpng. The verdict
is a structural check, not proof that the pixels are correct: a flipped bit inside JPEG entropy
data is not detected.

## HammingIndex

Finding gallery photos that a candidate is a copy of needs "all 64-bit hashes within *d* bits".
The hash is cut into *d + 1* bands. If two hashes differ in at most *d* bits, at least one band is
identical (pigeonhole), so one hash-table lookup per band finds every true match; each candidate is
then verified with a popcount. `HammingIndexTest` compares the result with brute force for
*d* = 0..8.

## Restore

`Restorer.restoreDetailed` returns a `RestoreOutcome`. It repairs a missing JPEG end marker on a
temporary copy, writes to the chosen folder, to `Pictures/Recovered` (MediaStore, `IS_PENDING`) or to
the legacy directory, then compares the size of the written file with the source. A copy that fails
verification is deleted. The source candidate is never modified.

## Tests

- `TestFixtures` holds 16×12 files from a standard encoder, so parsers meet real output.
- `CarverFormatsTest`: every format, back-to-back images, truncation, limits, cancellation.
- `CarverFuzzTest`: random and damaged input; invariants on every hit; fixed seeds.
- `IntegrityAnalyzerTest`: complete / partial / damaged cases, CRC corruption, never throws.
- `HammingIndexTest`: equivalence with brute force, including the gallery index.
- `ReportWriterTest`, `ResultCodecCompatTest`, `ImageSignaturesTest` and the earlier tests.

Not covered by unit tests: `Scanner`, `Restorer`, `SafTree` and the UI, which need a device or
Robolectric.

## Known limits

- Permanently deleted photos cannot be recovered without root; the app finds what Android leaves
  in trash, hidden folders, caches and thumbnail databases.
- The integrity check is structural. HEIC is validated only by the system decoder.
- Android classes are verified on a device, not by unit tests.
