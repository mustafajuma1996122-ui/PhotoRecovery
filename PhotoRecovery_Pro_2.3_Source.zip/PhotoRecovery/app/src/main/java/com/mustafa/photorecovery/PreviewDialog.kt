package com.mustafa.photorecovery

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import com.google.android.material.button.MaterialButton
import java.util.concurrent.Executors

/** Full screen preview over a snapshot of the visible results. */
class PreviewDialog(
    private val activity: Activity,
    private val photos: List<Photo>,
    private var index: Int,
    private val isSelected: (Photo) -> Boolean,
    private val toggle: (Photo) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()

    fun show() {
        val dialog = Dialog(activity, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val image = ZoomImageView(activity)
        val info = TextView(activity).apply {
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            textSize = 13f
        }
        val selectButton = MaterialButton(activity)
        val shareButton = MaterialButton(activity).apply {
            text = activity.getString(R.string.share)
            setOnClickListener { Sharing.share(activity, listOf(photos[index])) }
        }
        val closeButton = MaterialButton(activity).apply {
            text = activity.getString(R.string.close)
            setOnClickListener { dialog.dismiss() }
        }

        fun render() {
            val photo = photos[index]
            info.text = "${index + 1} / ${photos.size}\n${describe(activity, photo)}\n${photo.file.name}"
            selectButton.text = activity.getString(
                if (isSelected(photo)) R.string.unselect else R.string.select_for_restore
            )
            val key = photo.file.absolutePath
            image.tag = key
            image.show(null)
            worker.execute {
                if (image.tag != key) return@execute
                val bitmap = ImageDecode.decode(photo.file, 2048)
                main.post { if (image.tag == key) image.show(bitmap) }
            }
        }

        selectButton.setOnClickListener {
            toggle(photos[index])
            render()
        }
        image.onSwipe = { toLeft ->
            val rtl = activity.resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_RTL
            val next = index + if (toLeft != rtl) 1 else -1
            if (next in photos.indices) {
                index = next
                render()
            }
        }
        val buttons = LinearLayout(activity).apply {
            gravity = Gravity.CENTER
            addView(selectButton)
            addView(shareButton, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { marginStart = activity.dp(12) })
            addView(closeButton, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { marginStart = activity.dp(12) })
        }
        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            addView(image, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(info)
            addView(buttons)
        }
        // The dialog theme is not a Material theme, so views are created with the activity context.
        dialog.setContentView(root)
        dialog.setOnDismissListener { worker.shutdownNow() }
        render()
        dialog.show()
    }
}
