package com.mustafa.photorecovery

import java.io.File
import java.io.RandomAccessFile

/**
 * Finds complete images embedded inside a larger file (cache, thumbnail database).
 * The structure of every format is followed, so an EXIF thumbnail does not end
 * the outer JPEG and a random 0x3B byte does not end a GIF. Pure Kotlin.
 */
object Carver {
    data class Hit(val start: Long, val end: Long, val extension: String, val truncated: Boolean = false) {
        val size: Long get() = end - start
    }

    private class Source(private val file: RandomAccessFile) {
        val length = file.length()
        private val window = ByteArray(128 * 1024)
        private var windowStart = 0L
        private var windowSize = 0

        operator fun get(position: Long): Int {
            if (position < 0 || position >= length) return -1
            if (position < windowStart || position >= windowStart + windowSize) load(position)
            val index = (position - windowStart).toInt()
            return if (index < windowSize) window[index].toInt() and 0xFF else -1
        }

        private fun load(position: Long) {
            windowStart = position
            file.seek(position)
            var total = 0
            while (total < window.size) {
                val count = file.read(window, total, window.size - total)
                if (count < 0) break
                total += count
            }
            windowSize = total
        }

        fun matches(position: Long, text: String): Boolean =
            text.indices.all { get(position + it) == text[it].code }

        fun bigEndian(position: Long, bytes: Int): Long {
            var value = 0L
            for (i in 0 until bytes) {
                val b = get(position + i)
                if (b < 0) return -1
                value = (value shl 8) or b.toLong()
            }
            return value
        }
    }

    fun scan(file: File, maxSize: Long, isCancelled: () -> Boolean = { false }, onHit: (Hit) -> Unit) {
        RandomAccessFile(file, "r").use { raf ->
            val source = Source(raf)
            var position = 0L
            while (position < source.length) {
                if ((position and 0xFFFF) == 0L && isCancelled()) return
                val hit = when (source[position]) {
                    0xFF -> jpeg(source, position, maxSize)
                    0x89 -> png(source, position, maxSize)
                    'G'.code -> gif(source, position, maxSize)
                    'R'.code -> webp(source, position, maxSize)
                    else -> null
                }
                if (hit != null) {
                    if (isCancelled()) return
                    onHit(hit)
                }
                // A truncated candidate may hide further images, so keep searching inside it.
                position = if (hit != null && !hit.truncated) hit.end else position + 1
            }
        }
    }

    /** Copies one hit to [target]; a truncated JPEG gets the missing end marker. */
    fun extract(file: File, hit: Hit, target: File) {
        RandomAccessFile(file, "r").use { input ->
            input.seek(hit.start)
            target.outputStream().use { output ->
                val buffer = ByteArray(64 * 1024)
                var remaining = hit.size
                while (remaining > 0) {
                    val count = input.read(buffer, 0, minOf(remaining, buffer.size.toLong()).toInt())
                    if (count < 0) break
                    output.write(buffer, 0, count)
                    remaining -= count
                }
                if (hit.truncated) output.write(byteArrayOf(0xFF.toByte(), 0xD9.toByte()))
            }
        }
    }

    private fun jpeg(s: Source, start: Long, maxSize: Long): Hit? {
        if (s[start + 1] != 0xD8 || s[start + 2] != 0xFF) return null
        val limit = start + maxSize
        var p = start + 2
        var hasScan = false
        fun truncated(end: Long) =
            if (hasScan && end - start >= 512) Hit(start, end, "jpg", true) else null
        while (p < limit) {
            if (p >= s.length) return truncated(s.length)
            if (s[p] != 0xFF) return truncated(p)
            val marker = s[p + 1]
            when {
                marker < 0 -> return truncated(s.length)
                marker == 0xFF -> p++
                marker == 0xD9 -> return if (hasScan) Hit(start, p + 2, "jpg") else null
                marker == 0xD8 || marker == 0x00 -> return truncated(p)
                marker == 0x01 || marker in 0xD0..0xD7 -> p += 2
                else -> {
                    val size = s.bigEndian(p + 2, 2)
                    if (size < 2) return truncated(p)
                    p += 2 + size
                    if (marker == 0xDA) {
                        hasScan = true
                        // Skip entropy coded data up to the next real marker.
                        while (p < limit && p < s.length) {
                            if (s[p] == 0xFF) {
                                val next = s[p + 1]
                                if (next == 0x00 || next in 0xD0..0xD7) p += 2
                                else if (next == 0xFF) p++
                                else break
                            } else p++
                        }
                    }
                }
            }
        }
        return null
    }

    private fun png(s: Source, start: Long, maxSize: Long): Hit? {
        if (!s.matches(start + 1, "PNG\r\n\u001A\n")) return null
        var p = start + 8
        if (s.bigEndian(p, 4) != 13L || !s.matches(p + 4, "IHDR")) return null
        while (p + 12 <= s.length) {
            val size = s.bigEndian(p, 4)
            val end = p + 12 + size
            if (size < 0 || end > s.length || end - start > maxSize) return null
            if (s.matches(p + 4, "IEND")) return Hit(start, end, "png")
            p = end
        }
        return null
    }

    private fun gif(s: Source, start: Long, maxSize: Long): Hit? {
        if (!s.matches(start, "GIF89a") && !s.matches(start, "GIF87a")) return null
        val screenFlags = s[start + 10]
        if (screenFlags < 0) return null
        var p = start + 13 + colorTable(screenFlags)
        var images = 0
        /** Returns the position after a chain of data sub-blocks, or -1. */
        fun skipBlocks(from: Long): Long {
            var q = from
            while (q - start <= maxSize) {
                val size = s[q]
                if (size < 0) return -1
                q += 1 + size
                if (size == 0) return q
            }
            return -1
        }
        while (p >= 0 && p - start < maxSize) {
            when (s[p]) {
                0x3B -> return if (images > 0) Hit(start, p + 1, "gif") else null
                0x21 -> p = skipBlocks(p + 2)
                0x2C -> {
                    val flags = s[p + 9]
                    if (flags < 0) return null
                    p = skipBlocks(p + 11 + colorTable(flags))
                    images++
                }
                else -> return null
            }
        }
        return null
    }

    private fun colorTable(flags: Int): Long =
        if (flags and 0x80 != 0) 3L * (1 shl ((flags and 7) + 1)) else 0L

    private fun webp(s: Source, start: Long, maxSize: Long): Hit? {
        if (!s.matches(start, "RIFF") || !s.matches(start + 8, "WEBP")) return null
        var size = 0L
        for (i in 0 until 4) size = size or (s[start + 4 + i].toLong() shl (8 * i))
        val end = start + 8 + size
        if (size < 12 || end > s.length || end - start > maxSize) return null
        return Hit(start, end, "webp")
    }
}
