package com.mustafa.photorecovery

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.widget.ImageView
import kotlin.math.abs

/** Pinch to zoom, drag to pan, double tap to toggle, horizontal swipe when not zoomed. */
class ZoomImageView(context: Context) : ImageView(context) {
    var onSwipe: ((toLeft: Boolean) -> Unit)? = null
    private val transform = Matrix()
    private var zoom = 1f
    private var baseScale = 1f
    private var offsetX = 0f
    private var offsetY = 0f
    private var imageWidth = 0
    private var imageHeight = 0

    private val scaler = ScaleGestureDetector(context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                zoomTo(zoom * detector.scaleFactor, detector.focusX, detector.focusY)
                return true
            }
        })

    private val gestures = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent) = true

        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
            if (zoom > 1f && !scaler.isInProgress) {
                offsetX -= distanceX
                offsetY -= distanceY
                apply()
            }
            return true
        }

        override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
            if (zoom <= 1.01f && abs(velocityX) > abs(velocityY) * 1.5f && abs(velocityX) > 600f) {
                onSwipe?.invoke(velocityX < 0)
            }
            return true
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            zoomTo(if (zoom > 1f) 1f else 3f, e.x, e.y)
            return true
        }
    })

    init {
        scaleType = ScaleType.MATRIX
    }

    fun show(bitmap: Bitmap?) {
        setImageBitmap(bitmap)
        imageWidth = bitmap?.width ?: 0
        imageHeight = bitmap?.height ?: 0
        reset()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        reset()
    }

    private fun reset() {
        if (imageWidth == 0 || width == 0 || height == 0) return
        baseScale = minOf(width.toFloat() / imageWidth, height.toFloat() / imageHeight)
        zoom = 1f
        offsetX = 0f
        offsetY = 0f
        apply()
    }

    private fun zoomTo(target: Float, focusX: Float, focusY: Float) {
        val next = target.coerceIn(1f, 8f)
        val factor = next / zoom
        val x = focusX - width / 2f
        val y = focusY - height / 2f
        offsetX = x - (x - offsetX) * factor
        offsetY = y - (y - offsetY) * factor
        zoom = next
        apply()
    }

    private fun apply() {
        if (imageWidth == 0) return
        val scale = baseScale * zoom
        val shownWidth = imageWidth * scale
        val shownHeight = imageHeight * scale
        val maxX = maxOf(0f, (shownWidth - width) / 2f)
        val maxY = maxOf(0f, (shownHeight - height) / 2f)
        offsetX = offsetX.coerceIn(-maxX, maxX)
        offsetY = offsetY.coerceIn(-maxY, maxY)
        transform.setScale(scale, scale)
        transform.postTranslate((width - shownWidth) / 2f + offsetX, (height - shownHeight) / 2f + offsetY)
        imageMatrix = transform
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaler.onTouchEvent(event)
        gestures.onTouchEvent(event)
        return true
    }
}
