package com.mustafa.photorecovery

import java.io.File

/** Where a candidate was found. It does not prove that the photo was deleted. */
enum class PhotoSource(val label: Int) {
    TRASH(R.string.source_trash),
    FOLDER(R.string.source_folder),
    CARVED(R.string.source_carved),
    THUMBNAIL(R.string.source_thumbnail),
    HIDDEN(R.string.source_hidden)
}

data class Photo(
    val file: File,
    val source: PhotoSource,
    val width: Int = 0,
    val height: Int = 0
) {
    val size: Long = file.length()
    val modified: Long = file.lastModified()
}
