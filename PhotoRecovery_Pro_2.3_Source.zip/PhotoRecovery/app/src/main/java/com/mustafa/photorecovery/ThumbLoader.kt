package com.mustafa.photorecovery

import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import java.util.concurrent.Executors

class ThumbLoader {
    private val main = Handler(Looper.getMainLooper())
    private val pool = Executors.newFixedThreadPool(3)
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 8).toInt()) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    fun load(photo: Photo, view: ImageView) {
        val key = photo.file.absolutePath
        view.tag = key
        val cached = cache.get(key)
        view.setImageBitmap(cached)
        if (cached != null) return
        pool.execute {
            if (view.tag != key) return@execute
            val bitmap = ImageDecode.decode(photo.file, 360) ?: return@execute
            cache.put(key, bitmap)
            main.post { if (view.tag == key) view.setImageBitmap(bitmap) }
        }
    }

    fun clear() = cache.evictAll()

    fun shutdown() {
        pool.shutdownNow()
    }
}
