package com.mustafa.photorecovery

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import androidx.documentfile.provider.DocumentFile
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val shown = ArrayList<Photo>()
    private val selected get() = ScanStore.selected
    private val thumbs = ThumbLoader()
    private val worker = Executors.newSingleThreadExecutor()
    private var comparing = false
    private val storeListener: (Boolean) -> Unit = { full -> if (full) refresh() else renderStatus() }

    private var hideSmall = false
    private var hideCopies = false
    private var redundant: Set<Photo> = emptySet()
    private var analysed: List<Photo> = emptyList()
    private val hashes = HashMap<String, Long?>()
    private var hideExisting = true
    private var existing: Set<Photo> = emptySet()
    private var comparingText = ""
    private val gallery by lazy { GalleryIndex(applicationContext) }
    @Volatile private var closed = false
    private var sortMode = 0
    private var formatIndex = 0
    private var dateIndex = 0
    private val formats = listOf("ALL", "JPEG", "PNG", "GIF", "WEBP", "HEIC", "BMP")
    private val dates = listOf("ALL", "7D", "30D", "OLDER")
    private var selectedTreeUri: Uri? = null

    private lateinit var scanButton: Button
    private lateinit var folderButton: Button
    private lateinit var restoreButton: Button
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var adapter: PhotoAdapter

    private val prefs by lazy { getSharedPreferences("photo_recovery", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        val dark = getSharedPreferences("photo_recovery", MODE_PRIVATE).getBoolean("dark_mode", false)
        setTheme(if (dark) R.style.PhotoRecoveryTheme_Dark else R.style.PhotoRecoveryTheme)
        super.onCreate(savedInstanceState)
        selectedTreeUri = prefs.getString("selected_tree_uri", null)?.let { Uri.parse(it) }
        hideSmall = prefs.getBoolean("hide_small", false)
        hideCopies = prefs.getBoolean("hide_copies", false)
        hideExisting = prefs.getBoolean("hide_existing", true)
        sortMode = prefs.getInt("sort", 0)
        formatIndex = prefs.getInt("format", 0)
        dateIndex = prefs.getInt("date", 0)
        setContentView(buildLayout())
        ScanStore.load(this)
        ScanStore.listener = storeListener
        refresh()
    }

    private fun button(text: Int, action: (View) -> Unit) = MaterialButton(this).apply {
        setText(text)
        isAllCaps = false
        setOnClickListener { action(it) }
    }

    private fun row(vararg views: View) = LinearLayout(this).apply {
        views.forEach {
            addView(it, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = dp(3)
                marginEnd = dp(3)
            })
        }
    }

    private fun buildLayout(): View {
        val title = TextView(this).apply {
            text = "PhotoRecovery Pro"
            textSize = 21f
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, dp(6), 0, dp(6))
        }
        scanButton = button(R.string.start_scan) { toggleScan() }
        folderButton = button(R.string.choose_folder) { openFolderPicker(REQUEST_SCAN_FOLDER) }
        folderButton.setOnLongClickListener {
            if (!ScanStore.busy) {
                saveScanFolder(null)
                status.setText(R.string.folder_cleared)
            }
            true
        }
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
        }
        status = TextView(this).apply {
            gravity = Gravity.CENTER
            maxLines = 3
        }
        val grid = RecyclerView(this)
        grid.layoutManager = GridLayoutManager(this, maxOf(2, resources.configuration.screenWidthDp / 180))
        grid.itemAnimator = null
        adapter = PhotoAdapter(shown, thumbs, { it in selected }, ::toggleAt, ::preview)
        grid.adapter = adapter
        restoreButton = button(R.string.restore_selected) { ScanStore.restore(this, selected.toList()) }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            addView(title)
            addView(row(scanButton, folderButton))
            addView(progress)
            addView(status)
            addView(row(
                button(R.string.filters) { showFilters() },
                button(R.string.select_all) { selectAll() },
                button(R.string.more) { showMenu(it) }
            ))
            addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(restoreButton, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
    }

    private fun refresh() {
        updateRedundant()
        val filtered = ScanStore.results.filter {
            (!hideSmall || it.size >= 50 * 1024) &&
                (!hideCopies || it !in redundant) &&
                (!hideExisting || it !in existing) &&
                PhotoFilters.matches(it.file, formats[formatIndex], dates[dateIndex])
        }
        val sorted = when (sortMode) {
            1 -> filtered.sortedByDescending { it.size }
            2 -> filtered.sortedBy { it.file.name.lowercase() }
            3 -> filtered.sortedByDescending { it.width.toLong() * it.height }
            else -> filtered.sortedByDescending { it.modified }
        }
        shown.clear()
        shown.addAll(sorted)
        selected.retainAll(shown.toHashSet())
        adapter.notifyDataSetChanged()
        renderStatus()
        renderButtons()
    }

    /** Finds copies and photos still in the gallery whenever the finished result list changes. */
    private fun updateRedundant() {
        if (!(hideCopies || hideExisting) || ScanStore.busy || comparing ||
            ScanStore.results.isEmpty() || analysed == ScanStore.results) return
        val snapshot = ArrayList(ScanStore.results)
        val findCopies = hideCopies
        val findExisting = hideExisting
        comparing = true
        comparingText = getString(R.string.similar_working)
        worker.execute {
            var copies: Set<Photo> = emptySet()
            var present: Set<Photo> = emptySet()
            try {
                if (findExisting) {
                    val index = gallery.build({ closed }) { done, total ->
                        runOnUiThread {
                            comparingText = getString(R.string.gallery_progress, done, total)
                            if (!isDestroyed) renderStatus()
                        }
                    }
                    if (index != null) {
                        // Items in the system trash were deleted by the user, so they stay visible.
                        present = snapshot.filter { photo ->
                            !closed && photo.source != PhotoSource.TRASH &&
                                ImageDecode.decode(photo.file, 160)
                                    ?.let { index.contains(GalleryIndex.view(it)) } == true
                        }.toSet()
                    }
                }
                if (findCopies) {
                    val items = snapshot.take(2500).map {
                        val path = it.file.absolutePath
                        val key = "$path:${it.size}:${it.modified}"
                        if (!hashes.containsKey(key)) hashes[key] = PerceptualDuplicates.differenceHash(it.file)
                        DuplicateRules.Item(hashes[key], it.width, it.height, it.size)
                    }
                    copies = DuplicateRules.redundant(items).map { snapshot[it] }.toSet()
                }
            } catch (_: Exception) {
                // Filtering is optional; on failure the photos stay visible.
            }
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                comparing = false
                analysed = snapshot
                redundant = copies
                existing = present
                refresh()
            }
        }
    }

    private fun renderStatus() {
        progress.visibility = if (ScanStore.busy || comparing) View.VISIBLE else View.GONE
        val summary = ScanStore.restoreSummary
        status.text = when {
            ScanStore.running -> getString(R.string.progress, ScanStore.scannedFiles, ScanStore.results.size) +
                "\n" + ScanStore.currentFolder
            ScanStore.restoring -> getString(R.string.restoring)
            comparing -> comparingText
            summary != null -> getString(R.string.restore_result, summary.first, summary.second) +
                "\n" + destinationName()
            ScanStore.finished -> {
                val end = getString(
                    if (ScanStore.failed) R.string.scan_error
                    else if (ScanStore.cancelled) R.string.scan_stopped
                    else R.string.scan_done
                )
                val megabytes = ScanStore.results.sumOf { it.size } / (1024.0 * 1024.0)
                getString(R.string.summary, end, ScanStore.results.size, shown.size, "%.1f".format(megabytes))
            }
            else -> getString(R.string.press_start)
        }
    }

    private fun destinationName(): String {
        val tree = Restorer.destination(this) ?: return "Pictures/Recovered"
        return DocumentFile.fromTreeUri(this, tree)?.name ?: tree.toString()
    }

    private fun renderButtons() {
        scanButton.setText(if (ScanStore.running) R.string.stop_scan else R.string.start_scan)
        scanButton.isEnabled = !ScanStore.restoring && !comparing
        folderButton.setText(if (selectedTreeUri == null) R.string.choose_folder else R.string.folder_selected)
        folderButton.isEnabled = !ScanStore.busy
        restoreButton.text = getString(R.string.restore_selected, selected.size)
        restoreButton.isEnabled = !ScanStore.busy && !comparing && selected.isNotEmpty()
    }

    private fun toggle(photo: Photo) {
        if (!selected.remove(photo)) selected.add(photo)
        val position = shown.indexOf(photo)
        if (position >= 0) adapter.notifyItemChanged(position)
        renderButtons()
    }

    private fun toggleAt(position: Int) {
        shown.getOrNull(position)?.let { toggle(it) }
    }

    private fun preview(position: Int) {
        if (position in shown.indices) {
            PreviewDialog(this, ArrayList(shown), position, { it in selected }, ::toggle).show()
        }
    }

    private fun selectAll() {
        if (shown.isNotEmpty() && selected.size == shown.size) selected.clear() else selected.addAll(shown)
        adapter.notifyDataSetChanged()
        renderButtons()
    }

    private fun spinner(labels: List<Int>, current: Int) = Spinner(this).apply {
        adapter = ArrayAdapter(
            this@MainActivity, android.R.layout.simple_spinner_dropdown_item, labels.map { getString(it) }
        )
        setSelection(current)
    }

    private fun showFilters() {
        val small = CheckBox(this).apply {
            setText(R.string.hide_small)
            isChecked = hideSmall
        }
        val sort = spinner(
            listOf(R.string.sort_new, R.string.sort_size, R.string.sort_name, R.string.sort_resolution), sortMode
        )
        val copies = CheckBox(this).apply {
            setText(R.string.hide_copies)
            isChecked = hideCopies
        }
        val format = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf(getString(R.string.format_all)) + formats.drop(1)
            )
            setSelection(formatIndex)
        }
        val date = spinner(listOf(R.string.date_all, R.string.date_7, R.string.date_30, R.string.date_older), dateIndex)
        val present = CheckBox(this).apply {
            setText(R.string.hide_existing)
            isChecked = hideExisting
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(8))
            listOf(present, small, copies, sort, format, date).forEach { addView(it) }
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.filters)
            .setView(content)
            .setNegativeButton(R.string.close, null)
            .setPositiveButton(R.string.apply) { _, _ ->
                hideSmall = small.isChecked
                hideCopies = copies.isChecked
                hideExisting = present.isChecked
                analysed = emptyList()
                sortMode = sort.selectedItemPosition
                formatIndex = format.selectedItemPosition
                dateIndex = date.selectedItemPosition
                prefs.edit().putBoolean("hide_small", hideSmall).putBoolean("hide_copies", hideCopies).putBoolean("hide_existing", hideExisting).putInt("sort", sortMode)
                    .putInt("format", formatIndex).putInt("date", dateIndex).apply()
                refresh()
            }
            .show()
    }

    private fun showMenu(anchor: View) {
        val menu = PopupMenu(this, anchor)
        fun item(title: Int, action: () -> Unit) {
            menu.menu.add(title).setOnMenuItemClickListener { action(); true }
        }
        val idle = !ScanStore.busy && !comparing
        if (idle) item(R.string.similar) { findSimilarPhotos() }
        if (selected.isNotEmpty()) item(R.string.share) { Sharing.share(this, selected.toList()) }
        item(R.string.history) { showRestoreHistory() }
        if (idle) item(R.string.choose_destination) { openFolderPicker(REQUEST_DESTINATION) }
        if (idle && Restorer.destination(this) != null) item(R.string.default_destination) {
            prefs.edit().remove("dest_tree_uri").apply()
            status.text = destinationName()
        }
        if (idle) item(R.string.clear_temp) { confirmClear() }
        if (idle) item(R.string.theme) {
            prefs.edit().putBoolean("dark_mode", !prefs.getBoolean("dark_mode", false)).apply()
            recreate()
        }
        item(R.string.about) { message(R.string.about, getString(R.string.about_text)) }
        menu.show()
    }

    private fun message(title: Int, text: String) {
        AlertDialog.Builder(this).setTitle(title).setMessage(text)
            .setPositiveButton(R.string.ok, null).show()
    }

    private fun confirmClear() {
        AlertDialog.Builder(this)
            .setTitle(R.string.clear_temp)
            .setMessage(R.string.clear_temp_confirm)
            .setNegativeButton(R.string.close, null)
            .setPositiveButton(R.string.ok) { _, _ ->
                thumbs.clear()
                ScanStore.clearTemporary(this)
            }
            .show()
    }

    private fun showRestoreHistory() {
        val history = getSharedPreferences("photo_recovery_history", MODE_PRIVATE)
        val entries = history.getString("entries", "").orEmpty().lines().filter { it.isNotBlank() }
        val text = if (entries.isEmpty()) getString(R.string.history_empty)
            else entries.takeLast(50).asReversed().joinToString("\n")
        AlertDialog.Builder(this)
            .setTitle(R.string.history)
            .setMessage(text)
            .setPositiveButton(R.string.close, null)
            .setNeutralButton(R.string.history_clear) { _, _ -> history.edit().clear().apply() }
            .show()
    }

    private fun findSimilarPhotos() {
        if (shown.size < 2) {
            message(R.string.similar, getString(R.string.similar_need))
            return
        }
        val candidates = shown.take(2500)
        comparing = true
        comparingText = getString(R.string.similar_working)
        renderStatus()
        renderButtons()
        worker.execute {
            val hashes = candidates.map { PerceptualDuplicates.differenceHash(it.file) }
            val groups = PerceptualDuplicates.groupHashes(hashes, 5)
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                comparing = false
                renderStatus()
                renderButtons()
                val body = if (groups.isEmpty()) getString(R.string.similar_none)
                else groups.take(30).mapIndexed { number, group ->
                    getString(R.string.similar_group, number + 1, group.size) + "\n" +
                        group.take(5).joinToString("\n") { "• " + candidates[it].file.name }
                }.joinToString("\n\n")
                message(R.string.similar, body + "\n\n" + getString(R.string.similar_note))
            }
        }
    }

    private fun saveScanFolder(uri: Uri?) {
        selectedTreeUri = uri
        prefs.edit().putString("selected_tree_uri", uri?.toString()).apply()
        renderButtons()
    }

    private fun openFolderPicker(request: Int) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
        )
        startActivityForResult(intent, request)
    }

    @Deprecated("Platform folder picker")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val result = data ?: return
        val uri = result.data ?: return
        val flags = result.flags and
            (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        try { contentResolver.takePersistableUriPermission(uri, flags) } catch (_: Exception) { }
        if (requestCode == REQUEST_SCAN_FOLDER) {
            saveScanFolder(uri)
            status.setText(R.string.folder_hint)
        } else if (requestCode == REQUEST_DESTINATION) {
            prefs.edit().putString("dest_tree_uri", uri.toString()).apply()
            status.text = getString(R.string.destination_set, destinationName())
        }
    }

    private fun allFilesDeclared() =
        packageManager.getPackageInfo(packageName, PackageManager.GET_PERMISSIONS)
            .requestedPermissions?.contains(Manifest.permission.MANAGE_EXTERNAL_STORAGE) == true

    private fun hasPermission() =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
            PackageManager.PERMISSION_GRANTED

    private fun askPermission() {
        status.setText(R.string.need_permission)
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:$packageName")
                ))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
        }
    }

    private fun toggleScan() {
        if (ScanStore.running) {
            ScanStore.cancel()
            return
        }
        val tree = selectedTreeUri
        if (tree != null && contentResolver.persistedUriPermissions.none { it.uri == tree && it.isReadPermission }) {
            saveScanFolder(null)
            status.setText(R.string.folder_expired)
            return
        }
        // The store build has no all-files permission and scans a chosen folder only.
        if (tree == null && !allFilesDeclared()) {
            status.setText(R.string.store_choose_folder)
            openFolderPicker(REQUEST_SCAN_FOLDER)
            return
        }
        if (tree == null && !hasPermission()) {
            askPermission()
            return
        }
        // Android 9 and older need the storage permission to save restored photos.
        if (Build.VERSION.SDK_INT < 29 && !hasPermission()) {
            askPermission()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }
        thumbs.clear()
        ScanStore.start(this, tree)
        try {
            startForegroundService(Intent(this, ScanService::class.java))
        } catch (_: Exception) {
            // The scan still runs while the app is open.
        }
    }

    override fun onDestroy() {
        if (ScanStore.listener === storeListener) ScanStore.listener = null
        closed = true
        worker.shutdown()
        thumbs.shutdown()
        super.onDestroy()
    }

    private companion object {
        const val REQUEST_SCAN_FOLDER = 42
        const val REQUEST_DESTINATION = 43
    }
}
