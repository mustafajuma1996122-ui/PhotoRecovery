package com.mustafa.photorecovery

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.os.Build
import java.io.File

object ImageDecode {
    /** Decodes a downsampled bitmap; call off the main thread. Returns null on failure. */
    fun decode(file: File, maxDimension: Int): Bitmap? {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            if (bounds.outWidth > 0 && bounds.outHeight > 0) {
                var sample = 1
                while (bounds.outWidth / (sample * 2) >= maxDimension ||
                    bounds.outHeight / (sample * 2) >= maxDimension) sample *= 2
                val options = BitmapFactory.Options().apply { inSampleSize = sample }
                BitmapFactory.decodeFile(file.absolutePath, options)?.let { return it }
            }
            if (Build.VERSION.SDK_INT >= 28) {
                return ImageDecoder.decodeBitmap(ImageDecoder.createSource(file)) { decoder, info, _ ->
                    var sample = 1
                    while (info.size.width / (sample * 2) >= maxDimension ||
                        info.size.height / (sample * 2) >= maxDimension) sample *= 2
                    decoder.setTargetSampleSize(sample)
                    decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE)
                }
            }
        } catch (_: Exception) {
        } catch (_: OutOfMemoryError) {
        }
        return null
    }
}
