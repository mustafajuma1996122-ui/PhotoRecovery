package com.mustafa.photorecovery

import kotlin.math.abs

object DuplicateRules {
    data class Item(val hash: Long?, val width: Int, val height: Int, val bytes: Long)

    /**
     * Returns indices of redundant copies. The highest resolution copy (then the
     * largest file) is kept. Each item is compared with kept items only, so
     * chains of slightly different photos are not merged.
     */
    fun redundant(items: List<Item>, threshold: Int = 2): Set<Int> {
        val order = items.indices.sortedWith(
            compareByDescending<Int> { items[it].width.toLong() * items[it].height }
                .thenByDescending { items[it].bytes }
        )
        val kept = ArrayList<Item>()
        val hidden = HashSet<Int>()
        for (index in order) {
            val item = items[index]
            val hash = item.hash
            // Flat images share trivial hashes, so they are never treated as copies.
            if (hash == null || item.width <= 0 || item.height <= 0 || java.lang.Long.bitCount(hash) !in 4..60) continue
            val copy = kept.any {
                java.lang.Long.bitCount(hash xor it.hash!!) <= threshold && sameShape(item, it)
            }
            if (copy) hidden.add(index) else kept.add(item)
        }
        return hidden
    }

    private fun sameShape(a: Item, b: Item): Boolean {
        val first = a.width.toDouble() / a.height
        val second = b.width.toDouble() / b.height
        return abs(first - second) / second < 0.03
    }
}
