package com.mustafa.photorecovery

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import androidx.documentfile.provider.DocumentFile

class Scanner(private val context: Context, private val onFound: (Photo) -> Unit) {
    @Volatile var cancelled = false
    private val seenPaths = HashSet<String>()
    private val seenHashes = HashSet<String>()
    private val carveDir = temporaryDirectory(context)
    @Volatile var scannedFiles = 0
        private set
    @Volatile var currentFolder = ""
        private set
    private val imageExt = setOf("jpg", "jpeg", "png", "gif", "webp", "heic", "heif", "bmp")
    private val suspiciousWords = listOf("trash", "recycle", "deleted", ".bin", "thumb", "cache")
    private val maxCandidateBytes = 20L * 1024 * 1024
    private val maxStoredBytes = 512L * 1024 * 1024
    private var storedBytes = 0L

    fun scan(treeUri: Uri? = null) {
        carveDir.deleteRecursively()
        storedBytes = 0L
        seenPaths.clear()
        seenHashes.clear()
        if (!carveDir.mkdirs() && !carveDir.isDirectory) throw IllegalStateException("Cannot create the temporary folder")
        if (treeUri != null) {
            scanSelectedTree(treeUri)
        } else {
            if (Build.VERSION.SDK_INT >= 30) scanSystemTrash()
            walk(Environment.getExternalStorageDirectory())
        }
    }

    /** Scans only the folder explicitly granted through Android's Storage Access Framework. */
    private fun scanSelectedTree(treeUri: Uri) {
        val root = DocumentFile.fromTreeUri(context, treeUri) ?: return
        val stack = ArrayDeque<Pair<DocumentFile, Int>>()
        stack.add(root to 0)
        var visited = 0
        while (stack.isNotEmpty() && !cancelled && !cacheFull() && visited < 50_000) {
            val (directory, depth) = stack.removeLast()
            if (depth > 32) continue
            currentFolder = directory.name.orEmpty()
            val children = try { directory.listFiles() } catch (_: Exception) { emptyArray() }
            for (doc in children) {
                if (cancelled || visited++ >= 50_000) return
                if (doc.isDirectory) {
                    stack.add(doc to depth + 1)
                } else if (doc.isFile && doc.length() in 16L..(512L * 1024 * 1024)) {
                    scannedFiles++
                    val name = doc.name ?: "document_${visited}"
                    val lower = name.lowercase()
                    val extension = name.substringAfterLast('.', "").lowercase()
                    val suspicious = lower.startsWith(".") ||
                        listOf("trash", "recycle", "deleted", "thumb", "cache").any { lower.contains(it) }
                    // Do not copy ordinary documents or videos into the app cache.
                    if (extension !in imageExt && !suspicious) continue
                    val temp = File(carveDir, "saf_${visited}_${name.replace(Regex("[^A-Za-z0-9._-]"), "_")}")
                    try {
                        context.contentResolver.openInputStream(doc.uri)?.use { input ->
                            FileOutputStream(temp).use { output -> input.copyTo(output, 64 * 1024) }
                        } ?: continue
                        if (temp.length() <= maxCandidateBytes &&
                            (temp.extension.lowercase() in imageExt || hasKnownImageHeader(temp)) &&
                            isDecodableImage(temp)) {
                            retain(temp, PhotoSource.FOLDER)
                        } else {
                            if (suspicious && temp.length() >= 64L * 1024) carve(temp)
                            temp.delete()
                        }
                    } catch (_: Exception) { temp.delete() }
                }
            }
        }
    }

    /** Queries only trashed MediaStore rows. DATA may be unavailable on some devices. */
    private fun scanSystemTrash() {
        try {
            val args = Bundle().apply {
                putInt(MediaStore.QUERY_ARG_MATCH_TRASHED, MediaStore.MATCH_ONLY)
            }
            context.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Images.Media.DATA), args, null
            )?.use { cursor ->
                val pathColumn = cursor.getColumnIndex(MediaStore.Images.Media.DATA)
                if (pathColumn < 0) return
                while (cursor.moveToNext() && !cancelled) {
                    val path = cursor.getString(pathColumn) ?: continue
                    val candidate = File(path)
                    if (isDecodableImage(candidate)) add(candidate, PhotoSource.TRASH)
                }
            }
        } catch (_: Exception) {
            // OEM MediaStore implementations differ; filesystem scanning continues.
        }
    }

    private fun walk(root: File) {
        val stack = ArrayDeque<File>()
        stack.add(root)
        while (stack.isNotEmpty() && !cancelled) {
            val directory = stack.removeLast()
            currentFolder = directory.name
            val children = try { directory.listFiles() } catch (_: SecurityException) { null } ?: continue
            for (entry in children) {
                if (cancelled) return
                try {
                    if (entry.isDirectory) {
                        val path = entry.absolutePath
                        if (!path.endsWith("/Pictures/Recovered") &&
                            !path.startsWith(context.cacheDir.absolutePath) &&
                            !path.startsWith(context.filesDir.absolutePath) &&
                            !path.startsWith(context.codeCacheDir.absolutePath)) stack.add(entry)
                    } else if (entry.isFile && entry.canRead()) {
                        scannedFiles++
                        inspect(entry)
                    }
                } catch (_: SecurityException) { /* inaccessible folder */ }
            }
        }
    }

    /** Deliberately avoids ordinary gallery files to reduce noise and scan time. */
    private fun inspect(file: File) {
        if (file.length() < 16L) return
        val relative = file.absolutePath
            .removePrefix(Environment.getExternalStorageDirectory().absolutePath)
            .lowercase()
        val hidden = relative.split('/').any { it.startsWith(".") }
        val suspiciousPath = hidden || suspiciousWords.any { relative.contains(it) }
        if (!suspiciousPath) return

        if (file.name.startsWith(".thumbdata", ignoreCase = true)) {
            carve(file)
            return
        }
        if (file.length() <= maxCandidateBytes &&
            (file.extension.lowercase() in imageExt || hasKnownImageHeader(file)) &&
            isDecodableImage(file)) {
            add(file, if (relative.contains("thumb")) PhotoSource.THUMBNAIL else PhotoSource.HIDDEN)
        } else if (file.length() in 64L * 1024..512L * 1024 * 1024 &&
            (relative.contains("cache") || relative.contains("thumb"))) {
            carve(file)
        }
    }

    private fun hasKnownImageHeader(file: File): Boolean {
        val h = ByteArray(16)
        val count = try { FileInputStream(file).use { it.read(h) } } catch (_: Exception) { return false }
        if (count < 12) return false
        val jpeg = h[0] == 0xFF.toByte() && h[1] == 0xD8.toByte() && h[2] == 0xFF.toByte()
        val png = h[0] == 0x89.toByte() && String(h, 1, 3, Charsets.US_ASCII) == "PNG"
        val gif = String(h, 0, 4, Charsets.US_ASCII) == "GIF8"
        val webp = String(h, 0, 4, Charsets.US_ASCII) == "RIFF" && String(h, 8, 4, Charsets.US_ASCII) == "WEBP"
        val heif = String(h, 4, 4, Charsets.US_ASCII) == "ftyp" &&
            (String(h, 8, 4, Charsets.US_ASCII) in setOf("heic", "heix", "hevc", "mif1", "msf1"))
        val bmp = h[0] == 'B'.code.toByte() && h[1] == 'M'.code.toByte()
        return jpeg || png || gif || webp || heif || bmp
    }

    private fun isDecodableImage(file: File): Boolean {
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        return try {
            BitmapFactory.decodeFile(file.absolutePath, options)
            val bitmapFactoryCanRead = options.outWidth > 0 && options.outHeight > 0 &&
                options.outWidth <= 100_000 && options.outHeight <= 100_000 &&
                options.outMimeType?.startsWith("image/") == true
            if (bitmapFactoryCanRead) return true

            // HEIF/HEIC decoding is available only on Android releases/codecs that support it.
            if (Build.VERSION.SDK_INT >= 28 && isHeifFile(file)) {
                val source = android.graphics.ImageDecoder.createSource(file)
                val decoded = android.graphics.ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                    val width = info.size.width
                    val height = info.size.height
                    if (width <= 0 || height <= 0 || width > 100_000 || height > 100_000) {
                        throw IllegalArgumentException("bad HEIF size")
                    }
                    decoder.setTargetSampleSize(16)
                    decoder.setAllocator(android.graphics.ImageDecoder.ALLOCATOR_SOFTWARE)
                }
                decoded.recycle()
                return true
            }
            false
        } catch (_: Exception) { false }
    }

    private fun isHeifFile(file: File): Boolean {
        val header = ByteArray(16)
        val count = try { FileInputStream(file).use { it.read(header) } } catch (_: Exception) { return false }
        return count >= 12 && String(header, 4, 4, Charsets.US_ASCII) == "ftyp" &&
            String(header, 8, 4, Charsets.US_ASCII) in setOf("heic", "heix", "hevc", "mif1", "msf1")
    }

    /** One pass over the source finds every supported format. */
    private fun carve(source: File) {
        try {
            Carver.scan(source, maxCandidateBytes, { cancelled || cacheFull() }) { hit ->
                if (hit.size >= 128) {
                    val candidate = File(carveDir, "candidate_${System.nanoTime()}.${hit.extension}")
                    try {
                        Carver.extract(source, hit, candidate)
                        retain(candidate, PhotoSource.CARVED)
                    } catch (_: Exception) {
                        candidate.delete()
                    }
                }
            }
        } catch (_: Exception) {
            // A damaged cache file must not abort the whole scan.
        }
    }

    private fun cacheFull() = storedBytes >= maxStoredBytes

    /** Keeps a temporary candidate only if it decodes, is new and fits the cache limit. */
    private fun retain(candidate: File, source: PhotoSource) {
        val size = candidate.length()
        if (storedBytes + size <= maxStoredBytes && isDecodableImage(candidate) &&
            seenHashes.add(sha256(candidate))) {
            storedBytes += size
            add(candidate, source)
        } else candidate.delete()
    }

    companion object {
        fun temporaryDirectory(context: Context) = File(context.filesDir, "carved")
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun add(file: File, source: PhotoSource) {
        if (file.isFile && file.canRead() && file.length() >= 16 && seenPaths.add(file.absolutePath)) {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            onFound(Photo(file, source, maxOf(bounds.outWidth, 0), maxOf(bounds.outHeight, 0)))
        }
    }
}
