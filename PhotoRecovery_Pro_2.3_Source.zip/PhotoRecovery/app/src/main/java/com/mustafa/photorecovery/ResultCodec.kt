package com.mustafa.photorecovery

/** One saved result per line. Pure Kotlin so it can be unit tested. */
object ResultCodec {
    data class Entry(val source: String, val width: Int, val height: Int, val path: String)

    fun encode(entry: Entry): String? =
        if (entry.path.any { it == '\n' || it == '\r' }) null
        else "${entry.source}\t${entry.width}\t${entry.height}\t${entry.path}"

    fun decode(line: String): Entry? {
        val parts = line.split('\t', limit = 4)
        if (parts.size != 4 || parts[3].isEmpty()) return null
        val width = parts[1].toIntOrNull() ?: return null
        val height = parts[2].toIntOrNull() ?: return null
        return Entry(parts[0], width, height, parts[3])
    }
}
