package com.mustafa.photorecovery

import android.content.Context
import java.text.DateFormat
import java.util.Date

fun Context.dp(value: Int) = (value * resources.displayMetrics.density).toInt()

fun describe(context: Context, photo: Photo): String {
    val dimensions = if (photo.width > 0) "${photo.width}×${photo.height} — " else ""
    val date = DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(photo.modified))
    // The date of an extracted copy is the extraction time, so it is not shown.
    val extracted = photo.file.absolutePath.startsWith(Scanner.temporaryDirectory(context).absolutePath)
    val base = "${context.getString(photo.source.label)}\n$dimensions${photo.size / 1024} KB"
    return if (extracted) base else "$base\n$date"
}
