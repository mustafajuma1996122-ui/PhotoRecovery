package com.mustafa.photorecovery

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.provider.MediaStore
import java.io.File

/** Fingerprints of the photos currently in the gallery. Use from one background thread. */
class GalleryIndex(private val context: Context) {
    private val cache = HashMap<String, List<GalleryRules.View>>()

    /** Trashed and pending items are not returned by a default MediaStore query. */
    private fun galleryFiles(): List<File> = try {
        val files = ArrayList<File>()
        context.contentResolver.query(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Images.Media.DATA), null, null,
            "${MediaStore.Images.Media.DATE_MODIFIED} DESC"
        )?.use { cursor ->
            while (cursor.moveToNext()) {
                val path = cursor.getString(0) ?: continue
                // Hidden folders are where the candidates come from.
                if (!path.contains("/.")) files.add(File(path))
            }
        }
        files
    } catch (_: Exception) {
        emptyList()
    }

    /** Returns null if cancelled. Rotations cover thumbnails saved upright. */
    fun build(isCancelled: () -> Boolean, onProgress: (Int, Int) -> Unit): GalleryRules.Index? {
        val files = galleryFiles()
        val views = ArrayList<GalleryRules.View>()
        files.forEachIndexed { number, file ->
            if (isCancelled()) return null
            if (number % 25 == 0) onProgress(number, files.size)
            val key = "${file.path}:${file.length()}:${file.lastModified()}"
            views.addAll(cache.getOrPut(key) { viewsOf(file) })
        }
        return GalleryRules.Index(views)
    }

    private fun viewsOf(file: File): List<GalleryRules.View> {
        val bitmap = ImageDecode.decode(file, 160) ?: return emptyList()
        val result = ArrayList<GalleryRules.View>()
        for (degrees in listOf(0f, 90f, 180f, 270f)) {
            val matrix = Matrix().apply { postRotate(degrees) }
            val turned = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
            result.add(view(turned))
            // Some thumbnails are a centre square crop of the picture.
            val side = minOf(turned.width, turned.height)
            val square = Bitmap.createBitmap(
                turned, (turned.width - side) / 2, (turned.height - side) / 2, side, side
            )
            result.add(view(square))
        }
        return result
    }

    companion object {
        fun view(bitmap: Bitmap) = GalleryRules.View(
            PerceptualDuplicates.hashOf(bitmap), bitmap.width.toDouble() / bitmap.height
        )
    }
}
