package com.mustafa.photorecovery

import android.content.Context
import java.io.File

object ResultsRepository {
    private fun store(context: Context) = File(context.filesDir, "results.tsv")

    fun save(context: Context, photos: List<Photo>) {
        try {
            val temporary = File(context.filesDir, "results.tmp")
            temporary.bufferedWriter().use { writer ->
                photos.forEach { photo ->
                    val entry = ResultCodec.Entry(photo.source.name, photo.width, photo.height, photo.file.absolutePath)
                    ResultCodec.encode(entry)?.let { writer.appendLine(it) }
                }
            }
            temporary.renameTo(store(context))
        } catch (_: Exception) {
            // Saving results is a convenience and must not crash the app.
        }
    }

    /** Returns only results whose files still exist. */
    fun load(context: Context): List<Photo> = try {
        store(context).takeIf { it.isFile }?.readLines().orEmpty().mapNotNull { line ->
            val entry = ResultCodec.decode(line) ?: return@mapNotNull null
            val source = PhotoSource.values().firstOrNull { it.name == entry.source } ?: return@mapNotNull null
            val file = File(entry.path)
            if (file.isFile && file.canRead()) Photo(file, source, entry.width, entry.height) else null
        }
    } catch (_: Exception) {
        emptyList()
    }
}
