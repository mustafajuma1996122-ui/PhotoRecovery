package com.mustafa.photorecovery

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.IBinder

/** Keeps the process in the foreground while ScanStore is scanning. */
class ScanService : Service() {
    private val manager by lazy { getSystemService(NotificationManager::class.java) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL, getString(R.string.channel_scan), NotificationManager.IMPORTANCE_LOW)
        )
        startForeground(ID, build())
        if (intent?.action == STOP) ScanStore.cancel()
        ScanStore.serviceListener = { update() }
        update()
        return START_NOT_STICKY
    }

    private fun update() {
        if (ScanStore.running) {
            manager.notify(ID, build())
        } else {
            ScanStore.serviceListener = null
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun build(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, ScanService::class.java).setAction(STOP), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentTitle(getString(R.string.scanning))
            .setContentText(getString(R.string.progress, ScanStore.scannedFiles, ScanStore.results.size))
            .setContentIntent(open)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, getString(R.string.stop_scan), stop).build())
            .build()
    }

    override fun onDestroy() {
        ScanStore.serviceListener = null
        super.onDestroy()
    }

    private companion object {
        const val CHANNEL = "scan"
        const val ID = 7
        const val STOP = "com.mustafa.photorecovery.STOP"
    }
}
