package com.mustafa.photorecovery

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Test

class CarverTest {
    private fun bytes(vararg v: Int) = ByteArray(v.size) { v[it].toByte() }

    private fun jpeg(): ByteArray {
        // The APP1 segment contains a nested end marker, like an EXIF thumbnail.
        val app = bytes(0xFF, 0xE1, 0x00, 0x08, 0xFF, 0xD8, 0xFF, 0xD9, 0x00, 0x00)
        val scan = bytes(0xFF, 0xDA, 0x00, 0x02) + ByteArray(600) { 0x11 } + bytes(0xFF, 0x00, 0x22)
        return bytes(0xFF, 0xD8) + app + scan + bytes(0xFF, 0xD9)
    }

    private fun gif() = "GIF89a".toByteArray() + bytes(1, 0, 1, 0, 0, 0, 0) +
        bytes(0x2C, 0, 0, 0, 0, 1, 0, 1, 0, 0) + bytes(2, 3, 0x3B, 0x3B, 0x3B, 0) + bytes(0x3B)

    private fun carve(data: ByteArray): List<Carver.Hit> {
        val file = File.createTempFile("carve", ".bin")
        return try {
            file.writeBytes(data)
            val hits = ArrayList<Carver.Hit>()
            Carver.scan(file, 1_000_000) { hits.add(it) }
            hits
        } finally {
            file.delete()
        }
    }

    @Test fun nestedThumbnailDoesNotEndJpeg() {
        val image = jpeg()
        val hits = carve(ByteArray(100) + image + ByteArray(50))
        assertEquals(listOf(Carver.Hit(100, 100L + image.size, "jpg")), hits)
    }

    @Test fun gifTrailerByteInsideDataIsIgnored() {
        val image = gif()
        val hits = carve(ByteArray(7) + image + ByteArray(9))
        assertEquals(listOf(Carver.Hit(7, 7L + image.size, "gif")), hits)
    }

    @Test fun truncatedJpegIsReported() {
        val image = jpeg()
        val cut = image.copyOf(image.size - 2)
        assertEquals(listOf(Carver.Hit(0, cut.size.toLong(), "jpg", true)), carve(cut))
    }

    @Test fun randomDataProducesNothing() {
        assertEquals(emptyList<Carver.Hit>(), carve(ByteArray(5000) { 0x55 }))
    }
}
