package com.mustafa.photorecovery

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ResultsAndDuplicatesTest {
    @Test fun entryRoundTripKeepsTabsInPath() {
        val entry = ResultCodec.Entry("CARVED", 10, 20, "/a/b\tc.jpg")
        assertEquals(entry, ResultCodec.decode(ResultCodec.encode(entry)!!))
    }

    @Test fun brokenLinesAreRejected() {
        assertNull(ResultCodec.decode("CARVED\tx\t2\t/a"))
        assertNull(ResultCodec.encode(ResultCodec.Entry("CARVED", 1, 1, "/a\nb")))
    }

    @Test fun keepsHighestResolutionCopy() {
        val items = listOf(
            DuplicateRules.Item(0xFFL, 100, 100, 10),
            DuplicateRules.Item(0xFFL, 400, 400, 90),
            DuplicateRules.Item(0xFF00L, 400, 400, 90),
            DuplicateRules.Item(0xFFL, 400, 200, 50),
            DuplicateRules.Item(0L, 100, 100, 10),
            DuplicateRules.Item(0L, 100, 100, 10)
        )
        assertEquals(setOf(0), DuplicateRules.redundant(items))
    }
}
