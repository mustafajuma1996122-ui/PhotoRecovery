package com.mustafa.photorecovery

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GalleryRulesTest {
    private val index = GalleryRules.Index(listOf(GalleryRules.View(0xFF00FFL, 1.5), GalleryRules.View(0L, 1.0)))

    @Test fun closeHashWithSameShapeMatches() {
        assertTrue(index.contains(GalleryRules.View(0xFF00FEL, 1.52)))
    }

    @Test fun differentHashOrShapeDoesNotMatch() {
        assertFalse(index.contains(GalleryRules.View(0xFF00FF00L, 1.5)))
        assertFalse(index.contains(GalleryRules.View(0xFF00FFL, 1.0)))
    }

    @Test fun flatPicturesAreNeverMatched() {
        assertFalse(index.contains(GalleryRules.View(0L, 1.0)))
    }
}
