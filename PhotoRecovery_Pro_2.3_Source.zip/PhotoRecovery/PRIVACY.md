# سياسة الخصوصية — PhotoRecovery Pro

- يعالج التطبيق الصور على جهازك فقط، ولا يطلب إذن الإنترنت ولا يرسل أي بيانات.
- يحفظ داخل مساحته الخاصة نسخاً مستخرجة وقائمة نتائج الفحص وسجل الاستعادة، ويمكنك مسح الملفات المؤقتة من القائمة.
- لا تخرج صورة من التطبيق إلا عند استعادتها أو مشاركتها بطلب منك.
- النسخة العامة تطلب الوصول لكل الملفات، ونسخة المتجر تقرأ المجلد الذي تختاره فقط.

# Privacy policy

Photos are processed on your device only. The app has no internet permission and sends no data.
Extracted copies, the result list and the restore history stay in private app storage.
Photos leave the app only when you restore or share them.
