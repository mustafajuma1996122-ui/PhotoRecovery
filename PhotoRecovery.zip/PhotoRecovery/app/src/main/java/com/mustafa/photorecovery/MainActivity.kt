package com.mustafa.photorecovery

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.util.LruCache
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val all = ArrayList<Photo>()
    private val shown = ArrayList<Photo>()
    private val selected = HashSet<Photo>()
    private var hideSmall = false
    private var scanner: Scanner? = null
    private var busy = false

    private val worker = Executors.newSingleThreadExecutor()
    private val thumbs = Executors.newFixedThreadPool(3)
    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    private lateinit var status: TextView
    private lateinit var scanButton: Button
    private lateinit var restoreButton: Button
    private lateinit var progress: ProgressBar
    private val adapter = PhotoAdapter()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        scanButton = Button(this).apply { text = "بدء الفحص"; setOnClickListener { toggleScan() } }
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            visibility = View.GONE
        }
        status = TextView(this).apply { text = "اضغط بدء الفحص" }
        val filter = CheckBox(this).apply {
            text = "إخفاء الصور الصغيرة (أقل من 50KB)"
            setOnCheckedChangeListener { _, on -> hideSmall = on; refresh() }
        }
        val selectAll = Button(this).apply {
            text = "تحديد / إلغاء الكل"
            setOnClickListener {
                if (selected.size == shown.size) selected.clear() else selected.addAll(shown)
                updateSelection()
            }
        }
        val grid = GridView(this).apply {
            numColumns = 3
            horizontalSpacing = dp(4)
            verticalSpacing = dp(4)
            adapter = this@MainActivity.adapter
            setOnItemClickListener { _, _, pos, _ ->
                val p = shown[pos]
                if (!selected.remove(p)) selected.add(p)
                updateSelection()
            }
        }
        restoreButton = Button(this).apply { setOnClickListener { restoreSelected() } }
        root.addView(scanButton)
        root.addView(progress)
        root.addView(status)
        root.addView(filter)
        root.addView(selectAll)
        root.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(restoreButton)
        setContentView(root)
        updateSelection()
    }

    private fun hasPermission() =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED

    private fun askPermission() {
        status.text = "امنح إذن الوصول للملفات ثم اضغط بدء الفحص مرة أخرى"
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:$packageName")
                ))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
        }
    }

    private fun toggleScan() {
        if (busy) { scanner?.cancelled = true; return }
        if (!hasPermission()) { askPermission(); return }
        all.clear(); shown.clear(); selected.clear(); cache.evictAll(); updateSelection()
        setBusy(true)
        scanButton.text = "إيقاف الفحص"
        status.text = "جارٍ الفحص..."
        val pending = ArrayList<Photo>()
        var last = 0L
        fun flush() {
            val batch = ArrayList(pending)
            pending.clear()
            runOnUiThread {
                all.addAll(batch)
                refresh()
                status.text = "تم العثور على ${all.size} صورة"
            }
        }
        val s = Scanner(applicationContext) {
            pending.add(it)
            val now = System.currentTimeMillis()
            if (now - last > 700) { last = now; flush() }
        }
        scanner = s
        worker.execute {
            val ok = try { s.scan(); true } catch (_: Throwable) { false }
            flush()
            runOnUiThread {
                setBusy(false)
                scanButton.text = "بدء الفحص"
                val end = if (!ok) "حدث خطأ" else if (s.cancelled) "تم الإيقاف" else "اكتمل الفحص"
                status.text = "$end: ${all.size} صورة"
            }
        }
    }

    private fun setBusy(value: Boolean) {
        busy = value
        progress.visibility = if (value) View.VISIBLE else View.GONE
        updateSelection()
    }

    private fun refresh() {
        shown.clear()
        shown.addAll(all.filter { !hideSmall || it.file.length() >= 50 * 1024 })
        selected.retainAll(shown.toHashSet())
        updateSelection()
    }

    private fun updateSelection() {
        restoreButton.text = "استعادة المحدد (${selected.size})"
        restoreButton.isEnabled = !busy && selected.isNotEmpty()
        adapter.notifyDataSetChanged()
    }

    private fun restoreSelected() {
        val list = selected.toList()
        setBusy(true)
        scanButton.isEnabled = false
        status.text = "جارٍ الاستعادة..."
        worker.execute {
            val done = list.count { Restorer.restore(applicationContext, it) }
            runOnUiThread {
                selected.clear()
                scanButton.isEnabled = true
                setBusy(false)
                status.text = "تمت استعادة $done من ${list.size} إلى Pictures/Recovered"
            }
        }
    }

    private fun decode(path: String): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, o)
        var sample = 1
        while (o.outWidth / (sample * 2) >= 200 && o.outHeight / (sample * 2) >= 200) sample *= 2
        return BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
    }

    inner class PhotoAdapter : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(position: Int) = shown[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val cell = convertView as? LinearLayout ?: LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(4), dp(4), dp(4), dp(4))
                addView(ImageView(context).apply { scaleType = ImageView.ScaleType.CENTER_CROP },
                    LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(105)))
                addView(TextView(context).apply { textSize = 11f; maxLines = 2 })
            }
            val photo = shown[position]
            val image = cell.getChildAt(0) as ImageView
            val label = cell.getChildAt(1) as TextView
            label.text = "${photo.source}\n${photo.file.length() / 1024} KB"
            cell.setBackgroundColor(if (photo in selected) Color.rgb(144, 202, 249) else Color.TRANSPARENT)
            val path = photo.file.absolutePath
            image.tag = path
            val cached = cache.get(path)
            image.setImageBitmap(cached)
            if (cached == null) thumbs.execute {
                if (image.tag != path) return@execute
                val bitmap = try { decode(path) } catch (_: Throwable) { null } ?: return@execute
                cache.put(path, bitmap)
                runOnUiThread { if (image.tag == path) image.setImageBitmap(bitmap) }
            }
            return cell
        }
    }

    override fun onDestroy() {
        scanner?.cancelled = true
        worker.shutdown()
        thumbs.shutdownNow()
        super.onDestroy()
    }
}
