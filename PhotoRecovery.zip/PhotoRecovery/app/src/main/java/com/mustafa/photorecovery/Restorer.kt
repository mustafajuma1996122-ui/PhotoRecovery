package com.mustafa.photorecovery

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File

object Restorer {
    /* ينسخ الصورة إلى Pictures/Recovered دون تعديل الأصل */
    fun restore(context: Context, photo: Photo): Boolean {
        val mime = detectMime(photo.file)
        val ext = when (mime) {
            "image/png" -> "png"
            "image/gif" -> "gif"
            "image/webp" -> "webp"
            "image/heic" -> "heic"
            "image/bmp" -> "bmp"
            else -> "jpg"
        }
        val name = "recovered_${System.currentTimeMillis()}_${photo.file.absolutePath.hashCode().toUInt()}.$ext"
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, mime)
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Recovered")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: return false
                try {
                    resolver.openOutputStream(uri)!!.use { out ->
                        photo.file.inputStream().use { it.copyTo(out) }
                    }
                    values.clear()
                    values.put(MediaStore.Images.Media.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                } catch (e: Exception) {
                    resolver.delete(uri, null, null)
                    throw e
                }
            } else {
                val dir = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                    "Recovered"
                )
                val target = photo.file.copyTo(File(dir, name))
                MediaScannerConnection.scanFile(context, arrayOf(target.path), null, null)
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun detectMime(f: File): String {
        val options = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        android.graphics.BitmapFactory.decodeFile(f.path, options)
        return options.outMimeType?.replace("image/heif", "image/heic") ?: "image/jpeg"
    }
}
