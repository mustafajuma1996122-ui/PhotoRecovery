package com.mustafa.photorecovery

import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.MessageDigest

data class Photo(val file: File, val source: String)

class Scanner(private val context: Context, private val onFound: (Photo) -> Unit) {
    @Volatile var cancelled = false
    private val seenPaths = HashSet<String>()
    private val seenHashes = HashSet<String>()
    private val carveDir = File(context.cacheDir, "carved")
    private val imageExt = setOf("jpg", "jpeg", "png", "gif", "webp", "heic", "heif", "bmp")
    private val trashWords = listOf("trash", "recycle", "deleted", ".bin", "thumb", "cache")

    fun scan() {
        carveDir.deleteRecursively()
        carveDir.mkdirs()
        if (Build.VERSION.SDK_INT >= 30) scanSystemTrash()
        walk(Environment.getExternalStorageDirectory())
    }

    /* صور موجودة في سلة محذوفات النظام (أندرويد 11 فأحدث) */
    private fun scanSystemTrash() {
        try {
            val args = Bundle().apply {
                putInt(MediaStore.QUERY_ARG_MATCH_TRASHED, MediaStore.MATCH_ONLY)
            }
            context.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Images.Media.DATA), args, null
            )?.use { c ->
                while (c.moveToNext() && !cancelled) {
                    val path = c.getString(0) ?: continue
                    add(File(path), "سلة النظام")
                }
            }
        } catch (_: Exception) { }
    }

    private fun walk(root: File) {
        val stack = ArrayDeque<File>()
        stack.add(root)
        while (stack.isNotEmpty() && !cancelled) {
            val children = stack.removeLast().listFiles() ?: continue
            for (f in children) {
                if (cancelled) return
                if (f.isDirectory) {
                    if (!f.absolutePath.endsWith("/Pictures/Recovered")) stack.add(f)
                } else {
                    try { inspect(f) } catch (_: Exception) { }
                }
            }
        }
    }

    /* نأخذ فقط الملفات المخفية أو الموجودة في مجلدات السلة والمؤقتات، لا صور المعرض العادية */
    private fun inspect(f: File) {
        val relative = f.absolutePath
            .removePrefix(Environment.getExternalStorageDirectory().absolutePath)
            .lowercase()
        val hidden = relative.split('/').any { it.startsWith(".") }
        val suspicious = hidden || trashWords.any { relative.contains(it) }
        if (!suspicious) return

        if (f.name.startsWith(".thumbdata")) {
            carve(f)
        } else if (f.length() > 4096 && (f.extension.lowercase() in imageExt || hasImageHeader(f))) {
            add(f, if (relative.contains("thumb")) "صورة مصغرة" else "ملف مخفي/محذوف")
        } else if (f.length() in 65_536L..500_000_000L &&
            (relative.contains("cache") || relative.contains("thumb"))
        ) {
            carve(f) // ملفات كاش قد تحوي صوراً مدمجة
        }
    }

    private fun hasImageHeader(f: File): Boolean {
        val h = ByteArray(12)
        val n = f.inputStream().use { it.read(h) }
        if (n < 12) return false
        val jpeg = h[0] == 0xFF.toByte() && h[1] == 0xD8.toByte() && h[2] == 0xFF.toByte()
        val png = h[0] == 0x89.toByte() && String(h, 1, 3) == "PNG"
        val gif = String(h, 0, 4) == "GIF8"
        val webp = String(h, 0, 4) == "RIFF" && String(h, 8, 4) == "WEBP"
        return jpeg || png || gif || webp
    }

    /* استخراج صور JPEG المدمجة داخل ملفات .thumbdata وملفات الكاش */
    private fun carve(source: File) {
        val out = ByteArrayOutputStream()
        var depth = 0
        var p2 = -1
        var p1 = -1
        source.inputStream().buffered(65536).use { input ->
            while (!cancelled) {
                val b = input.read()
                if (b < 0) break
                if (depth > 0) out.write(b)
                if (p2 == 0xFF && p1 == 0xD8 && b == 0xFF) {
                    if (depth == 0) {
                        out.reset()
                        out.write(0xFF); out.write(0xD8); out.write(0xFF)
                    }
                    depth++
                } else if (depth > 0 && p1 == 0xFF && b == 0xD9) {
                    depth--
                    if (depth == 0) saveCarved(out.toByteArray())
                }
                if (out.size() > 15_000_000) { depth = 0; out.reset() }
                p2 = p1
                p1 = b
            }
        }
    }

    private fun saveCarved(bytes: ByteArray) {
        if (bytes.size < 4096) return
        val hash = MessageDigest.getInstance("MD5").digest(bytes)
            .joinToString("") { "%02x".format(it) }
        if (!seenHashes.add(hash)) return
        val file = File(carveDir, "$hash.jpg")
        file.writeBytes(bytes)
        add(file, "مستخرجة")
    }

    private fun add(f: File, source: String) {
        if (f.canRead() && seenPaths.add(f.absolutePath)) onFound(Photo(f, source))
    }
}
