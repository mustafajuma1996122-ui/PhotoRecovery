package com.mustafa.photorecovery

import java.io.File

/** Pure filtering rules shared by the results UI and unit tests. */
object PhotoFilters {
    fun matches(
        file: File,
        format: String,
        dateRange: String,
        nowMillis: Long = System.currentTimeMillis()
    ): Boolean {
        if (format != "ALL") {
            val extension = file.extension.lowercase()
            val accepted = when (format) {
                "JPEG" -> setOf("jpg", "jpeg")
                "PNG" -> setOf("png")
                "GIF" -> setOf("gif")
                "WEBP" -> setOf("webp")
                "HEIC" -> setOf("heic", "heif")
                "BMP" -> setOf("bmp")
                else -> emptySet()
            }
            if (extension !in accepted) return false
        }

        val age = (nowMillis - file.lastModified()).coerceAtLeast(0L)
        val sevenDays = 7L * 24 * 60 * 60 * 1000
        val thirtyDays = 30L * 24 * 60 * 60 * 1000
        return when (dateRange) {
            "7D" -> age <= sevenDays
            "30D" -> age <= thirtyDays
            "OLDER" -> age > thirtyDays
            else -> true
        }
    }
}
