package com.mustafa.photorecovery

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File

/**
 * Lightweight difference-hash utilities. This detects visually similar images;
 * it never deletes or modifies source files.
 */
object PerceptualDuplicates {
    fun differenceHash(file: File): Long? {
        if (!file.isFile || !file.canRead()) return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        return try {
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0 ||
                bounds.outWidth > 100_000 || bounds.outHeight > 100_000) return null

            var sample = 1
            while (bounds.outWidth / (sample * 2) >= 18 &&
                bounds.outHeight / (sample * 2) >= 16) sample *= 2

            val decoded = BitmapFactory.decodeFile(
                file.absolutePath,
                BitmapFactory.Options().apply {
                    inSampleSize = sample
                    inPreferredConfig = Bitmap.Config.ARGB_8888
                }
            ) ?: return null
            val tiny = Bitmap.createScaledBitmap(decoded, 9, 8, true)
            if (tiny !== decoded) decoded.recycle()

            var hash = 0L
            var bit = 0
            for (y in 0 until 8) {
                for (x in 0 until 8) {
                    val left = tiny.getPixel(x, y)
                    val right = tiny.getPixel(x + 1, y)
                    val leftGray = (android.graphics.Color.red(left) * 299 +
                        android.graphics.Color.green(left) * 587 +
                        android.graphics.Color.blue(left) * 114) / 1000
                    val rightGray = (android.graphics.Color.red(right) * 299 +
                        android.graphics.Color.green(right) * 587 +
                        android.graphics.Color.blue(right) * 114) / 1000
                    if (leftGray > rightGray) hash = hash or (1L shl bit)
                    bit++
                }
            }
            tiny.recycle()
            hash
        } catch (_: Exception) {
            null
        }
    }

    fun hammingDistance(first: Long, second: Long): Int =
        java.lang.Long.bitCount(first xor second)

    /** Groups items whose dHash distance is within the threshold. */
    fun groupHashes(hashes: List<Long?>, threshold: Int = 5): List<List<Int>> {
        val parent = IntArray(hashes.size) { it }
        fun find(start: Int): Int {
            var node = start
            while (parent[node] != node) {
                parent[node] = parent[parent[node]]
                node = parent[node]
            }
            return node
        }
        fun union(a: Int, b: Int) {
            val ra = find(a)
            val rb = find(b)
            if (ra != rb) parent[rb] = ra
        }

        for (i in hashes.indices) {
            val a = hashes[i] ?: continue
            for (j in i + 1 until hashes.size) {
                val b = hashes[j] ?: continue
                if (hammingDistance(a, b) <= threshold) union(i, j)
            }
        }
        return hashes.indices.groupBy { find(it) }.values
            .filter { it.size > 1 }
            .sortedByDescending { it.size }
    }
}
