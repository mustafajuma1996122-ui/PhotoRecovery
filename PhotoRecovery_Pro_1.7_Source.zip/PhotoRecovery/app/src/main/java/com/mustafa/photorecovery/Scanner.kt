package com.mustafa.photorecovery

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import androidx.documentfile.provider.DocumentFile

/** A readable image candidate. Source describes where it was discovered, not deletion certainty. */
data class Photo(val file: File, val source: String)

class Scanner(private val context: Context, private val onFound: (Photo) -> Unit) {
    @Volatile var cancelled = false
    private val seenPaths = HashSet<String>()
    private val seenHashes = HashSet<String>()
    private val carveDir = File(context.cacheDir, "carved")
    private val imageExt = setOf("jpg", "jpeg", "png", "gif", "webp", "heic", "heif", "bmp")
    private val suspiciousWords = listOf("trash", "recycle", "deleted", ".bin", "thumb", "cache")
    private val maxCandidateBytes = 20L * 1024 * 1024
    private val maxTotalCarvedBytes = 256L * 1024 * 1024
    private var totalCarvedBytes = 0L

    fun scan(treeUri: Uri? = null) {
        carveDir.deleteRecursively()
        totalCarvedBytes = 0L
        seenPaths.clear()
        seenHashes.clear()
        if (!carveDir.mkdirs() && !carveDir.isDirectory) throw IllegalStateException("تعذر إنشاء مجلد الفحص المؤقت")
        if (treeUri != null) {
            scanSelectedTree(treeUri)
        } else {
            if (Build.VERSION.SDK_INT >= 30) scanSystemTrash()
            walk(Environment.getExternalStorageDirectory())
        }
    }

    /** Scans only the folder explicitly granted through Android's Storage Access Framework. */
    private fun scanSelectedTree(treeUri: Uri) {
        val root = DocumentFile.fromTreeUri(context, treeUri) ?: return
        val stack = ArrayDeque<Pair<DocumentFile, Int>>()
        stack.add(root to 0)
        var visited = 0
        while (stack.isNotEmpty() && !cancelled && visited < 50_000) {
            val (directory, depth) = stack.removeLast()
            if (depth > 32) continue
            val children = try { directory.listFiles() } catch (_: Exception) { emptyArray() }
            for (doc in children) {
                if (cancelled || visited++ >= 50_000) return
                if (doc.isDirectory) {
                    stack.add(doc to depth + 1)
                } else if (doc.isFile && doc.length() in 16L..(512L * 1024 * 1024)) {
                    val name = doc.name ?: "document_${visited}"
                    val lower = name.lowercase()
                    val extension = name.substringAfterLast('.', "").lowercase()
                    val suspicious = lower.startsWith(".") ||
                        listOf("trash", "recycle", "deleted", "thumb", "cache").any { lower.contains(it) }
                    // Do not copy ordinary documents or videos into the app cache.
                    if (extension !in imageExt && !suspicious) continue
                    val temp = File(carveDir, "saf_${visited}_${name.replace(Regex("[^A-Za-z0-9._-]"), "_")}")
                    try {
                        context.contentResolver.openInputStream(doc.uri)?.use { input ->
                            FileOutputStream(temp).use { output -> input.copyTo(output, 64 * 1024) }
                        } ?: continue
                        if (temp.length() <= maxCandidateBytes &&
                            (temp.extension.lowercase() in imageExt || hasKnownImageHeader(temp)) && isDecodableImage(temp)) {
                            val digest = sha256(temp)
                            if (seenHashes.add(digest)) add(temp, "مجلد محدد") else temp.delete()
                        } else if (suspicious && temp.length() >= 64L * 1024) {
                            carveJpegs(temp)
                            carvePngs(temp)
                            carveWebps(temp)
                            carveGifs(temp)
                            temp.delete()
                        } else temp.delete()
                    } catch (_: Exception) { temp.delete() }
                }
            }
        }
    }

    /** Queries only trashed MediaStore rows. DATA may be unavailable on some devices. */
    private fun scanSystemTrash() {
        try {
            val args = Bundle().apply {
                putInt(MediaStore.QUERY_ARG_MATCH_TRASHED, MediaStore.MATCH_ONLY)
            }
            context.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Images.Media.DATA), args, null
            )?.use { cursor ->
                val pathColumn = cursor.getColumnIndex(MediaStore.Images.Media.DATA)
                if (pathColumn < 0) return
                while (cursor.moveToNext() && !cancelled) {
                    val path = cursor.getString(pathColumn) ?: continue
                    val candidate = File(path)
                    if (isDecodableImage(candidate)) add(candidate, "سلة النظام")
                }
            }
        } catch (_: Exception) {
            // OEM MediaStore implementations differ; filesystem scanning continues.
        }
    }

    private fun walk(root: File) {
        val stack = ArrayDeque<File>()
        stack.add(root)
        while (stack.isNotEmpty() && !cancelled) {
            val directory = stack.removeLast()
            val children = try { directory.listFiles() } catch (_: SecurityException) { null } ?: continue
            for (entry in children) {
                if (cancelled) return
                try {
                    if (entry.isDirectory) {
                        val path = entry.absolutePath
                        if (!path.endsWith("/Pictures/Recovered") &&
                            !path.startsWith(context.cacheDir.absolutePath) &&
                            !path.startsWith(context.codeCacheDir.absolutePath)) stack.add(entry)
                    } else if (entry.isFile && entry.canRead()) {
                        inspect(entry)
                    }
                } catch (_: SecurityException) { /* inaccessible folder */ }
            }
        }
    }

    /** Deliberately avoids ordinary gallery files to reduce noise and scan time. */
    private fun inspect(file: File) {
        if (file.length() < 16L) return
        val relative = file.absolutePath
            .removePrefix(Environment.getExternalStorageDirectory().absolutePath)
            .lowercase()
        val hidden = relative.split('/').any { it.startsWith(".") }
        val suspiciousPath = hidden || suspiciousWords.any { relative.contains(it) }
        if (!suspiciousPath) return

        if (file.name.startsWith(".thumbdata", ignoreCase = true)) {
            carveJpegs(file)
            return
        }
        if (file.length() <= maxCandidateBytes &&
            (file.extension.lowercase() in imageExt || hasKnownImageHeader(file))) {
            if (isDecodableImage(file)) {
                add(file, if (relative.contains("thumb")) "صورة مصغرة" else "ملف مخفي/مؤقت")
            }
        } else if (file.length() in 64L * 1024..512L * 1024 * 1024 &&
            (relative.contains("cache") || relative.contains("thumb"))) {
            carveJpegs(file)
            carvePngs(file)
            carveWebps(file)
            carveGifs(file)
        }
    }

    private fun hasKnownImageHeader(file: File): Boolean {
        val h = ByteArray(16)
        val count = try { FileInputStream(file).use { it.read(h) } } catch (_: Exception) { return false }
        if (count < 12) return false
        val jpeg = h[0] == 0xFF.toByte() && h[1] == 0xD8.toByte() && h[2] == 0xFF.toByte()
        val png = h[0] == 0x89.toByte() && String(h, 1, 3, Charsets.US_ASCII) == "PNG"
        val gif = String(h, 0, 4, Charsets.US_ASCII) == "GIF8"
        val webp = String(h, 0, 4, Charsets.US_ASCII) == "RIFF" && String(h, 8, 4, Charsets.US_ASCII) == "WEBP"
        val heif = String(h, 4, 4, Charsets.US_ASCII) == "ftyp" &&
            (String(h, 8, 4, Charsets.US_ASCII) in setOf("heic", "heix", "hevc", "mif1", "msf1"))
        val bmp = h[0] == 'B'.code.toByte() && h[1] == 'M'.code.toByte()
        return jpeg || png || gif || webp || heif || bmp
    }

    private fun isDecodableImage(file: File): Boolean {
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        return try {
            BitmapFactory.decodeFile(file.absolutePath, options)
            val bitmapFactoryCanRead = options.outWidth > 0 && options.outHeight > 0 &&
                options.outWidth <= 100_000 && options.outHeight <= 100_000 &&
                options.outMimeType?.startsWith("image/") == true
            if (bitmapFactoryCanRead) return true

            // HEIF/HEIC decoding is available only on Android releases/codecs that support it.
            if (Build.VERSION.SDK_INT >= 28 && isHeifFile(file)) {
                val source = android.graphics.ImageDecoder.createSource(file)
                val decoded = android.graphics.ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                    val width = info.size.width
                    val height = info.size.height
                    if (width <= 0 || height <= 0 || width > 100_000 || height > 100_000) {
                        throw IllegalArgumentException("أبعاد HEIF غير صالحة")
                    }
                    decoder.setTargetSampleSize(16)
                    decoder.setAllocator(android.graphics.ImageDecoder.ALLOCATOR_SOFTWARE)
                }
                decoded.recycle()
                return true
            }
            false
        } catch (_: Exception) { false }
    }

    private fun isHeifFile(file: File): Boolean {
        val header = ByteArray(16)
        val count = try { FileInputStream(file).use { it.read(header) } } catch (_: Exception) { return false }
        return count >= 12 && String(header, 4, 4, Charsets.US_ASCII) == "ftyp" &&
            String(header, 8, 4, Charsets.US_ASCII) in setOf("heic", "heix", "hevc", "mif1", "msf1")
    }

    /**
     * Streaming JPEG carving: writes candidates to disk as bytes arrive, so large
     * cache files do not require a matching in-memory byte array. Candidates are
     * retained only after Android's image decoder recognizes their dimensions.
     */
    private fun carveJpegs(source: File) {
        var previous = -1
        var outputFile: File? = null
        var output: BufferedOutputStream? = null
        var written = 0L
        try {
            BufferedInputStream(FileInputStream(source), 128 * 1024).use { input ->
                while (!cancelled) {
                    val value = input.read()
                    if (value < 0) break
                    if (output == null && previous == 0xFF && value == 0xD8) {
                        val candidate = File(carveDir, "candidate_${System.nanoTime()}.jpg")
                        outputFile = candidate
                        output = BufferedOutputStream(FileOutputStream(candidate), 64 * 1024)
                        output!!.write(0xFF)
                        output!!.write(0xD8)
                        written = 2
                    } else if (output != null) {
                        output!!.write(value)
                        written++
                        if (previous == 0xFF && value == 0xD9) {
                            output!!.flush()
                            output!!.close()
                            output = null
                            val candidate = outputFile
                            if (candidate != null && written >= 512 && isDecodableImage(candidate)) {
                                val digest = sha256(candidate)
                                if (seenHashes.add(digest) &&
                                    totalCarvedBytes + candidate.length() <= maxTotalCarvedBytes) {
                                    totalCarvedBytes += candidate.length()
                                    add(candidate, "مستخرجة من ملف مؤقت")
                                } else candidate.delete()
                            } else candidate?.delete()
                            outputFile = null
                            written = 0
                        } else if (written > maxCandidateBytes) {
                            output!!.close()
                            output = null
                            outputFile?.delete()
                            outputFile = null
                            written = 0
                        }
                    }
                    previous = value
                }
            }
        } catch (_: Exception) {
            // A damaged cache file should not abort the complete scan.
        } finally {
            try { output?.close() } catch (_: Exception) { }
            outputFile?.delete()
        }
    }


    /** Extracts bounded PNG candidates until the canonical IEND chunk marker. */
    private fun carvePngs(source: File) = carveBySignature(
        source = source,
        signature = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A),
        format = "png",
        endMarker = byteArrayOf(0x49, 0x45, 0x4E, 0x44, 0xAE.toByte(), 0x42, 0x60, 0x82.toByte())
    )

    /** WebP stores the RIFF payload length in bytes 4..7 of its 12-byte header. */
    private fun carveWebps(source: File) = carveBySignature(
        source = source,
        signature = "RIFF".toByteArray(Charsets.US_ASCII),
        format = "webp",
        endMarker = null,
        webpMode = true
    )

    /** GIF candidates are bounded by the GIF trailer; decoder validation rejects false matches. */
    private fun carveGifs(source: File) = carveBySignature(
        source = source,
        signature = "GIF8".toByteArray(Charsets.US_ASCII),
        format = "gif",
        endMarker = byteArrayOf(0x3B)
    )

    private fun carveBySignature(
        source: File,
        signature: ByteArray,
        format: String,
        endMarker: ByteArray?,
        webpMode: Boolean = false
    ) {
        var output: BufferedOutputStream? = null
        var candidate: File? = null
        var matched = 0
        var written = 0L
        var expectedWebpLength = -1L
        val tail = ArrayDeque<Byte>()
        try {
            BufferedInputStream(FileInputStream(source), 128 * 1024).use { input ->
                while (!cancelled) {
                    val value = input.read()
                    if (value < 0) break
                    if (output == null) {
                        if (value == (signature[matched].toInt() and 0xFF)) {
                            matched++
                            if (matched == signature.size) {
                                candidate = File(carveDir, "candidate_${System.nanoTime()}.$format")
                                output = BufferedOutputStream(FileOutputStream(candidate!!), 32 * 1024)
                                signature.forEach { output!!.write(it.toInt()) }
                                written = signature.size.toLong()
                                matched = 0
                                tail.clear()
                            }
                        } else {
                            matched = if (value == (signature[0].toInt() and 0xFF)) 1 else 0
                        }
                    } else {
                        output!!.write(value)
                        written++
                        tail.addLast(value.toByte())
                        while (tail.size > 8) tail.removeFirst()
                        if (webpMode && written == 8L) {
                            val bytes = tail.toList()
                            val size = (bytes[4].toInt() and 0xFF) or
                                ((bytes[5].toInt() and 0xFF) shl 8) or
                                ((bytes[6].toInt() and 0xFF) shl 16) or
                                ((bytes[7].toInt() and 0xFF) shl 24)
                            expectedWebpLength = size.toLong() + 8L
                            if (expectedWebpLength !in 20L..maxCandidateBytes) expectedWebpLength = -2L
                        }
                        if (webpMode && written == 12L) {
                            val headerTail = tail.toList()
                            val webpTag = headerTail.takeLast(4).map { it.toInt().toChar() }.joinToString("")
                            if (webpTag != "WEBP") expectedWebpLength = -2L
                        }
                        val ended = when {
                            webpMode -> expectedWebpLength > 0 && written >= expectedWebpLength
                            endMarker != null -> tail.size == endMarker.size &&
                                tail.toList().map { it.toInt() } == endMarker.map { it.toInt() }
                            else -> false
                        }
                        if (ended || written > maxCandidateBytes || expectedWebpLength == -2L) {
                            output!!.flush()
                            output!!.close()
                            output = null
                            val result = candidate
                            if (ended && result != null) retainCarved(result, "مستخرجة من ملف مؤقت")
                            else result?.delete()
                            candidate = null
                            written = 0L
                            expectedWebpLength = -1L
                            tail.clear()
                        }
                    }
                }
            }
        } catch (_: Exception) {
            // Ignore malformed candidate streams and continue scanning other files.
        } finally {
            try { output?.close() } catch (_: Exception) { }
            candidate?.delete()
        }
    }

    private fun retainCarved(candidate: File, source: String) {
        if (!isDecodableImage(candidate)) {
            candidate.delete()
            return
        }
        val size = candidate.length()
        if (totalCarvedBytes + size > maxTotalCarvedBytes) {
            candidate.delete()
            return
        }
        val digest = sha256(candidate)
        if (seenHashes.add(digest)) {
            totalCarvedBytes += size
            add(candidate, source)
        } else candidate.delete()
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun add(file: File, source: String) {
        if (file.isFile && file.canRead() && file.length() >= 16 && seenPaths.add(file.absolutePath)) {
            onFound(Photo(file, source))
        }
    }
}
