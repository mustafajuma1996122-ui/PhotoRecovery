package com.mustafa.photorecovery

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File

object Restorer {
    /* ينسخ الصورة إلى Pictures/Recovered دون تعديل الأصل */
    fun restore(context: Context, photo: Photo): Boolean {
        if (!photo.file.exists() || !photo.file.isFile || !photo.file.canRead() || photo.file.length() < 16) {
            recordHistory(context, photo, false)
            return false
        }
        val repaired = tryRepairJpegEndMarker(context, photo.file)
        val sourceFile = repaired ?: photo.file
        val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        try { android.graphics.BitmapFactory.decodeFile(sourceFile.path, bounds) } catch (_: Exception) { }
        val mime = detectMime(sourceFile)
        val heifValid = if (mime == "image/heic" && Build.VERSION.SDK_INT >= 28 &&
            (bounds.outWidth <= 0 || bounds.outHeight <= 0)) decodeHeifForValidation(sourceFile) else false
        if ((bounds.outWidth <= 0 || bounds.outHeight <= 0) && !heifValid || !mime.startsWith("image/")) {
            repaired?.delete()
            recordHistory(context, photo, false)
            return false
        }
        val ext = when (mime) {
            "image/png" -> "png"
            "image/gif" -> "gif"
            "image/webp" -> "webp"
            "image/heic" -> "heic"
            "image/bmp" -> "bmp"
            else -> "jpg"
        }
        val name = "recovered_${System.currentTimeMillis()}_${System.nanoTime()}.$ext"
        val success = try {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, mime)
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Recovered")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("تعذر إنشاء ملف الاستعادة")
                try {
                    val output = resolver.openOutputStream(uri) ?: throw IllegalStateException("تعذر فتح ملف الوجهة")
                    output.use { out ->
                        sourceFile.inputStream().use { it.copyTo(out) }
                    }
                    values.clear()
                    values.put(MediaStore.Images.Media.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                } catch (e: Exception) {
                    resolver.delete(uri, null, null)
                    throw e
                }
            } else {
                val dir = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                    "Recovered"
                )
                if (!dir.exists() && !dir.mkdirs()) throw IllegalStateException("تعذر إنشاء مجلد الاستعادة")
                val target = sourceFile.copyTo(File(dir, name), overwrite = false)
                MediaScannerConnection.scanFile(context, arrayOf(target.path), null, null)
            }
            true
        } catch (_: Exception) {
            false
        }
        repaired?.delete()
        recordHistory(context, photo, success)
        return success
    }

    /**
     * Limited JPEG repair: if the decoder cannot read dimensions, try a temporary
     * copy with a missing EOI marker appended. The original candidate is never modified.
     */
    private fun tryRepairJpegEndMarker(context: Context, source: File): File? {
        return try {
            val header = ByteArray(3)
            val count = source.inputStream().use { it.read(header) }
            if (count < 3 || header[0] != 0xFF.toByte() || header[1] != 0xD8.toByte() ||
                header[2] != 0xFF.toByte()) return null

            val originalBounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(source.path, originalBounds)
            if (originalBounds.outWidth > 0 && originalBounds.outHeight > 0) return null

            val temp = File.createTempFile("jpeg_repair_", ".jpg", context.cacheDir)
            source.inputStream().use { input ->
                temp.outputStream().use { output ->
                    input.copyTo(output, 64 * 1024)
                    output.write(byteArrayOf(0xFF.toByte(), 0xD9.toByte()))
                }
            }
            val repairedBounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(temp.path, repairedBounds)
            if (repairedBounds.outWidth > 0 && repairedBounds.outHeight > 0) temp else {
                temp.delete()
                null
            }
        } catch (_: Exception) { null }
    }

    private fun decodeHeifForValidation(file: File): Boolean {
        return try {
            val source = android.graphics.ImageDecoder.createSource(file)
            val bitmap = android.graphics.ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                if (info.size.width <= 0 || info.size.height <= 0 ||
                    info.size.width > 100_000 || info.size.height > 100_000) {
                    throw IllegalArgumentException("أبعاد HEIF غير صالحة")
                }
                decoder.setTargetSampleSize(16)
                decoder.setAllocator(android.graphics.ImageDecoder.ALLOCATOR_SOFTWARE)
            }
            bitmap.recycle()
            true
        } catch (_: Exception) { false }
    }

    private fun recordHistory(context: Context, photo: Photo, success: Boolean) {
        try {
            val prefs = context.getSharedPreferences("photo_recovery_history", Context.MODE_PRIVATE)
            val old = prefs.getString("entries", "").orEmpty()
            val time = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault())
                .format(java.util.Date())
            val state = if (success) "نجاح" else "فشل"
            val entry = "$time | $state | ${photo.file.name} | ${photo.source}"
            val entries = (old.lines().filter { it.isNotBlank() } + entry).takeLast(100)
            prefs.edit().putString("entries", entries.joinToString("\n")).apply()
        } catch (_: Exception) {
            // History must never interrupt a restore operation.
        }
    }

    private fun detectMime(f: File): String {
        val options = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        android.graphics.BitmapFactory.decodeFile(f.path, options)
        val decodedMime = options.outMimeType?.lowercase()
        if (decodedMime?.startsWith("image/") == true) {
            return if (decodedMime == "image/heif") "image/heic" else decodedMime
        }
        // BitmapFactory support varies by Android release; use validated file signatures as fallback.
        val header = ByteArray(16)
        val count = try { f.inputStream().use { it.read(header) } } catch (_: Exception) { 0 }
        if (count >= 12) {
            if (header[0] == 0xFF.toByte() && header[1] == 0xD8.toByte()) return "image/jpeg"
            if (header[0] == 0x89.toByte() && String(header, 1, 3, Charsets.US_ASCII) == "PNG") return "image/png"
            if (String(header, 0, 4, Charsets.US_ASCII).startsWith("GIF8")) return "image/gif"
            if (String(header, 0, 4, Charsets.US_ASCII) == "RIFF" &&
                String(header, 8, 4, Charsets.US_ASCII) == "WEBP") return "image/webp"
            if (String(header, 4, 4, Charsets.US_ASCII) == "ftyp" &&
                String(header, 8, 4, Charsets.US_ASCII) in setOf("heic", "heix", "hevc", "mif1", "msf1")) return "image/heic"
            if (header[0] == 'B'.code.toByte() && header[1] == 'M'.code.toByte()) return "image/bmp"
        }
        return "application/octet-stream"
    }
}
