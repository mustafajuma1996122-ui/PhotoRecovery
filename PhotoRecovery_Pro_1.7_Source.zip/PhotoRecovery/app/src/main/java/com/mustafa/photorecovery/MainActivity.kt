package com.mustafa.photorecovery

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.util.LruCache
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val all = ArrayList<Photo>()
    private val shown = ArrayList<Photo>()
    private val selected = HashSet<Photo>()
    private var hideSmall = false
    private var scanner: Scanner? = null
    private var busy = false
    private var selectedTreeUri: Uri? = null
    private var sortMode = 0
    private lateinit var folderButton: Button
    private lateinit var sortSpinner: Spinner
    private lateinit var formatSpinner: Spinner
    private lateinit var dateSpinner: Spinner
    private var formatFilter = "ALL"
    private var dateFilter = "ALL"

    private val worker = Executors.newSingleThreadExecutor()
    private val thumbs = Executors.newFixedThreadPool(3)
    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    private lateinit var status: TextView
    private lateinit var scanButton: Button
    private lateinit var restoreButton: Button
    private lateinit var progress: ProgressBar
    private val adapter = PhotoAdapter()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun styleActionButton(button: MaterialButton, primary: Boolean) {
        button.cornerRadius = dp(14)
        button.insetTop = dp(3)
        button.insetBottom = dp(3)
        button.backgroundTintList = android.content.res.ColorStateList.valueOf(
            if (primary) Color.rgb(27, 105, 184) else Color.rgb(231, 238, 247)
        )
        button.setTextColor(if (primary) Color.WHITE else Color.rgb(35, 65, 95))
        button.textSize = 14f
        button.isAllCaps = false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        selectedTreeUri = getSharedPreferences("photo_recovery", MODE_PRIVATE)
            .getString("selected_tree_uri", null)?.let { Uri.parse(it) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.rgb(244, 247, 251))
        }
        val header = TextView(this).apply {
            text = "PhotoRecovery Pro"
            textSize = 23f
            setTextColor(Color.rgb(24, 55, 85))
            gravity = android.view.Gravity.CENTER
            setPadding(0, dp(10), 0, dp(4))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val subtitle = TextView(this).apply {
            text = "استعادة الصور القابلة للوصول — اضغط مطولاً لمعاينة الصورة"
            textSize = 12f
            gravity = android.view.Gravity.CENTER
            setTextColor(Color.DKGRAY)
            setPadding(0, 0, 0, dp(10))
        }
        folderButton = MaterialButton(this).apply {
            styleActionButton(this, false)
            text = "اختيار مجلد للفحص"
            setOnClickListener { openFolderPicker() }
            setOnLongClickListener {
                selectedTreeUri = null
                getSharedPreferences("photo_recovery", MODE_PRIVATE).edit()
                    .remove("selected_tree_uri").apply()
                text = "اختيار مجلد للفحص"
                status.text = "تم إلغاء تحديد المجلد — سيُستخدم الفحص العام بعد منح الإذن"
                true
            }
        }
        scanButton = MaterialButton(this).apply {
            styleActionButton(this, true)
            text = "بدء الفحص"
            setOnClickListener { toggleScan() }
        }
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            visibility = View.GONE
        }
        status = TextView(this).apply { text = "اضغط بدء الفحص" }
        val filter = CheckBox(this).apply {
            text = "إخفاء الصور الصغيرة (أقل من 50KB)"
            setOnCheckedChangeListener { _, on -> hideSmall = on; refresh() }
        }
        sortSpinner = Spinner(this).apply {
            this.adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                listOf("ترتيب: الأحدث أولاً", "ترتيب: الأكبر حجماً", "ترتيب: الاسم")
            )
            onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                    sortMode = position
                    refresh()
                }
            }
        }
        formatSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                listOf("كل الصيغ", "JPEG", "PNG", "GIF", "WEBP", "HEIC", "BMP")
            )
            onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                    formatFilter = listOf("ALL", "JPEG", "PNG", "GIF", "WEBP", "HEIC", "BMP")[position]
                    refresh()
                }
            }
        }
        dateSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                listOf("كل التواريخ", "آخر 7 أيام", "آخر 30 يوماً", "أقدم من 30 يوماً")
            )
            onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                    dateFilter = listOf("ALL", "7D", "30D", "OLDER")[position]
                    refresh()
                }
            }
        }
        val filterLabel = TextView(this).apply {
            text = "تصفية النتائج"
            textSize = 14f
            setTextColor(Color.rgb(45, 59, 78))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(dp(4), dp(8), dp(4), dp(2))
        }
        val historyButton = MaterialButton(this).apply {
            styleActionButton(this, false)
            text = "سجل عمليات الاستعادة"
            setOnClickListener { showRestoreHistory() }
        }
        val selectAll = MaterialButton(this).apply {
            styleActionButton(this, false)
            text = "تحديد / إلغاء الكل"
            setOnClickListener {
                if (selected.size == shown.size) selected.clear() else selected.addAll(shown)
                updateSelection()
            }
        }
        val duplicatesButton = MaterialButton(this).apply {
            styleActionButton(this, false)
            text = "كشف الصور المتشابهة"
            setOnClickListener { findSimilarPhotos() }
        }
        val grid = GridView(this).apply {
            numColumns = 3
            horizontalSpacing = dp(4)
            verticalSpacing = dp(4)
            adapter = this@MainActivity.adapter
            setOnItemClickListener { _, _, pos, _ ->
                val p = shown[pos]
                if (!selected.remove(p)) selected.add(p)
                updateSelection()
            }
            setOnItemLongClickListener { _, _, pos, _ ->
                showPhotoPreview(shown[pos])
                true
            }
        }
        restoreButton = MaterialButton(this).apply {
            styleActionButton(this, true)
            setOnClickListener { restoreSelected() }
        }
        val headerContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            addView(header)
            addView(subtitle)
        }
        val headerCard = MaterialCardView(this).apply {
            radius = dp(18).toFloat()
            cardElevation = dp(2).toFloat()
            setCardBackgroundColor(Color.WHITE)
            addView(headerContent)
        }
        root.addView(headerCard)
        root.addView(folderButton)
        root.addView(scanButton)
        root.addView(progress)
        root.addView(status)
        root.addView(filter)
        root.addView(sortSpinner)
        root.addView(filterLabel)
        root.addView(formatSpinner)
        root.addView(dateSpinner)
        root.addView(historyButton)
        root.addView(selectAll)
        root.addView(duplicatesButton)
        root.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(restoreButton)
        val about = MaterialButton(this).apply {
            styleActionButton(this, false)
            text = "حول التطبيق وحقوق الملكية"
            setOnClickListener { showAbout() }
        }
        root.addView(about)
        val copyright = TextView(this).apply {
            text = "© 2026 Mustafa Jumaa Burhan"
            textSize = 10f
            gravity = android.view.Gravity.CENTER
            setTextColor(Color.GRAY)
            setPadding(0, dp(6), 0, dp(2))
        }
        root.addView(copyright)
        setContentView(root)
        if (selectedTreeUri != null) folderButton.text = "مجلد محدد — تغيير المجلد"
        updateSelection()
    }

    private fun showAbout() {
        android.app.AlertDialog.Builder(this)
            .setTitle("PhotoRecovery Pro")
            .setMessage(
                "أداة لفحص مواقع التخزين التي يسمح Android للتطبيق بالوصول إليها، " +
                "واستخراج الصور من بعض الملفات المؤقتة والمصغرات.\n\n" +
                "لا يضمن التطبيق استعادة الصور المحذوفة نهائياً. تعتمد النتيجة على " +
                "صلاحيات الجهاز وحالة التخزين والتشفير وميزة TRIM.\n\n" +
                "حقوق الملكية: © 2026 Mustafa Jumaa Burhan"
            )
            .setPositiveButton("حسناً", null)
            .show()
    }

    private fun openFolderPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, 42)
    }

    @Deprecated("Uses the platform folder picker for compatibility with the current Activity implementation")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            try { contentResolver.takePersistableUriPermission(uri, flags) } catch (_: Exception) { }
            selectedTreeUri = uri
            getSharedPreferences("photo_recovery", MODE_PRIVATE).edit()
                .putString("selected_tree_uri", uri.toString()).apply()
            folderButton.text = "تم اختيار مجلد — تغيير المجلد"
            status.text = "سيتم فحص المجلد الذي اخترته فقط"
        }
    }

    private fun hasPermission() =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED

    private fun askPermission() {
        status.text = "امنح إذن الوصول للملفات ثم اضغط بدء الفحص مرة أخرى"
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:$packageName")
                ))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
        }
    }

    private fun toggleScan() {
        if (busy) { scanner?.cancelled = true; return }
        if (selectedTreeUri != null && contentResolver.persistedUriPermissions.none {
                it.uri == selectedTreeUri && it.isReadPermission
            }) {
            selectedTreeUri = null
            getSharedPreferences("photo_recovery", MODE_PRIVATE).edit().remove("selected_tree_uri").apply()
            status.text = "انتهت صلاحية المجلد. اختر المجلد مرة أخرى."
            openFolderPicker()
            return
        }
        if (selectedTreeUri == null && !hasPermission()) { askPermission(); return }
        all.clear(); shown.clear(); selected.clear(); cache.evictAll(); updateSelection()
        setBusy(true)
        scanButton.text = "إيقاف الفحص"
        status.text = "جارٍ الفحص..."
        val pending = ArrayList<Photo>()
        var last = 0L
        fun flush() {
            val batch = ArrayList(pending)
            pending.clear()
            runOnUiThread {
                all.addAll(batch)
                refresh()
                status.text = "تم العثور على ${all.size} صورة"
            }
        }
        val s = Scanner(applicationContext) {
            pending.add(it)
            val now = System.currentTimeMillis()
            if (now - last > 700) { last = now; flush() }
        }
        scanner = s
        worker.execute {
            val ok = try { s.scan(selectedTreeUri); true } catch (_: Throwable) { false }
            flush()
            runOnUiThread {
                setBusy(false)
                scanButton.text = "بدء الفحص"
                val end = if (!ok) "حدث خطأ" else if (s.cancelled) "تم الإيقاف" else "اكتمل الفحص"
                val totalBytes = all.sumOf { it.file.length() }
                val byFormat = all.groupingBy { it.file.extension.uppercase().ifBlank { "غير معروف" } }
                    .eachCount().entries.sortedByDescending { it.value }
                    .take(4).joinToString("، ") { "${it.key}: ${it.value}" }
                val sizeMb = totalBytes / (1024.0 * 1024.0)
                status.text = "$end: ${all.size} صورة | ${"%.1f".format(java.util.Locale.getDefault(), sizeMb)} MB" +
                    if (byFormat.isNotBlank()) "\n$byFormat" else ""
            }
        }
    }

    private fun setBusy(value: Boolean) {
        busy = value
        progress.visibility = if (value) View.VISIBLE else View.GONE
        updateSelection()
    }

    private fun refresh() {
        shown.clear()
        val filtered = all.filter {
            (!hideSmall || it.file.length() >= 50 * 1024) &&
                PhotoFilters.matches(it.file, formatFilter, dateFilter)
        }
        val sorted = when (sortMode) {
            1 -> filtered.sortedByDescending { it.file.length() }
            2 -> filtered.sortedBy { it.file.name.lowercase() }
            else -> filtered.sortedByDescending { it.file.lastModified() }
        }
        shown.addAll(sorted)
        selected.retainAll(shown.toHashSet())
        if (::restoreButton.isInitialized) updateSelection()
    }

    /**
     * Computes small perceptual hashes off the UI thread and reports likely
     * duplicates. No source file is deleted or changed.
     */
    private fun findSimilarPhotos() {
        if (busy) return
        if (shown.size < 2) {
            android.app.AlertDialog.Builder(this)
                .setMessage("تحتاج إلى صورتين على الأقل لإجراء المقارنة.")
                .setPositiveButton("حسناً", null).show()
            return
        }
        val candidates = shown.take(2500)
        setBusy(true)
        status.text = "جارٍ تحليل التشابه البصري لـ ${candidates.size} صورة..."
        worker.execute {
            val hashes = candidates.map { PerceptualDuplicates.differenceHash(it.file) }
            val groups = PerceptualDuplicates.groupHashes(hashes, 5)
            val message = if (groups.isEmpty()) {
                "لم يتم العثور على مجموعات صور متشابهة ضمن حد المقارنة الحالي."
            } else {
                groups.take(30).mapIndexed { index, group ->
                    val names = group.take(5).joinToString("\n") { i ->
                        "• ${candidates[i].file.name}"
                    }
                    "${index + 1}) ${group.size} صور متشابهة\n$names" +
                        if (group.size > 5) "\n... و${group.size - 5} أخرى" else ""
                }.joinToString("\n\n")
            }
            runOnUiThread {
                setBusy(false)
                status.text = "اكتمل تحليل التشابه: ${groups.size} مجموعة"
                android.app.AlertDialog.Builder(this)
                    .setTitle("نتائج التشابه البصري")
                    .setMessage(
                        "$message\n\nملاحظة: التشابه تقديري وقد تظهر نتائج متقاربة غير متطابقة. " +
                            "لم يتم حذف أو تعديل أي ملف." +
                            if (shown.size > candidates.size) "\nتم تحليل أول ${candidates.size} صورة فقط لتقليل استهلاك الذاكرة والوقت." else ""
                    )
                    .setPositiveButton("إغلاق", null)
                    .show()
            }
        }
    }

    private fun showRestoreHistory() {
        val entries = getSharedPreferences("photo_recovery_history", MODE_PRIVATE)
            .getString("entries", "")?.lines()?.filter { it.isNotBlank() } ?: emptyList()
        val message = if (entries.isEmpty()) "لا توجد عمليات استعادة مسجلة بعد."
            else entries.takeLast(50).asReversed().joinToString("\n")
        android.app.AlertDialog.Builder(this)
            .setTitle("سجل عمليات الاستعادة")
            .setMessage(message)
            .setPositiveButton("إغلاق", null)
            .setNeutralButton("مسح السجل") { _, _ ->
                getSharedPreferences("photo_recovery_history", MODE_PRIVATE).edit()
                    .remove("entries").apply()
            }
            .show()
    }

    private fun updateSelection() {
        restoreButton.text = "استعادة المحدد (${selected.size})"
        restoreButton.isEnabled = !busy && selected.isNotEmpty()
        adapter.notifyDataSetChanged()
    }

    /** Long-press a result to inspect it before deciding to restore it. */
    private fun showPhotoPreview(photo: Photo) {
        val bitmap = try { decodeFullPreview(photo.file.absolutePath) } catch (_: Exception) { null }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        val preview = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setImageBitmap(bitmap)
            minimumHeight = dp(220)
            maxHeight = dp(420)
        }
        val info = TextView(this).apply {
            text = "المصدر: ${photo.source}\nالحجم: ${photo.file.length() / 1024} KB\nالملف: ${photo.file.name}"
            textSize = 13f
            setPadding(0, dp(12), 0, dp(4))
        }
        content.addView(preview, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        content.addView(info)
        android.app.AlertDialog.Builder(this)
            .setTitle("معاينة الصورة")
            .setView(content)
            .setNegativeButton("إغلاق", null)
            .setPositiveButton(if (photo in selected) "إلغاء التحديد" else "تحديد للاستعادة") { _, _ ->
                if (!selected.remove(photo)) selected.add(photo)
                updateSelection()
            }
            .show()
    }

    private fun decodeFullPreview(path: String): Bitmap? = decodeImage(path, 900)

    private fun decodeImage(path: String, maxDimension: Int): Bitmap? {
        val file = java.io.File(path)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        if (bounds.outWidth > 0 && bounds.outHeight > 0) {
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= maxDimension ||
                bounds.outHeight / (sample * 2) >= maxDimension) sample *= 2
            BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })?.let { return it }
        }
        if (Build.VERSION.SDK_INT >= 28) {
            return try {
                val source = android.graphics.ImageDecoder.createSource(file)
                android.graphics.ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                    var sample = 1
                    while (info.size.width / (sample * 2) >= maxDimension ||
                        info.size.height / (sample * 2) >= maxDimension) sample *= 2
                    decoder.setTargetSampleSize(sample)
                    decoder.setAllocator(android.graphics.ImageDecoder.ALLOCATOR_SOFTWARE)
                }
            } catch (_: Exception) { null }
        }
        return null
    }

    private fun restoreSelected() {
        val list = selected.toList()
        setBusy(true)
        scanButton.isEnabled = false
        status.text = "جارٍ الاستعادة..."
        worker.execute {
            var done = 0
            var failed = 0
            list.forEach { photo ->
                if (Restorer.restore(applicationContext, photo)) done++ else failed++
            }
            runOnUiThread {
                selected.clear()
                scanButton.isEnabled = true
                setBusy(false)
                status.text = "نجحت استعادة $done وفشلت $failed — المجلد: Pictures/Recovered"
            }
        }
    }

    private fun decode(path: String): Bitmap? = decodeImage(path, 200)

    inner class PhotoAdapter : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(position: Int) = shown[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val cell = convertView as? LinearLayout ?: LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(4), dp(4), dp(4), dp(4))
                addView(ImageView(context).apply { scaleType = ImageView.ScaleType.CENTER_CROP },
                    LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(105)))
                addView(TextView(context).apply { textSize = 11f; maxLines = 2 })
            }
            val photo = shown[position]
            val image = cell.getChildAt(0) as ImageView
            val label = cell.getChildAt(1) as TextView
            label.text = "${photo.source}\n${photo.file.length() / 1024} KB"
            cell.setBackgroundColor(if (photo in selected) Color.rgb(144, 202, 249) else Color.TRANSPARENT)
            val path = photo.file.absolutePath
            image.tag = path
            val cached = cache.get(path)
            image.setImageBitmap(cached)
            if (cached == null) thumbs.execute {
                if (image.tag != path) return@execute
                val bitmap = try { decode(path) } catch (_: Throwable) { null } ?: return@execute
                cache.put(path, bitmap)
                runOnUiThread { if (image.tag == path) image.setImageBitmap(bitmap) }
            }
            return cell
        }
    }

    override fun onDestroy() {
        scanner?.cancelled = true
        worker.shutdown()
        thumbs.shutdownNow()
        super.onDestroy()
    }
}
