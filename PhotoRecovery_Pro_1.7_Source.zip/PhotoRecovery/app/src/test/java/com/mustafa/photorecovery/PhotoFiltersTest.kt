package com.mustafa.photorecovery

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PhotoFiltersTest {
    @Test fun jpegFilterAcceptsBothExtensions() {
        val now = System.currentTimeMillis()
        assertTrue(PhotoFilters.matches(File("photo.jpg"), "JPEG", "ALL", now))
        assertTrue(PhotoFilters.matches(File("photo.jpeg"), "JPEG", "ALL", now))
        assertFalse(PhotoFilters.matches(File("photo.png"), "JPEG", "ALL", now))
    }

    @Test fun dateFilterUsesThirtyDayBoundary() {
        val now = System.currentTimeMillis()
        val recent = File.createTempFile("recent", ".png")
        val old = File.createTempFile("old", ".png")
        try {
            recent.setLastModified(now - 10L * 24 * 60 * 60 * 1000)
            old.setLastModified(now - 45L * 24 * 60 * 60 * 1000)
            assertTrue(PhotoFilters.matches(recent, "ALL", "30D", now))
            assertFalse(PhotoFilters.matches(old, "ALL", "30D", now))
            assertTrue(PhotoFilters.matches(old, "ALL", "OLDER", now))
        } finally {
            recent.delete()
            old.delete()
        }
    }
}


class PerceptualDuplicatesTest {
    @org.junit.Test
    fun hammingDistanceCountsDifferentBits() {
        org.junit.Assert.assertEquals(0, PerceptualDuplicates.hammingDistance(0L, 0L))
        org.junit.Assert.assertEquals(1, PerceptualDuplicates.hammingDistance(0L, 1L))
        org.junit.Assert.assertEquals(3, PerceptualDuplicates.hammingDistance(0L, 7L))
    }

    @org.junit.Test
    fun groupsOnlyHashesWithinThreshold() {
        val groups = PerceptualDuplicates.groupHashes(
            listOf(0L, 1L, 3L, 255L, null),
            threshold = 2
        )
        org.junit.Assert.assertEquals(1, groups.size)
        org.junit.Assert.assertEquals(listOf(0, 1, 2), groups.single())
    }
}
